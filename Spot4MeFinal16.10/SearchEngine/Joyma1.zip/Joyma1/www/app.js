/*
    This file is generated and updated by Sencha Cmd. You can edit this file as
    needed for your application, but these edits will have to be merged by
    Sencha Cmd when it performs code generation tasks such as generating new
    models, controllers or views and when running "sencha app upgrade".

    Ideally changes to this file would be limited and most work would be done
    in other places (such as Controllers). If Sencha Cmd cannot merge your
    changes and its generated code, it will produce a "merge conflict" that you
    will need to resolve manually.
*/

// DO NOT DELETE - this directive is required for Sencha Cmd packages to work.
//@require @packageOverrides

//<debug>
Ext.Loader.setPath({
    'Ext': 'touch/src',
    'INBooks': 'app'
});
//</debug>

Ext.application({
    name: 'com.inbooks',

    requires: [
        'Ext.MessageBox', 'com.inbooks.classes.Helpers'
    ],

    models: [
        'BooksModel', 'CatalogModel', 'BookshelfModel', 'BookmarksModel', 
        'MusicModel', 'VideoModel'
    ],
    views: [
    //'Login'
    ],

    stores: [
        'BooksStore', 'CatalogStore', 'BookshelfStore', 'BookmarksStore',
        'SearchStore', 'MusicStore', 'VideoStore'
    ],

    controllers: ['HeaderController', 'FooterController', 'LoginController', 'SignUpController',
        'DashboardController', 'CatalogController', 'BooksController', 'ReaderController',
        'AppController', 'InviteController', 'BookshelfController', 'BookmarksController',
        'ReachUsController', 'SettingsController', 'PreferenceController', 'ProfileController',
        'SearchController', 'DonationController', 'VideosController', 'MusicController' ],

    

    isIconPrecomposed: true,

    /*Global declarations - Start*/

    g_api_port: '',
    g_api_host: 'http://api.inbooks.in',
    g_menus: ['login', 'signup', 'dashboard', 'catalog', 'books', 'bookshelf', 'bookmarks', 'reader', 'settings', 'invite', 'reachus', 'invite', 'search', 'donation', 'music', 'videos'],
    g_arrNavHistory: [],
    g_clrNavHistory: true,
    g_viewportCaller: null,
    g_catalogs: null,
    g_books: null,
    g_bookshelf: null,
    g_bookId: null,
    g_pages: null, //Holds book pages
    g_bookTitle: null, //Title of the selected book
    g_bookmarkPanel: null, //Bookmark panel view
    g_bookmarks: null,
    //Selected book details
    g_selectedBookDetails: null,
    g_BookThumbnailUrl: 'http://www.inbooks.in/content/books/',
    g_gotoPageSlider: null,
    g_imginfo: [],
    g_prefetchedImgs: [],
    g_Async_prefetch_CallStack:[],
    g_promise_pipelength: 0,
    g_pinchStartScale: null,
    g_pinchEndScale: null,
    g_minWidth: null,
    g_minHeight: null,
    /*Global declarations - End*/

    /*Global Functions - Start*/
    destroyHeaderButtons: function () {
        var ids = ['id-vw-reader', 'id-vw-books', 'id-vw-login', 'id-vw-signup', 'id-vw-catalog', 'id-vw-bookshelf', 'carousel-reader', 'id-vw-settings', 'id-vw-dashboard', 'id-footer', 'id-vw-bookshelf', 'pnlBookmarks', 'id-vw-search','id-vw-donation', 'id-video']; //'id-footer',
        ids.forEach(function (id) {
            try {
                if (Ext.getCmp(id) != undefined) {
                    Ext.getCmp(id).destroy()
                }
            } catch (e) { console.log("Error while destroying the component [" + id + "]") }
        });
        //Destroy the current main view aka activeitem from Dom
        try { Ext.Viewport.getActiveItem().destroy(); } catch (e) { }

        //reset the com.inbooks.app.g_bookmarkPanel value
        com.inbooks.app.g_bookmarkPanel = null;
        //Clear App Cache
        try {
            console.log("Clearing Application Data & Cache");
            window.MyCls.clearApplicationData;
            console.log("Cleared Application Data & Cache");
        } catch (e) { console.log("Error during clearApplicationData()"); }
    },
    /*Global Functions - End*/

    
    launch: function () {
 		localStorage.setItem('curTheme',"Green,vm-green-theme");//set the current theme. default: green
        var preferredLang = localStorage.getItem('lang');
        console.log("lang: " + preferredLang);
        if (preferredLang == null) {
            preferredLang = "ENG";
            localStorage.setItem('lang', preferredLang);
            com.inbooks.classes.Helpers.setLanguage(preferredLang);
        } else {
            com.inbooks.classes.Helpers.setLanguage(preferredLang);
        }
        // Destroy the #splashLoader element
        try {
            Ext.fly('splashLoader').destroy();
        }
        catch (e) { console.log(e.message) }

        // Initialize the main view
        if (localStorage.getItem('Inbooks-keepmeloggedin') == 1) {
            Ext.Viewport.add(Ext.create('com.inbooks.view.Dashboard'));
        }
        else {
            Ext.Viewport.add(Ext.create('com.inbooks.view.Login'));
        }

        //Bubble the event to update screen orientation on active item change
        Ext.Viewport.on('activeitemchange', com.inbooks.classes.Helpers.updateScreenOrientation);
    },
    onUpdated: function () {
        Ext.Msg.confirm(
            "Application Update",
            "This application has just successfully been updated to the latest version. Reload now?",
            function (buttonId) {
                if (buttonId === 'yes') {
                    window.location.reload();
                }
            }
        );
    }
});