﻿
Ext.define("com.inbooks.view.Profile", {
extend: "Ext.form.Panel",
xtype: 'profile',
config: {
    //id:'id-vw-profile',
    scrollable: true,
    style: 'background-color: white;',
    items: [
           
        {/*Spacer decoration*/
            xtype: 'spacer',
            height: '50px'
        },
        {/*Fields*/
            xtype: 'fieldset',
            defaults: {
                labelWidth: '40%'
            },
            layout:
            {
                type: 'vbox',
                pack: 'center'
            },
            items:
            [
                {/*Device Id*/
                    xtype: 'textfield',
                    name: 'txtdeviceuuid',
                    disabled: true,
                    hidden: true,
                    label: 'Device #.',
                    placeHolder: '',
                    style: 'background-color: #ffffff; font-size: 14px',
                    listeners: {
                        initialize: function (field) {
                            try {
                                field.setValue(device.uuid);
                            }
                            catch (e) { }
                        }
                    }
                },
                {/*email*/
                    xtype: 'emailfield',
                    name: 'txtemailid',
                    label: 'Email',
                    id: 'usrEmail',
                    required: true,
                    placeHolder: '',
                    autoCapitalize: false,
                    clearIcon: true,
                    style: 'background-color: #ffffff; font-size: 14px',
                    listeners: {
                        initialize: function (field) {
                            try { field.setValue(Ext.JSON.decode(localStorage.getItem('user')).Email); } catch (e) { }
                        }
                    }
                },
                {/*User contact number*/
                    xtype: 'textfield',
                    name: 'txtcontactnumberid',
                    label: 'Contact Number',
                    id: 'usrContactNo',
                    component: { type: 'tel' },
                    placeHolder: '',
                    autoCapitalize: false,
                    required: true,
                    clearIcon: true,
                    style: 'background-color: #ffffff; font-size: 14px',
                    listeners: {
                        initialize: function (field) {
                            try { field.setValue(Ext.JSON.decode(localStorage.getItem('user')).MobilePhone); } catch (e) { }
                        }
                    }
                }
            ]
        },
        {/*Spacer decoration*/
            xtype: 'spacer',
            height: '20px'
        },
        {/*Submit button*/
            xtype: 'panel',
            defaults: {
                width: '100%',
                height: '40px'
            },
            layout: {
                type: 'hbox',
                pack: 'center'
            },
            style:'padding-left:0.8%;padding-right:0.8%',
            items: [
                        {
                            xtype: 'button',
                            name: 'btnChangeProfile',
                            id: 'btnchangeprofile',
                            width: "100%",
                            action: 'btnChangeProfile',
                            text: 'Change Profile',
                            ui: 'confirm' //Blue Theme
                        }                               
                    ]
                }
            ]
        },
        initialize: function () {
        console.log("Profile view initialize")
        this.callParent(arguments);
        this.on('painted', this.painted);

        },
        painted: function () {
        console.log('Profile view painted');
        Ext.getCmp("usrEmail").setLabel(g_l['lbl0018']);
        Ext.getCmp("usrContactNo").setLabel(g_l['lbl0045']);
        Ext.getCmp("btnchangeprofile").setText(g_l['lbl0046']);
    }
});





