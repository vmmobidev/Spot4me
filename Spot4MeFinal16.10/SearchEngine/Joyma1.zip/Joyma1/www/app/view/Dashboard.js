﻿Ext.define('com.inbooks.view.Dashboard', {
    extend: 'Ext.Panel',
    xtype: 'dashboard', 
    config: {
        //scrollable: true,
        style: "background-color: white",
        items: [
            {
                xtype: 'panel',
                id: 'id-vw-dashboard',
                html: [
                   '<div align="center">',
                   '<div class="vm-grad" id="btnBadge" style="display:visible"></div>',
                   '<div class="vm-log" id="dvLstLogin" style="display:visible"></div>',
                   '<div id="div_Ma_Logo" class="dashboard-ma-face-logo-7-10"><img id="imgMaFace" src="resources/images/joyma-logo-face-100x80.png"/> </div>',
                   '<div id="divActive_catalog_Text" class="dashboard-menu-font activeCatalog-res-600-900">Active<br/>Catalog</div>',
                   '<div id="div_invite_FriendsText" class="dashboard-menu-font inviteFriends-res-600-900">Invite<br/>Friends</div>',
                   '<div id="divMy_bookshelf_Text" class="dashboard-menu-font myBookshelf-res-600-900">My<br/>Bookshelf</div>',
                   '<div id="div_reachus_Text" class="dashboard-menu-font reachUs-res-600-900">Reach<br/>Us</div>',
                   //'<div id="div_donation_Text" class="dashboard-menu-font donate-res-600-900">Donate</div>',

                   '<img src="resources/images/dashboard-wotxt.png" id="imgpotrait" alt="hp" width="600px" height="900px" border="0" usemap="#Map"/>',


                   '<map name="Map" id="Map">',
                   '<area class="dash-img-map" shape="circle" coords="303,823,29" id="settings" />', //Settings
                   '<area class="dash-img-map" shape="poly" coords="395,216,469,216,505,280,469,344,394,342,359,279" id="bookshelf"/>', //My Bookshelf
                   '<area class="dash-img-map" shape="circle" coords="290,393,66" id="invite"/>', //Invite
                   '<area class="dash-img-map" shape="poly" coords="188,76,295,77,347,171,295,262,187,262,134,171"  id="catalog"/>', //Active catalog
                   //'<area class="dash-img-map" shape="poly" coords="318,502,382,503,416,558,384,614,319,615,286,557" id="donation" />' ,     //donate
                   '<area class="dash-img-map" shape="circle" coords="414,822,29"  id="logout"/>', //Active Logout
                   '<area class="dash-img-map" shape="circle" coords="493,475,60" id="reachus"/>', //Reach us
                   '</map></div>'].join(''),
                listeners:
                [
                   {
                       element: 'innerElement',
                       event: 'tap',
                       fn: function (cmp, index, target, record, e, eOpts) {

                           com.inbooks.app.destroyHeaderButtons();
                           var view = cmp.delegatedTarget.id;
                           if(view == "logout"){
                               com.inbooks.app.getController("HeaderController").btnLogout_Click();
                           }
                           else{
                               com.inbooks.app.g_viewportCaller = view;
                               com.inbooks.classes.Helpers.pushNavHistory(view);
                               Ext.Viewport.setActiveItem({ xtype: view});
                           }
                       },
                       delegate: '.dash-img-map'
                   },
                    {
                        element: 'element',
                        event: 'tap',
                        fn: function (cmp, index, target, record, e, eOpts) {
                            com.inbooks.app.destroyHeaderButtons();
                            var view = cmp.delegatedTarget.id;
                            if(view == "logout"){
                                com.inbooks.app.getController("HeaderController").btnLogout_Click();
                            }
                            else{
                                com.inbooks.app.g_viewportCaller = view.split('_')[1];
                                com.inbooks.classes.Helpers.pushNavHistory(view.split('_')[1]);
                                Ext.Viewport.setActiveItem({ xtype: view.split('_')[1]});
                            }
                        },
                        delegate: '.dashboard-menu-font'
                    }
                ]
            }
        ]
    },
    initialize: function () {
        console.log("Dashboard view initialize");
        this.callParent(arguments);
        this.on('painted', this.painted);
    },
        
    painted: function (cmp) {
        console.log('Dashboard View - painted');

        noty(
            {
                "text": '<div class="vm-notyDecorator vm-notyDisclaimer ">' + g_m['msg0065'] + '</div>',
                "layout": "bottom",
                "type": "information",      //skyblue color
                "modal": false ,
                animation: {
                    open: {height: 'toggle'},
                    close: {height: 'toggle'},
                    easing: 'swing',      //swing or linear(constant speed)
                    speed: 400 // opening & closing animation speed
                },
                closeWith: ["null"]  ,         //don't close the noty
                callback:{
                    afterShow:function () {
                        var times = 3;
                        while(times != 0){         //blink 3 times
                            this.$bar.fadeOut(400).fadeIn(400);
                            times-=1;
                        }
                    }
                }
            });
        com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[2];
        com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[2]);
        var settingsArea = $("#settings");
        var bookshelfArea = $("#bookshelf");
        var inviteArea = $("#invite");
        var catalogArea = $("#catalog");
        var logoutArea = $("#logout");
        var reachusArea = $("#reachus");
        //var donateArea = $("#donation");

        //var settingsLabel = $("#div_settings_Text");
        var activeCatalogLabel = $("#divActive_catalog_Text");
        var myBookshelfLabel = $("#divMy_bookshelf_Text");
        var reachUsLabel = $("#div_reachus_Text");
        var inviteFriendsLabel = $("#div_invite_FriendsText");
        var dashboardImage = $("#imgpotrait");
        //var donateLabel = $("#div_donation_Text");
        var maFaceLogo = $("#div_Ma_Logo");

        var deviceScreenWidth = window.innerWidth;
        var deviceScreenHeight = window.innerHeight;
        var isLandscapeOrientationOn = localStorage.getItem("LandscapeOrientation");

        if(Ext.os.deviceType == "Phone"){
            $(".vm-notyDisclaimer").css('font-size','10px');
            console.log('resizing: ' + deviceScreenWidth + ',' + deviceScreenHeight);
            dashboardImage.attr('src',"resources/images/dashboard-5inch.png");

            dashboardImage.attr('style','max-width:100%;max-height:100%;');

            console.log('new size: ' + dashboardImage.attr('width') + ',' + dashboardImage.attr('height'));

            activeCatalogLabel.removeClass('activeCatalog-res-600-900').addClass('activeCatalog-res-480-800');
            //settingsLabel.removeClass('settings-res-600-900').addClass('settings-res-480-800');
            inviteFriendsLabel.removeClass('inviteFriends-res-600-900').addClass('inviteFriends-res-480-800');
            myBookshelfLabel.removeClass('myBookshelf-res-600-900').addClass('myBookshelf-res-480-800');
            reachUsLabel.removeClass('reachUs-res-600-900').addClass('reachUs-res-480-800');
            //donateLabel.removeClass('donate-res-600-900').addClass('donate-res-480-800');
            maFaceLogo.removeClass('dashboard-ma-face-logo-7-10').addClass('dashboard-ma-face-logo-5');

        }else if(Ext.os.deviceType == "Tablet" && ((deviceScreenWidth > 600 && deviceScreenHeight > 900)||(deviceScreenWidth > deviceScreenHeight ))){
            console.log('resizing 10 inch: ' + deviceScreenWidth + ',' + deviceScreenHeight);
            console.log(dashboardImage);
            dashboardImage.attr('src',"resources/images/dashboard-10inch.png").load(function(){
                    dashboardImage.attr("width","");
                    dashboardImage.attr("height","");
            });
            //dashboardImage.attr('style','max-width:100%;max-height:100%;');
            console.log("LANDSCAPE ORIENTATION:  " + isLandscapeOrientationOn) ;
            //var newWidth = (isLandscapeOrientationOn == 1)?("100%"): ("100%");
            //var newHeight = (isLandscapeOrientationOn == 1)?("100%"): ("100%");

            console.log('new size 10 inch: ' + dashboardImage.attr('width') + dashboardImage.attr('height'));
            activeCatalogLabel.removeClass('activeCatalog-res-600-900 activeCatalog-res-480-800').addClass('activeCatalog-res-800-1280');
            //settingsLabel.removeClass('settings-res-600-900 settings-res-480-800').addClass('settings-res-800-1280');
            inviteFriendsLabel.removeClass('inviteFriends-res-600-900 inviteFriends-res-480-800').addClass('inviteFriends-res-800-1280');
            myBookshelfLabel.removeClass('myBookshelf-res-600-900 myBookshelf-res-480-800').addClass('myBookshelf-res-800-1280');
            reachUsLabel.removeClass('reachUs-res-600-900 reachUs-res-480-800').addClass('reachUs-res-800-1280');
            //donateLabel.removeClass('donate-res-600-900 donate-res-480-800').addClass('donate-res-800-1280');

        }
        activeCatalogLabel[0].innerText = g_l['lbl0037'];
        //settingsLabel[0].innerText = g_l['lbl0039'];
        inviteFriendsLabel[0].innerText = g_l['lbl0040'];
        myBookshelfLabel[0].innerText = g_l['lbl0038'];
        reachUsLabel[0].innerText = g_l['lbl0041'];
        //donateLabel[0].innerText = g_l['lbl0051'];
        if(Ext.os.deviceType == "Phone"){
            $(".dashboard-menu-font").css('font-size','10px');
            catalogArea.attr('coords','100,60,158,60,188,110,158,160,100,162,72,111');
            logoutArea.attr('coords','223,458,16');
            bookshelfArea.attr('coords','214,136,252,137,271,170,253,205,213,203,194,169');
            //donateArea.attr('coords','172,290,206,290,223,318,206,350,172,348,155,320');
            reachusArea.attr('coords','265,275,32');
            inviteArea.attr('coords','156,231,35');
            settingsArea.attr('coords','164,458,16');
        }else if(Ext.os.deviceType == "Tablet" && ((deviceScreenWidth > 600 && deviceScreenHeight > 900)||(deviceScreenWidth > deviceScreenHeight ))){

            catalogArea.attr('coords','250,154,391,154,464,279,393,402,251,402,178,280');
            settingsArea.attr('coords','405,1150,37');
            bookshelfArea.attr('coords','526,340,626,340,673,426,626,510,528,510,478,426');
            reachusArea.attr('coords','657,682,80');
            //donateArea.attr('coords','425,705,509,705,554,796,511,865,425,865,381,798');
            inviteArea.attr('coords','386,574,88');
            logoutArea.attr('coords','552,1150,39');
        }
        var ls_AllMasters = Ext.JSON.decode(localStorage.getItem("AllMasterData"));
        console.log("ls_AllMasters - " + ls_AllMasters);
        //Load my bookshelf items
        com.inbooks.classes.Helpers.loadMyBookshelf();
        if (ls_AllMasters == null || ls_AllMasters == undefined) {
            console.log("Fire - AllMasters");
            //show the loading mask
            setTimeout(function(){
                Ext.Viewport.setMasked({
                    xtype: 'loadmask',
                    indicator: true,
                    message: ''+ g_m['msg0040']+''
                });
            }, 50);
            com.inbooks.app.fireEvent('LoadAllMasters', cmp);
        }
    }        
    
});