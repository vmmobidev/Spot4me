Ext.define('com.inbooks.view.Reader', {
    extend: 'Ext.Container',
    requires: [
        'Ext.SegmentedButton', 'Ext.Carousel'
    ],
    xtype: 'reader',
    config: {
        id: 'id-vw-reader',
        //itemId: 'id-vw-reader',
        layout: 'fit',
        fullscreen: true,
        style: "background-color: white",
        items: [
          {
              xtype: 'header',
              docked: 'top'
          },
          {
            xtype: 'footer',
            docked: 'bottom'
          },
          {
            xtype: 'panel',
            id: 'id-carousel-panel',
            items: [
                {
                    xtype: 'tabbar',
                    title: '',
                    id: 'carouselTitleBar',
                    ui: 'plain',
                    cls: 'ui-bar ui-bar-e',
                    docked: 'bottom',
                    height: 50,
                    items: [
                        {
                            xtype: 'button',
                            disabled: true,
                            top: 2,
                            left: 5,
                            id: 'btnPreviousPage',
                            text: '<i class="icon-chevron-left"></i>',
                            action: 'btnPreviousPage',
                            height: 45,
                            width: 50
                        },
                        {
                            xtype: 'segmentedbutton',
                            allowMultiple: true,
                            id: 'btnBookmark',
                            items: [
                                {
                                    text: '<i style="color: red;" class="icon-2x icon-tags"></i>',
                                    id: 'id-Bookmarks'
                                }
                            ],
                            top: 2,
                            right: 70,
                            height: 45,
                            width: 50
                        },
                        {
                            xtype: 'button',
                            id: 'btnNextPage',
                            top: 2,
                            right: 5,
                            text: '<i class="icon-chevron-right"></i>',
                            action: 'btnNextPage',
                            height: 45,
                            width: 50
                        }
                    ]
                },
                {
                    //Reference: http://stackoverflow.com/questions/13383454/sencha-touch-2-0-carousel-image-resolution
                    xtype: 'carousel',
                    indicator: false,
                    height: '100%',
                    itemId: 'BookReaderCarousel',
                    id: 'carousel-reader',
                    defaults: {
                        styleHtmlContent: true,
                        listeners: [
                            {
                                 element: 'innerElement',
                                 delegate: 'img',
                                 event: 'pinch',
                                 fn: function (carouselItem) {
                                     console.log("Carousel item pinch-start");
                                     com.inbooks.app.fireEvent('CarouselItemPinch', carouselItem, this);
                                     console.log("Carousel item pinch-end");
                                 }
                            },
                            {
                                 element: 'innerElement',
                                 delegate: 'img',
                                 event: 'pinchstart',
                                 fn: function (carouselItem) {
                                     console.log("Carousel item pinchStart-start");
                                     com.inbooks.app.fireEvent('CarouselItemPinchStart', carouselItem, this);
                                     console.log("Carousel item pinchStart-end");
                                 }
                            },
                            {
                                 element: 'innerElement',
                                 delegate: 'img',
                                 event: 'pinchend',
                                 fn: function (carouselItem) {
                                     console.log("Carousel item pinchend-start");
                                     com.inbooks.app.fireEvent('CarouselItemPinchEnd', carouselItem, this);
                                     console.log("Carousel item pinchend-end");
                                 }
                            },
                            {
                                element: 'element',
                                delegate: '.carousel-images',
                                event: 'doubletap',
                                fn : function() {
                                    com.inbooks.classes.Helpers.GotoPage();
                                }
                            },
                            {
                                element: 'element',
                                delegate: '.carousel-images',
                                event: 'tap',
                                fn : function() {
                                    try{
                                        Ext.getCmp('goto-page-slider').hide();
                                    }
                                    catch(e){ console.log(e.message) }
                                }
                            }
                        ]
                    },
                    listeners: {
                        initialize: function (cmp) {
                            console.log("Carousel initialize - Start");
                            cmp = Ext.getCmp('carousel-reader');
                            /*//show the loading mask
                            setTimeout(function(){
                                Ext.Viewport.setMasked({
                                    xtype: 'loadmask',
                                    indicator: true,
                                    message: g_m['msg0049']
                                });
                            }, 100);*/

                            //console.log(com.inbooks.app.g_pages);
                            Ext.each(com.inbooks.app.g_pages, function (item, index) {
                                var itm = { html: '<div class="carousel-images"><img align="middle" style="width: 100%; height: 100%" id="imgPage_' + index + '" src="resources/images/spacer.gif" />' + '</div>',
                                            scrollable: 'both'
                                            /*listeners : {
                                                element : 'element',
                                                delegate: '.carousel-images',
                                                doubletap : function() {
                                                    com.inbooks.classes.Helpers.GotoPage();
                                                },
                                                tap : function() {
                                                    try{
                                                        Ext.getCmp('goto-page-slider').hide();
                                                    }
                                                    catch(e){ console.log(e.message) }
                                                }
                                            }*/
                                          };
                                cmp.add(itm);
                            });
                            console.log("Carousel initialize - Start");
                        },
                        painted: function (cmp) {
                            console.log("Carousel painted - start");
                            //show the loading mask
                            setTimeout(function(){
                                Ext.getCmp('carousel-reader').items.items[0].setMasked({
                                //Ext.Viewport.setMasked({
                                    xtype: 'loadmask',
                                    indicator: true,
                                    message: g_m['msg0049']
                                });
                            }, 10);
                            //Set the first page image of the carousel
                            var i = $('#imgPage_0');
                            var url = com.inbooks.classes.Helpers.getPageImageUrl(0);
                            //Set or reset the bookmark icon
                            com.inbooks.classes.Helpers.setBookmarkIcon();
                            //Set the title of the book
                            $("#divTitle").empty().html(com.inbooks.app.g_bookTitle);
                            com.inbooks.app.g_prefetchedImgs = [];
                            i.attr('src', url)
                                .load(function () {
                                    if(localStorage.getItem('ReadOffline')==1) {
                                        var bookCode = (com.inbooks.app.g_selectedBookDetails.BookCode == undefined)?com.inbooks.app.g_selectedBookDetails.BOOKCODE:com.inbooks.app.g_selectedBookDetails.BookCode;
                                        var imgCanvas = document.createElement("canvas"),
                                            imgContext = imgCanvas.getContext("2d");
                                        imgCanvas.width = i.width();
                                        imgCanvas.height = i.height();
                                        var flag = false;
                                        Ext.each(com.inbooks.app.g_imginfo,function(item,index){
                                            if(item.PageNum==0 && item.BookCode==bookCode){
                                                flag=true;
                                                return false;
                                            }
                                        });
                                        if(!flag) {
                                            imgContext.drawImage(i[0], 0, 0, i.width(), i.height());
                                            var imgData = {Source: imgCanvas.toDataURL("image/jpeg"),PageNum:0, BookCode: bookCode };
                                            com.inbooks.app.g_imginfo.push(imgData);
                                        }

                                        // Save as JSON in localStorage
                                        //localStorage.setItem("imgInfo", Ext.JSON.encode(com.inbooks.app.g_imginfo));
                                        var offlineStore= Ext.getStore('OfflineReaderStore');
                                        offlineStore.clearData();
                                        offlineStore.sync();
                                        offlineStore.setData(com.inbooks.app.g_imginfo);
                                        offlineStore.sync();
                                    }
                                    //var i_idx;
                                    console.log("Adjusting Image Size based on first item in the image array (start)")
                                    i.attr('height', '100%');
                                    i.attr('width', '100%');
                                    setTimeout(function () {
                                        Ext.getCmp('carousel-reader').items.items[0].setMasked(false);
                                        //Ext.Viewport.setMasked(false);
                                    }, 500);
                                    //Prefetch the next 5 pages in advance
                                    //TODO: by senthil
                                    com.inbooks.classes.Helpers.prefetchSubsequentPages();
                                    console.log("Image Source" + i.attr('src'))
                                })
                                .error(function () {
                                    console.log("Error loading " + url);
                                    //Reset to old image is required? because the previous image failed so the old image should have been there already!
                                    i.attr('src', "resources/images/spacer.gif");
                                    com.inbooks.classes.Helpers.notifyError(g_m['msg0006'], true);
                                    console.log("Removing mask");
                                    setTimeout(function () {
                                        //During error no need to check for condition instead simply remove the mask
                                        //console.log("Removing mask from Browse Controller inside showCarousalPageNum() with i.attr('src') == undefined, error");
                                        Ext.getCmp('carousel-reader').items.items[0].setMasked(false);
                                        //Ext.Viewport.setMasked(false);
                                    }, 150);

                                });
                            this.up('panel').getItems().items[0].setTitle((this.activeIndex+1) + " of " + this.getItems().length + " pages");

                            setTimeout(function(){
                                Ext.getCmp('carousel-reader').items.items[0].setMasked(false);
                                //Ext.Viewport.setMasked(false);
                            }, 1000);

                            com.inbooks.app.g_minWidth = window.innerWidth;//document.getElementById("imgPage_"+(Ext.getCmp('carousel-reader').activeIndex)).clientWidth;
                            com.inbooks.app.g_minHeight = window.innerHeight-175;//document.getElementById("imgPage_"+(Ext.getCmp('carousel-reader').activeIndex)).clientHeight;
                            console.log("Carousel painted - end");
                        },
                        resize: function (o, m, component) {
                            console.log('Carousel resize');
                            $('#imgPage_'+Ext.getCmp('carousel-reader').activeIndex).css('width', window.innerWidth);
                            $('#imgPage_'+Ext.getCmp('carousel-reader').activeIndex).css('height', (window.innerHeight-175));//Header=50, Footer=50, TitleBar=50, PageNavigator=50, Total=175
                        }
                    }
                },
                {
                    html: '<div id="divTitle" class="ellipsisDot"></div><div class="vm-bookmarks-before-select" id="id-bookmarks"></div>',
                    cls: 'ui-bar-e',
                    docked: 'top',
                    itemId: 'BookTitle',
                    height: 25,
                    listeners: [
                        {
                            element: 'element',
                            delegate: '#id-bookmarks',
                            event: 'tap',
                            fn: function (cmp, data, target, ev) {
                                com.inbooks.classes.Helpers.processBookmarkIconTap(data);
                            }
                        }
                    ]
                }
            ]//,
            /*listeners: {
                resize: function (o, m, component) {
                    console.log('carousel outer panel resize start');

                    console.log('carousel outer panel resize end');
                }
            }*/
          }
        ]
    },
    initialize: function () {
        console.log("Reader view initialize");
        this.callParent(arguments);
        this.on('painted', this.painted);
    },
    painted: function (browse) {
        console.log('Reader view painted start');
        //Ext.getCmp('id-footer').setActiveTab(1);
        com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[7];
        com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[7]);
    }
});