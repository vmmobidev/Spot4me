Ext.define("com.inbooks.view.Books", {
    extend: "Ext.Panel",
    xtype: 'books',
    requires: [
        'com.inbooks.store.BooksStore',
        'Ext.dataview.List'
    ],
    config: {
        id: 'id-vw-books',
        //scrollable: true,
        layout: 'fit',
        items: [
            {
                xtype: 'header',
                docked: 'top'
            },
            {
                xtype: 'footer',
                docked: 'bottom'
            },
            {
                xtype: 'list',
                ui: 'round',
                title: 'Books',
                cls: "booksList",
                itemId: 'list-books',
                store: 'BooksStore',
                id: 'tplBookLst',
                grouped: true,
                //layout: 'fit',
                //height: window.innerHeight-100,
                onItemDisclosure: true,
                itemTpl: new Ext.XTemplate(
                         [
                            '<div>'
                            , '<span><img class="catalog" id={ID} src=' + com.inbooks.app.g_BookThumbnailUrl + '{BOOKCODE}/{CoverPageThumbUrl}></img></span>'
                            , '<span style="width: 70%; position: absolute;">'
                            , '<p class="ellipsisDot line1" width="50%">&emsp;{NAME}</p>'
                            , '<p class="ellipsisDot line2" width="50%">&emsp;Author: {AUTHOR}</p>'
                            , '<p class="ellipsisDot line2" width="50%">&emsp;Summary: {Summary}</p>'
                            , '<p class="ellipsisDot line2" width="50%">&emsp;Proposed by: {ProposedUser}</p>'
                            , '<p class="ellipsisDot line2" width="50%">&emsp;Publisher: {PUBLISHER}</br>&emsp;Year: {PUBLISHYEAR}&nbsp;<button class="btn btn-success btn-mini btnAddtoBookshelf" id="idaddtobookshelf_{BOOKCODE}"><i class="icon-plus-sign"></i>&nbsp;bookshelf</button> &nbsp;<button style="visibility:hidden;" class="btn btn-mini btnAddtoBookshelf" id="idpreview_{BOOKCODE}"><i class="icon-eye-open"></i>&nbsp;preview</button>&nbsp;<button style="visibility:hidden;" class="btn btn-primary btn-mini btnAddtoBookshelf" id="idbuy_{BOOKCODE}"><i class="icon-money"></i>&nbsp;buy</button></p>'
                            , '</span>'
                            , '</div>'
                         ].join('')),
                listeners: [
                    {
                        element: 'element',
                        delegate: 'button',
                        event: 'tap',
                        fn: function (cmp, data, target, ev) {
                            if (!(cmp.delegatedTarget.disabled)) {
                                //show the loading mask
                                Ext.Viewport.setMasked({
                                    xtype: 'loadmask',
                                    indicator: true,
                                    message: g_m['msg0052']
                                });
                                var bookCode = data.id.split('_')[1];  //get the book code for the book for which the button is tapped
                                if (data.id.split('_')[0] == "idpreview") {   // if the button is preview button
                                    var cmp = {}, options = {},data;
                                    var allData = Ext.getStore('BooksStore').data.all ;     //get all books list from store
                                    Ext.each(allData,function(item,i){         //traverse the book list
                                            if(item.data.BOOKCODE == bookCode) {
                                                data = item;                    // set the data for the current book
                                                return;
                                            }
                                    });
                                    //call the reader for that particular book when preview is clicked
                                    com.inbooks.app.getController("BooksController").showReader(cmp, data, options);
                                }
                                else{
                                    com.inbooks.classes.Helpers.addToBookshelf(bookCode); // else if the buttons pressed are add to bookshelf or Buy, add the book to bookshelf
                                }

                            }
                        }
                    }
                ]
            }
        ]
    },
    initialize: function (mybooks) {
        console.log("Books View initialize");
        this.callParent(arguments);
        try {
            var masterData = Ext.JSON.decode(localStorage.getItem("AllMasterData"));
            com.inbooks.app.g_catalogs = masterData.catalogs;
            com.inbooks.app.g_books = masterData.books;
            var store = Ext.getStore('BooksStore');
            store.setData(com.inbooks.app.g_books);
        }
        catch (e) { }
        this.on('painted', this.painted);
    },
    painted: function () {
        console.log('Books View painted - start');
        Ext.getCmp('id-footer').setActiveTab(1);
        com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[4];
        com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[4]);
        //set the template after the page is painted in order to get the values of global variables for labels and messages
        Ext.getCmp('tplBookLst').setItemTpl(new Ext.XTemplate(
            [
                '<div>'
                , '<span><img class="catalog" id={ID} src=' + com.inbooks.app.g_BookThumbnailUrl + '{BOOKCODE}/{CoverPageThumbUrl}></img></span>'
                , '<span style="width: 70%; position: absolute;">'
                , '<p class="ellipsisDot line1" width="50%">&emsp;{NAME}</p>'
                , '<p class="ellipsisDot line2" width="50%">&emsp;&nbsp;' + g_l['lbl0027'] + ': {AUTHOR}</p>'
                , '<p class="ellipsisDot line2" width="50%">&emsp;&nbsp;' + g_l['lbl0042'] + ': {Summary}</p>'
                , '<p class="ellipsisDot line2" width="50%">&emsp;&nbsp;' + g_l['lbl0043'] + ': {ProposedUser}</p>'
                , '<p class="ellipsisDot line2" width="50%">&emsp;&nbsp;' + g_l['lbl0028'] + ': {PUBLISHER}</br>&emsp;&nbsp;' + g_l['lbl0029'] + ': {PUBLISHYEAR}&nbsp;<button class="btn btn-success btn-mini btnAddtoBookshelf" id="idaddtobookshelf_{BOOKCODE}"><i class="icon-plus-sign"></i>&nbsp;' + g_l['lbl0030'] + '</button>&nbsp;<button style="visibility:hidden;" class="btn btn-mini btnAddtoBookshelf" id="idpreview_{BOOKCODE}"><i class="icon-eye-open"></i>&nbsp;' + g_l['lbl0052'] + '</button>&nbsp;<button style="visibility:hidden;" class="btn btn-primary btn-mini btnAddtoBookshelf" id="idbuy_{BOOKCODE}"><i class="icon-money"></i>&nbsp;' + g_l['lbl0053'] + '</button></p>'
                , '</span>'
                , '</div>'
            ].join('')));
        Ext.each(com.inbooks.app.g_bookshelf, function (obj, index, e) {
            $("#idaddtobookshelf_" + obj.BookCode).removeClass("btn-success");
            $("#idaddtobookshelf_" + obj.BookCode).prop("disabled", "disabled");
            $("#idbuy_" + obj.BookCode).removeClass("btn-primary");
            $("#idbuy_" + obj.BookCode).prop("disabled", "disabled");
        });
        console.log('Books View painted - end');
    }
});