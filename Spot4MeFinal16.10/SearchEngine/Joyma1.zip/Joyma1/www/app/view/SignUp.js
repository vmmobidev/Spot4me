﻿Ext.define("com.inbooks.view.SignUp", {//Start extend
extend: "Ext.form.Panel",
xtype: 'signup',
requires: [''],
config: {    
    id: 'id-vw-signup',
    scrollable: true,
    items: [                        
            {//spacer decoration
                xtype: 'spacer',
                height: '50PX'
            },                              
            { //logo image
                xtype: 'panel',
                id: 'signuplogo',
                html: '<div align="center"><img src="resources/images/joyma-logo-face-100x80.png"></img><div class="vm-login-logo-txt">JoyMa</div></div>'
            },                            
            { //spacer decoration
                xtype: 'spacer',
                height: '100PX'
            },                                
            { //fields
                xtype: 'fieldset',
                defaults:
                    {
                        labelWidth: '40%'
                    },
                items:
                    [ 
                        { /*Referred by*/
                            xtype: 'textfield',
                            disabled:true,
                            value:'Sam',
                            //html: 'Referred By: ' + com.inbooks.app.g_referredby,
                            label: 'Referred By',
                            id:'txtReferredBy',
                            //required: true,
                            style: 'background-color: #ffffff; font-size: 14px'
                        },                                           
                        {/*Full Name*/
                            xtype: 'textfield',
                            name: 'txtFullname',
                            id:'txtFullname',
                            label: 'Full Name',
                            placeHolder: '',
                            autoCapitalize: true,
                            required: true,
                            clearIcon: true,
                            style: 'background-color: #ffffff; font-size: 14px'
                        },                       
                        {/*Gender*/
                                xtype: 'selectfield',
                                name: 'drpGender',
                                id:'drpGender',
                                label: 'Gender',
                                placeHolder: '',
                                autoCapitalize: false,
                                //required: true,
                                clearIcon: true,
                                style: 'background-color: #ffffff; font-size: 14px',
                                options: [
                                    { text: 'Male', value: 'male' },
                                    { text: 'Female', value: 'Female' }
                            ]
                        },
                        {/*Username*/
                            xtype: 'textfield',
                            name: 'txtUsername',
                            id:'txtUserName',
                            label: 'Username',
                            placeHolder: '',
                            autoCapitalize: false,
                            required: true,
                            clearIcon: true,
                            style: 'background-color: #ffffff; font-size: 14px'
                        },
                        {/*Password*/
                            xtype: 'passwordfield',
                            name: 'txtPassword',
                            id:'txtPassword',
                            label: 'Password',
                            placeHolder: '',
                            autoCapitalize: false,
                            autoComplete: false,
                            required: true,
                            clearIcon: true,
                            style: 'background-color: #ffffff; font-size: 14px'
                        },                         
                        {/*Mobile*/
                            xtype: 'numberfield',
                            name: 'txtMobile',
                            id:'txtMobile',
                            label: 'Mobile',
                            placeHolder: '',
                            autoCapitalize: false,
                            required: true,
                            clearIcon: true,
                            style: 'background-color: #ffffff; font-size: 14px'
                        },
                        {/*email*/
                            xtype: 'emailfield',
                            name: 'txtEmail',
                            id:'txtEmail',
                            label: 'Email',
                            placeHolder: '',
                            autoCapitalize: false,
                            required: true,
                            clearIcon: true,
                            style: 'background-color: #ffffff; font-size: 14px'
                        },                                                        
                  ]
            }, 
            { // Space decoration
                xtype: 'spacer',
                height: '10px'
            },
            /*Terms & Conditions*/
            {
                layout:
                    {
                        type: 'hbox',
                        pack: 'center'
                    },
                items:
                    [
                        {
                            html: '<i id="chkTermsAndConditions" class="icon-check-empty icon-2x"></i>',
                            cls: 'vm-customCheckBox',
                                
                            listeners: { 
                                tap: {
                                    fn: function (event, el) {
                                        hideKeyboard(); // Calling this function for resigning the keyboard
                                        if (el.className.match("empty")) {
                                            el.setAttribute('class', 'icon-check icon-2x vm-iconClassCheckBox');
                                            Ext.getCmp('btnRegister').setDisabled(false);
                                        }
                                        else {
                                            el.setAttribute('class', 'icon-check-empty icon-2x');
                                            Ext.getCmp('btnRegister').setDisabled(true);
                                        }
                                    },
                                    element: 'element',
                                    delegate: '#chkTermsAndConditions'
                                }
                            }
                        },
                        {// Space decoration
                            xtype: 'spacer',
                            width: '4px'
                        },
                        {
                            html: ['<u style="color: blue; font-size: 12px">',
                            '<div style="padding-top: 15px;" id="divTerms">',
                            'I understand and agree with JoyMa Terms & Conditions',
                            '</div>',
                            '</u>'].join(''),
                            style: 'top: 25%',
                            id:'divTermsnConditions',
                            listeners:
                            {
                                tap:
                                {
                                    delegate: 'div',
                                    element: 'element',
                                    fn: function (terms) {
                                        /*if (com.inbooks.app.terms == null) {
                                            com.inbooks.app.terms = Ext.Viewport.add(Ext.create('com.inbooks.view.TermsAndConditions',
                                            {
                                                hidden: true
                                            }));
                                        }
                                        com.hpvideobook.app.terms.show();*/
                                            
                                        //Ext.Viewport.add(Ext.create('com.inbooks.view.TermsAndConditions',{hidden: true})).show();
                                    }
                                }
                            }
                        }
                 ]
            },
            {// Space decoration
                xtype: 'spacer',
                height: '50px'
            },
            {/*buttons*/
                xtype: 'panel',
                defaults: {
                    width: '100%',
                    height: '50px'
                },
                layout: {
                    type: 'vbox',
                    pack: 'center'
                },
                style:'padding-left:0.8%;padding-right:0.8%',
                items: [
                    { /*Register button*/
                        xtype: 'button',
                        name: 'btnRegister',
                        id:'btnRegister',
                        disabled:true,
                        action: 'btnRegisterClick',
                        text: 'Submit',
                        ui: 'confirm'
                            
                    }, 
                    {/*Spacer decoration*/
                        xtype: 'spacer',
                        height: '5px'
                    },
                    {/*Cancel button*/
                        xtype: 'button',
                        name: 'btnCancel',
                        id: 'btnCancel',
                        action: 'btnCancelClick',
                        text: 'Cancel',
                        ui: 'normal' 
                    },
                    {/*Spacer decoration*/
                        xtype: 'spacer',
                        height: '20px'
                    }                                 
                ] 
            }
        ]
    }, 
    initialize: function () {
        console.log("SignUp view initialize");
        this.callParent(arguments);
        this.on('painted', this.painted);       
    },
    painted: function () {
            console.log('SignUp view painted');
            $.noty.closeAll();
            com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[1];
            com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[1]);
            Ext.getCmp("txtReferredBy").setLabel( g_l['lbl0012']);
            Ext.getCmp("txtFullname").setLabel( g_l['lbl0013']);
            Ext.getCmp("drpGender").setLabel( g_l['lbl0014']);
            Ext.getCmp("txtUserName").setLabel( g_l['lbl0015']);
            Ext.getCmp("txtPassword").setLabel( g_l['lbl0016']);
            Ext.getCmp("txtMobile").setLabel( g_l['lbl0017']);
            Ext.getCmp("txtEmail").setLabel( g_l['lbl0018']);
            Ext.getCmp("drpGender").setOptions( [{text: ''+g_l['lbl0019']+'',  value: 'male'},{text: ''+g_l['lbl0020']+'', value: 'Female'}]);
            Ext.getCmp("divTermsnConditions").setHtml(['<u style="color: blue; font-size: 12px">',
                '<div style="padding-top: 15px;" id="divTerms">',
                ''+ g_l['lbl0021']+'',
                '</div>',
                '</u>'].join(''));
            Ext.getCmp("btnRegister").setText(g_l['lbl0022']);
            Ext.getCmp("btnCancel").setText(g_l['lbl0023']);
            Ext.getCmp("signuplogo").setHtml('<div align="center"><img src="resources/images/joyma-logo-face-100x80.png"></img><div class="vm-login-logo-txt">' + g_l['lbl0049'] + '</div></div>');
     }
});





