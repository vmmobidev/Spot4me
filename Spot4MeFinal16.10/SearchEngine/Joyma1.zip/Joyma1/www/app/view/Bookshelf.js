﻿Ext.define("com.inbooks.view.Bookshelf", {
    extend: "Ext.Panel",
    xtype: 'bookshelf',
    requires: [
    'com.inbooks.store.BookshelfStore',
    'Ext.dataview.List'
],
    config: {
        id: 'id-vw-bookshelf',
        layout: 'fit',
        items: [
        {/*Header*/
            xtype: 'header',
            docked: 'top'
        },
        {/*Footer*/
            xtype: 'footer',
            docked: 'bottom'
        },
        {/*Books list*/
            xtype: 'list',
            ui: 'round',
            title: 'Bookshelf',
            cls: "booksList",
            itemId: 'bookshelf-list',
            store: 'BookshelfStore',
            id: 'tplBookshelfLst',
            //emptyText: 'No books added yet',
            /*plugins: {
            xclass: 'Ext.plugin.SlideToRemove',
            buttonWidth: '40%',
            removeText: 'Remove'
            },*/
            onItemDisclosure: true,
            itemTpl: new Ext.XTemplate(
                [
                    '<div class="hidefield">'
                    , '<span><img class="catalog" src=' + com.inbooks.app.g_BookThumbnailUrl + '{BookCode}/{CoverPageThumbUrl}></img></span>'
                    , '<span style="width: 70%; position: absolute;">'
                    , '<p class="ellipsisDot line1" width="50%">&emsp;{Name}</p>'
                    , '<p class="ellipsisDot line2" width="50%">&emsp;Author: {Author}</p>'
                    , '<p class="ellipsisDot line2" width="50%">&emsp;Summary: {Summary}</p>'
                    , '<p class="ellipsisDot line2" width="50%">&emsp;Proposed by: {ProposedBy}</p>'
                    , '<p class="ellipsisDot line2" width="50%">&emsp;Publisher: {Publisher}</br>&emsp;Year: {PublishYear}&nbsp;<button class="btn btn-danger btn-mini btnDelFrmBookshelf" id="idDelFrmbookshelf_{BookCode}"><i class="icon-minus-sign"></i>&nbsp;bookshelf</button></p>'
                    , '</span>'
                    , '</div>'
                ].join('')),
            listeners: [
                {
                    element: 'element',
                    delegate: 'button',
                    event: 'tap',

                    fn: function (cmp, data, target, ev) {
                        
                            //show the loading mask
                            Ext.Viewport.setMasked({
                                xtype: 'loadmask',
                                indicator: true,
                                message: 'Deleting from bookshelf...'
                            });
                            

                            var bookcode = data.id.split('_')[1];
                            com.inbooks.classes.Helpers.delFrmBookshelf(bookcode);
                        }
                    }
                
            ]
        }
    ]
    },
    initialize: function (mybooks) {
        console.log("Books View initialize");
        this.callParent(arguments);
        try {
            var bookshelfData = Ext.JSON.decode(localStorage.getItem("AllBookshelf"));
            com.inbooks.app.g_bookshelf = bookshelfData.bookshelf;
            var store = Ext.getStore('BookshelfStore');
            store.clearData();
            store.setData(com.inbooks.app.g_bookshelf);
        }
        catch (e) { }
        this.on('painted', this.painted);
    },
    painted: function () {
        console.log('Books View painted');
        Ext.getCmp('id-footer').setActiveTab(2);
        Ext.getCmp('tplBookshelfLst').setEmptyText(g_m['msg0061']);
        //$(".booksList .x-item-selected").hide();
        
        com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[5];
        com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[5]);
        //set the template after the page is painted in order to get the values of global variables for labels and messages
        Ext.getCmp('tplBookshelfLst').setItemTpl(new Ext.XTemplate(
        [
            '<div>'
            , '<span><img class="catalog" src=' + com.inbooks.app.g_BookThumbnailUrl + '{BookCode}/{CoverPageThumbUrl}></img></span>'
            , '<span style="width: 70%; position: absolute;">'
            , '<p class="ellipsisDot line1" width="50%">&nbsp;&nbsp;{Name}</p>'
            , '<p class="ellipsisDot line2" width="50%">&emsp;' + g_l["lbl0027"] + ': {Author}</p>'
            , '<p class="ellipsisDot line2" width="50%">&emsp;' + g_l['lbl0042'] + ': {Summary}</p>'
            , '<p class="ellipsisDot line2" width="50%">&emsp;' + g_l['lbl0043'] + ': {ProposedBy}</p>'
            , '<p class="ellipsisDot line2" width="50%">&emsp;' + g_l["lbl0028"] + ': {Publisher}</br>&emsp;' + g_l['lbl0031'] + ': {PublishYear}&nbsp;<button class="btn btn-danger btn-mini btnDelFrmBookshelf" id="idDelFrmbookshelf_{BookCode}"><i class="icon-minus-sign"></i>&nbsp;' + g_l['lbl0032'] + '</button></p>'
            , '</span>'
            , '</div>'
        ].join('')));
    }
});