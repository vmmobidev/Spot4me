﻿Ext.define('com.inbooks.view.TermsAndConditions', {
    extend: 'Ext.Panel',
    xtype: 'termsandconditions',
    itemId: 'termsandconditions',
    config: {
        modal: true,
        centered: true,
        items: [
            {
                xtype: 'panel',
                items: [
                    {
                        xtype: 'titlebar',
                        title: 'Terms and Conditions',
                        docked: 'top',
                        items: [
                            {
                                xtype: 'button',
                                ui: 'plain decline',
                                iconCls: 'delete',
                                align: 'right',
                                iconMask: true,
                                action: 'btnHideTermsAndConditions'
                            }
                        ]
                    },
                    {
                        xtype: 'panel',
                        id: 'tacContentPanel',
                        scrollable: true,
                        styleHtmlContent: true,
                        cls: 'line2',
                        height: 300,
                        width: 275
                    }
                ]
            }
        ],
        listeners:{
            initialize: function () {
               // this.callParent(arguments);
               // this.on('painted', this.painted);
            } ,
            painted: function(){        
                Ext.Ajax.request({
                    url: 'resources/htmlContent/TermsAndConditions.html',
                    success: function (response, opts) {
                        Ext.getCmp("tacContentPanel").setHtml(response.responseText);
                    }
                });
            }        
        }
    },    

});
            