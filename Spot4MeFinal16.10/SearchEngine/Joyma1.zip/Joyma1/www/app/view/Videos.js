Ext.define("com.inbooks.view.Videos", {
    extend: "Ext.Panel",
    xtype: 'videos',
    requires: [
        'com.inbooks.store.VideoStore',
        'Ext.dataview.List'
    ],
    config: {
        id: 'id-vw-Videos',
        scrollable: true,
        layout: 'fit',
        items: [
            {
                xtype: 'header',
                docked: 'top'
            },
            {
                xtype: 'footer',
                docked: 'bottom'
            },
            {
                xtype: 'list',
                ui: 'round',
                disableSelection: true,
                //title: 'Books',
                cls: "booksList",
                itemId: 'list-videos',
                store: 'VideoStore',
                id: 'tplVideos',
                grouped: true,
                onItemDisclosure: true,
                itemTpl: new Ext.XTemplate(
                         [
                             '<div>'
                             , '<span><img class="catalog" id={Id} src= "{imgUrl}"> </img></span>'
                             , '<span style="width: 70%; position: absolute;">'
                             , '<p class="ellipsisDot line1" width="50%">&emsp;{Name}</p>'
                             , '</span>'
                             , '</div>'
                         ].join('')),
                listeners: [
                    {
                        element: 'element',
                        delegate: 'button',
                        event: 'tap',
                        fn: function (cmp, data, target, ev) {

                        }
                    }
                ]
            }
        ]
    },
    initialize: function (mybooks) {
        console.log("Videos View initialize");
        this.callParent(arguments);
        this.on('painted', this.painted);
    },
    painted: function () {
        console.log('Videos View painted - start');
        com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[15];
        com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[15]);
        //Ext.getCmp('viewHeader').setHtml('<div style="position:absolute;top:28%;left:45%;">Videos</div>');
        //set the template after the page is painted in order to get the values of global variables for labels and messages
        Ext.getCmp('tplVideos').setItemTpl(new Ext.XTemplate(
            [
                '<div>'
                , '<span><img class="catalog" id={Id} src= "{imgUrl}"> </img></span>'
                , '<span style="width: 70%; position: absolute;">'
                , '<p class="ellipsisDot line1" width="50%">&emsp;{Name}</p>'
                , '</span>'
                , '</div>'
            ].join('')));
        Ext.getCmp('id-footer').setActiveTab(1);
        console.log('Videos View painted - end');
    }
});