Ext.define('com.inbooks.view.Settings', {
    extend: 'Ext.TabPanel',
    xtype: 'settings',
    //title: 'Profile',
    config: {
        id: 'id-vw-settings',
        tabBar: {
            docked: 'top',
            ui: 'normal',
            layout: {
                type: 'hbox'
            }
        },
        items: [
        {
            xtype: 'header',
            docked: 'top'
        },
        {
            xtype: 'footer',
            docked: 'bottom'
        },

        //        {
        //            xtype: 'changepassword',
        //            title: 'Change Password',
        //            iconCls: 'user'
        //        },
        {
            xtype: 'preference',
            id: "idpreferences",
            title: 'Preferences'
        //iconCls: 'settings'
        },
        {
            xtype: 'profile',
            id: "idprofile",
            title: 'Change Profile'
            //iconCls: 'user'
        }
    ]
},
initialize: function () {
    //@#$ console.log("Settings  View initialize");
    this.callParent(arguments);
    this.on('painted', this.painted);
},
painted: function () {

    //@#$ console.log(Settings View painted
    com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[8];
    com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[8]);
    Ext.getCmp('id-footer').setActiveTab(4);
    Ext.getCmp("idpreferences").tab.setTitle(g_l['lbl0047']);
    Ext.getCmp("idprofile").tab.setTitle(g_l['lbl0046']);
    Ext.getCmp("cboLanguage").setLabel(g_l['lbl0009']);
    Ext.getCmp("idToggle").setLabel(g_l['lbl0010']);
    Ext.getCmp("lblSyncCatalog").setLabel(g_l['lbl0011']);
    Ext.getCmp("cboThemeChanger").setLabel(g_l['lbl0036']);
    Ext.getCmp("tglOfflineReading").setLabel(g_l['lbl0044']);
    Ext.getCmp("btnFooterHome").setTitle(g_l['lbl0005']);
    Ext.getCmp("btnFooterCatalog").setTitle(g_l['lbl0006']);
    Ext.getCmp("btnFooterBookshelf").setTitle(g_l['lbl0007']);
    Ext.getCmp("btnFooterSearch").setTitle(g_l['lbl0048']);
    Ext.getCmp("btnFooterSettings").setTitle(g_l['lbl0008']);
    
}

});






















