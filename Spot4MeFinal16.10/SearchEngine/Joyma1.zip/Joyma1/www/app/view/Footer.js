Ext.define('com.inbooks.view.Footer', {
extend: 'Ext.Panel',
xtype: 'footer',
config: {
    height: 50,
    items: [
        {
            xtype: 'tabbar',
            docked: 'bottom',
            id: 'id-footer',            
            ui: 'normal',
            items: [
                {// Home or Dashboard
                    title: 'Home',
                    iconCls: 'home',
                    id:'btnFooterHome',
                    iconMask: true,
                    action: 'btnHomeClick',
                    itemId: com.inbooks.app.g_menus[2]
                },
                {//catalogue
                    title: 'Library',
                    iconMask: true,
                    id:'btnFooterCatalog',
                    iconCls: 'list',
                    action: 'btnCatalogueClick',
                    itemId: com.inbooks.app.g_menus[3]
                },
                {//bookshelf
                    title: 'Bookshelf',
                    iconMask: true,
                    badgeText: '',
                    id:'btnFooterBookshelf',
                    iconCls: 'icon-bookshelf',
                    action: 'btnBookshelfClick',
                    itemId: com.inbooks.app.g_menus[5]
                },
                {// Search
                    title: 'Search',
                    iconMask: true,
                    id:'btnFooterSearch',
                    iconCls: 'search',
                    action: 'btnSearchClick',
                    itemId: com.inbooks.app.g_menus[12]
                },
                {// Settings
                    title: 'Settings',
                    iconMask: true,
                    id:'btnFooterSettings',
                    iconCls: 'settings',
                    action: 'btnSettingsClick',
                    itemId: com.inbooks.app.g_menus[8]
                }                
            ]
        }
    ]
},
initialize: function () {        
    console.log("Footer view initialized");
    this.callParent(arguments);
    this.on('painted', this.painted);
},
painted: function () {
    console.log("Footer view painted");
    $.noty.closeAll();// hide the bottom noty message
    try{
        Ext.getCmp('btnFooterBookshelf').setBadgeText(Ext.JSON.decode(localStorage.getItem("AllBookshelf")).bookshelf.length);
        Ext.getCmp("btnFooterHome").setTitle( g_l['lbl0005']);
        Ext.getCmp("btnFooterCatalog").setTitle( g_l['lbl0006']);
        Ext.getCmp("btnFooterBookshelf").setTitle( g_l['lbl0007']);
        Ext.getCmp("btnFooterSettings").setTitle(g_l['lbl0008']);
        Ext.getCmp("btnFooterSearch").setTitle(g_l['lbl0048']);
    }
    catch(e){ console.log(e.message); }
    }
});
