Ext.define("com.inbooks.view.Search",{
    extend: "Ext.Panel",
    xtype: 'search',
    requires: [
        'com.inbooks.store.SearchStore',
        'Ext.dataview.List',
        'Ext.field.Search',
        'Ext.Toolbar'
    ],
    config: {
        id: 'id-vw-search',
        scrollable: true,
        layout: 'fit',
        items: [
            {
                xtype: 'header',
                docked: 'top'
            },
            {
                xtype: 'footer',
                docked: 'bottom'
            },
            {
                xtype: 'toolbar',
                docked: 'top',
                height:'70px',
                ui: 'normal',
                items: [
                    {
                        xtype: 'searchfield',
                        id:'txtsearch',
                        placeHolder: 'Search...',
                        clearIcon: true,
                        width:'97%',
                        height:'50px',
                        listeners: {
                            keyup: function(field){
                                com.inbooks.classes.Helpers.onSearchKeyUp(field);
                                Ext.each(com.inbooks.app.g_bookshelf, function (obj, index, e) {
                                    $("#idaddtobookshelf_" + obj.BookCode).removeClass("btn-success");
                                    $("#idaddtobookshelf_" + obj.BookCode).prop("disabled", "disabled");
                                    $("#idbuy_" + obj.BookCode).removeClass("btn-primary");
                                    $("#idbuy_" + obj.BookCode).prop("disabled", "disabled");
                                });
                            } ,
                            clearicontap: function (field, e, opts) {
                                hideKeyboard(); // Calling this function for resigning the keyboard
                                com.inbooks.classes.Helpers.onSearchKeyUp(field);
                                Ext.each(com.inbooks.app.g_bookshelf, function (obj, index, e) {
                                    $("#idaddtobookshelf_" + obj.BookCode).removeClass("btn-success");
                                    $("#idaddtobookshelf_" + obj.BookCode).prop("disabled", "disabled");
                                    $("#idbuy_" + obj.BookCode).removeClass("btn-primary");
                                    $("#idbuy_" + obj.BookCode).prop("disabled", "disabled");
                                });
                            }
                        }
                    }
                ]
            },
            {
                xtype: 'list',
                ui: 'round',
                onItemDisclosure: true,
                cls: "booksList",
                store: 'SearchStore',
                id:'tplsearchbooklst',
                //itemTpl defines the template for each item in the list
                itemTpl:  new Ext.XTemplate(
                    [
                        '<div>'
                        , '<span><img class="catalog" id={ID} src=' + com.inbooks.app.g_BookThumbnailUrl +'{BOOKCODE}/{CoverPageThumbUrl}></img></span>'
                        , '<span style="width: 70%; position: absolute;">'
                        , '<p class="ellipsisDot line1" width="50%">&emsp;{NAME}</p>'
                        , '<p class="ellipsisDot line2" width="50%">&emsp;Author: {AUTHOR}</p>'
                        , '<p class="ellipsisDot line2" width="50%">&emsp;Summary: {Summary}</p>'
                            , '<p class="ellipsisDot line2" width="50%">&emsp;Proposed by: {ProposedUser}</p>'
                        , '<p class="ellipsisDot line2" width="50%">&emsp;Publisher: {PUBLISHER}</br>&emsp;Year: {PUBLISHYEAR}&nbsp;<button class="btn btn-success btn-mini btnAddtoBookshelf" id="idaddtobookshelf_{BOOKCODE}"><i class="icon-plus-sign"></i>&nbsp;bookshelf</button>&nbsp;<button style="visibility:hidden;" class="btn btn-mini btnAddtoBookshelf" id="idpreview_{BOOKCODE}"><i class="icon-eye-open"></i>&nbsp;preview</button>&nbsp;<button style="visibility:hidden;" class="btn btn-primary btn-mini btnAddtoBookshelf" id="idbuy_{BOOKCODE}"><i class="icon-money"></i>&nbsp;buy</button></p>'
                        , '</span>'
                        , '</div>'
                    ].join('')),
                //useSimpleItems: true,
                grouped: true,
                emptyText: '<div style="margin-top: 20px; text-align: center">No Matching Items</div>',
                listeners: [
                    {
                        element: 'element',
                        delegate: 'button',
                        event: 'tap',
                        fn: function (cmp, data, target, ev) {
                            if(!(cmp.delegatedTarget.disabled)){
                                //show the loading mask
                                Ext.Viewport.setMasked({
                                    xtype: 'loadmask',
                                    indicator: true,
                                    message: g_m['msg0052']
                                });
                                var bookCode = data.id.split('_')[1];  //get the book code for the book for which the button is tapped
                                if (data.id.split('_')[0] == "idpreview") {   // if the button is preview button
                                    var cmp = {}, options = {},data;
                                    var allData = Ext.getStore('BooksStore').data.all ;     //get all books list from store
                                    Ext.each(allData,function(item,i){         //traverse the book list
                                        if(item.data.BOOKCODE == bookCode) {
                                            data = item;                    // set the data for the current book
                                            return;
                                        }
                                    });
                                    //call the reader for that particular book when preview is clicked
                                    com.inbooks.app.getController("BooksController").showReader(cmp, data, options);
                                }
                                else{
                                    com.inbooks.classes.Helpers.addToBookshelf(bookCode); // else if the buttons pressed are add to bookshelf or Buy, add the book to bookshelf
                                }
                            }
                        }
                    }
                ]
            }
        ]
    },
    initialize: function (searchbooks) {
        console.log("Search View initialize");
        //this.callParent(arguments);
        try {
            var masterData = Ext.JSON.decode(localStorage.getItem("AllMasterData"));
            com.inbooks.app.g_catalogs = masterData.catalogs;
            com.inbooks.app.g_books = masterData.books;
            var store = Ext.getStore('SearchStore');            
            store.clearData();
            store.setData(com.inbooks.app.g_books);
        }
        catch (e) { }
        this.on('painted', this.painted);
    } ,
    painted: function(){

        Ext.getCmp('id-footer').setActiveTab(3);
        Ext.getCmp('txtsearch').setPlaceHolder(g_l['lbl0048'] + '...') ;
        com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[12];
        com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[12]);

        Ext.getCmp('tplsearchbooklst').setItemTpl(new Ext.XTemplate(
            [
                '<div>'
                , '<span><img class="catalog" id={ID} src=' + com.inbooks.app.g_BookThumbnailUrl +'{BOOKCODE}/{CoverPageThumbUrl}></img></span>'
                , '<span style="width: 70%; position: absolute;">'
                , '<p class="ellipsisDot line1" width="50%">&emsp;{NAME}</p>'
                , '<p class="ellipsisDot line2" width="50%">&emsp;&nbsp;'+ g_l['lbl0027']+': {AUTHOR}</p>'
                , '<p class="ellipsisDot line2" width="50%">&emsp;&nbsp;'+ g_l['lbl0042']+': {Summary}</p>'
                , '<p class="ellipsisDot line2" width="50%">&emsp;&nbsp;'+ g_l['lbl0043']+': {ProposedUser}</p>'
                , '<p class="ellipsisDot line2" width="50%">&emsp;&nbsp;'+ g_l['lbl0028']+': {PUBLISHER}</br>&emsp;&nbsp;'+ g_l['lbl0029']+': {PUBLISHYEAR}&nbsp;<button class="btn btn-success btn-mini btnAddtoBookshelf" id="idaddtobookshelf_{BOOKCODE}"><i class="icon-plus-sign"></i>&nbsp;'+ g_l['lbl0030']+'</button>&nbsp;<button style="visibility:hidden;" class="btn btn-mini btnAddtoBookshelf" id="idpreview_{BOOKCODE}"><i class="icon-eye-open"></i>&nbsp;' + g_l['lbl0052'] + '</button>&nbsp;<button style="visibility:hidden;" class="btn btn-primary btn-mini btnAddtoBookshelf" id="idbuy_{BOOKCODE}"><i class="icon-money"></i>&nbsp;' + g_l['lbl0053'] + '</button></p>'
                , '</span>'
                , '</div>'
            ].join('')));

        Ext.each(com.inbooks.app.g_bookshelf, function (obj, index, e) {
            $("#idaddtobookshelf_" + obj.BookCode).removeClass("btn-success");
            $("#idaddtobookshelf_" + obj.BookCode).prop("disabled", "disabled");
            $("#idbuy_" + obj.BookCode).removeClass("btn-primary");
            $("#idbuy_" + obj.BookCode).prop("disabled", "disabled");
        });

        

    }
});
