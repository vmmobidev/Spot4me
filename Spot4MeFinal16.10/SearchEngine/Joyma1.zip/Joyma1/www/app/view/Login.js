﻿Ext.define("com.inbooks.view.Login", {
    extend: "Ext.form.Panel",
    xtype: 'login',
    config: {
    id:'id-vw-login',        
    style: 'background-color: white;',
    items: [
        {/*Spacer decoration*/
            xtype: 'spacer',
            height: '50PX'
        },        
        {/*Logo*/
            xtype: 'panel',
            id:'loginlogo',
            html: '<div align="center"><img src="resources/images/joyma-logo-face-100x80.png"></img><div class="vm-login-logo-txt">JoyMa</div></div>'
        },        
        {/*Fields*/
            xtype: 'fieldset',
            id: 'idfieldset',
            style: 'padding-top:35%',
            defaults: {
                labelWidth: '40%'
            },
            layout:
            {
                type: 'vbox',
                pack: 'center'
            },
            items:
            [
                {//Username
                    xtype: 'textfield',
                    name: 'txtUsername',
                    id: 'txtUsername',
                    value: '',
                    required: true,
                    placeHolder: 'Username',
                    autoComplete: false,
                    style: 'background: #EEE;'
                },
                {//Password
                    xtype: 'passwordfield',
                    name: 'txtPassword',
                    id: 'txtPassword',
                    value: '',
                    required: true,
                    autoComplete: false,
                    placeHolder: 'Password',
                    style: 'background:   #EEE;'
                }
            ]
        },
        {/*Spacer decoration*/
            xtype: 'spacer',
            height: '20px'
        },
        {/*Submit button*/
            xtype: 'panel',
            defaults: {
                width: '100%',
                height: '50px'
            },
            layout: {
                type: 'vbox',
                pack: 'center'
            },
            style: 'padding-left:0.8%; padding-right:0.8%',
            items: [
                {//Login button
                    xtype: 'button',
                    name: 'btnLogin',
                    id: 'btnLogin',
                    action: 'btnLoginClick',
                    text: 'Login',
                    ui: 'action' //Blue Theme,
                },
                {//Spacer decoration
                    xtype: 'spacer',
                    height: '5px'
                },
                {//SignUp button
                    xtype: 'button',
                    name: 'btnSignup',
                    id: 'btnSignup',
                    action: 'btnSignUpClick',
                    text: 'Sign Up',
                    ui: 'confirm' //green Theme
                }
            ]
        }
    ]
},
initialize: function () {
    console.log('Login view initialized');
    this.callParent(arguments);
    this.on('painted', this.painted);
},
painted: function () {
    console.log('Login view painted');
    $.noty.closeAll();
    com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[0];
    com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[0]);
    Ext.getCmp("txtUsername").setPlaceHolder(g_l['lbl0001']);
    Ext.getCmp("txtPassword").setPlaceHolder(g_l['lbl0002']);
    Ext.getCmp("btnLogin").setText(g_l['lbl0003']);
    Ext.getCmp("btnSignup").setText(g_l['lbl0004']);
    Ext.getCmp("loginlogo").setHtml('<div align="center"><img src="resources/images/joyma-logo-face-100x80.png"></img><div class="vm-login-logo-txt">' + g_l['lbl0049'] + '</div></div>');
    
    
    }
});























































