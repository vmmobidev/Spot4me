﻿Ext.define("com.inbooks.view.Invite", {
extend: "Ext.form.Panel",
xtype: 'invite',
config: {
scrollable: true,
style: 'background-color: white;',
items: [           
    {/*Spacer Decoration*/
        xtype: 'spacer',
        height: '50PX'
    },
    {/*Header*/   
        xtype:'header',
        docked:'top'
    },
    {/*Footer*/   
        xtype:'footer',
        docked:'bottom'
    },
    {
        xtype: 'fieldset',            
        defaults: {
            labelWidth: '40%'
        },
        layout:
        {
            type: 'vbox',
            pack: 'center'
        },
        items: [
            {//Your Friend's Name
                xtype: 'textfield',
                name: 'txtFriendName',
                id:'txtFriendName',
                value: '',
                required: true,
                placeHolder: 'Your friend'+"'s"+' name',
                style: 'background: #EEE;'
            }
        ]
    },
    {/*Spacer Decoration*/
        xtype: 'spacer',
        height: '10PX'
    },
    {
        xtype: 'fieldset',
        //style: 'padding-top:40%',
        defaults: {
            labelWidth: '40%'
        },
        layout:
        {
            type: 'vbox',
            pack: 'center'
        },
        items: [
            {//Email
                xtype: 'emailfield',
                name: 'txtFriendsEmail',
                id:'txtFriendsEmail',
                value: '',
                required: true,
                placeHolder: 'Email',
                style: 'background: #EEE;'
            }
        ]
    },
    {/*Spacer Decoration*/
        xtype: 'spacer',
        height: '10PX'
    },
    {
        xtype: 'fieldset',
        hidden: true,
        defaults: {
            labelWidth: '40%'
        },
        layout:
        {
            type: 'vbox',
            pack: 'center'
        },
        items: [
            {//Special Notes to you friend
                xtype: 'textareafield',
                name: 'txtNotes',                
                id:'txtNotes',
                value: '',                
                placeHolder: 'Special notes to your friend',
                style: 'background: #EEE;',
                height:'200px'
            }
        ]
    },
    {/*Spacer Decoration*/
        xtype: 'spacer',
        height: '20px'
    },
    {/*Buttons*/
        xtype: 'panel',
        defaults: {                   
            height: '50px'
        },
        layout: {
            type: 'hbox',
            pack: 'center'
        },
        style: 'padding-left:0.8%; padding-right:0.8%',
        items: [
            {//Login button
                xtype: 'button',
                name: 'btnClear',
                id:'btnClear',
                action: 'btnClearClick',
                text: 'Clear',
                width:'49%',
                ui: 'normal' //gray Theme
            },
            {//Spacer decoration
                xtype: 'spacer',
                width: '1%'
            },
            {//Invite button
                xtype: 'button',
                name: 'btnInvite',
                id:'btnInvite',
                action: 'btnInviteClick',
                text: 'Invite',
                width: '49%',
                ui: 'confirm' //green Theme
            }                 
        ]
    }
]
},
initialize: function () {
    console.log('Invite view initialized');
    this.callParent(arguments);
    this.on('painted', this.painted);
},
painted: function () {
    console.log('Invite view painted');
    com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[11];
    com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[11]);
    Ext.getCmp("txtFriendName").setPlaceHolder( g_m['msg0050']);
    Ext.getCmp("txtFriendsEmail").setPlaceHolder( g_l['lbl0018']);
    Ext.getCmp("txtNotes").setPlaceHolder( g_m['msg0051']);
    Ext.getCmp("btnClear").setText( g_l['lbl0025']);
    Ext.getCmp("btnInvite").setText( g_l['lbl0026']);
    }
});























































