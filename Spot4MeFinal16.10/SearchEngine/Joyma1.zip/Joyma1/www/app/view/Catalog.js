Ext.define("com.inbooks.view.Catalog", {
    extend: "Ext.Panel",
    xtype: 'catalog',
    requires: [
        'com.inbooks.store.CatalogStore',
        'Ext.dataview.List'
    ],
    config: {        
        id: 'id-vw-catalog',
        fullscreen: true,
        layout: 'fit',
        items: [
            {
                xtype: 'header',
                docked: 'top'
            },
            {
                xtype: 'footer',
                docked: 'bottom'
            },
            {
                xtype: 'list',
                //layout: 'fit',
                ui: 'round',
                title: 'Categories',
                itemId: 'list-catalog',
                store: 'catalogstore',
                onItemDisclosure: true,
                //itemTpl: ['<div class="uploadedbooks line1"><font class="ellipsis" size="3" color="#000000">{Name} ({count})</font></div>'].join(''),
                itemTpl: ['<div class="ellipsisDot line1">{Name} ({count})</div>'].join(''),
                //height: window.innerHeight-100,
                listeners: {
                    initialize:function(args){
                        console.log("Catalog list initialize");
                    },
                    painted: function(control) {
                        console.log('Catalog list painted');
                    }
                }
            }
        ]
    },
    initialize:function(mybooks){
        console.log("Catalog View initialize");
        this.callParent(arguments);
        try{
            var masterData = Ext.JSON.decode(localStorage.getItem("AllMasterData"));
            com.inbooks.app.g_catalogs = masterData.catalogs;
            com.inbooks.app.g_books = masterData.books;
            var store = Ext.getStore('catalogstore');
            store.setData(com.inbooks.app.g_catalogs);
        }
        catch(e){}
        this.on('painted', this.painted);        
    },
    painted: function() {
        console.log('Catalog View painted - start');
        Ext.getCmp('id-footer').setActiveTab(1);
        com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[3];
        com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[3]);
        console.log('Catalog View painted - end');
    }
});