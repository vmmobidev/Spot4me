﻿Ext.define('com.inbooks.view.Header', {
    extend: 'Ext.TabBar',
    id: 'viewHeader',
    xtype: 'header',
    config: {
        ui: 'plain',
        //title: '',
        cls: 'vm-header-title',
        height: 50,
        items: [

                {/*Back Button for IOS Devices*/
                    xtype: 'button',
                    //cls:'backbuttonalign',
                    cls: 'backbtncolor backbuttonalign',
                    id: 'backButton',
                    itemId: 'backButton',
                    hidden: true,
                    height:35,
                    align: 'left',
                    action: 'btnBackClick',
                    text: 'back',
                    ui: 'back'
                    //style: 'background-color:red'                    
                },
                {/*Logo*/
                    //xtype: 'panel',
                    align: 'center',
                    //left:'40%',
                    //top:'10%',
                    id:'headerlogo',
                    //width: '100%',
                    ui: 'plain',
                    html: '<span class="vm-img-logo"><img src="resources/images/logo-small.png" /></span><span class="vm-logo-txt">JoyMa</span>'
                },
                {/*Logout button*/
                    xtype: 'button',
                    action: 'btnLogoutClick',
                    align: 'right',
                    ui: 'plain',
                    text: '<i style="color: red;" class="icon-off icon-2x" />',
                    height: 45,
                    top: 2,
                    right: 5
                }             
          ]
    },
    initialize: function () {
        console.log("Header view initialize")
        this.callParent(arguments);
        this.on('painted', this.painted);
        this.on('resize', this.resize);
    },
    painted: function (header) {
        console.log('Header view painted');
        var userName = Ext.JSON.decode(localStorage.getItem("user")).Name;
        var curTheme = localStorage.getItem("curTheme");
        //this.setTitle("<div><div style='white-space: nowrap; overflow: hidden; text-overflow: ellipsis;width: 100%;font-size:10pt;color: #ffffff;'><h6>"+ g_m['msg0038'] + "&nbsp; " + userName +"</h6></div></div>");
        this.addCls(curTheme.split(',')[1]);
        Ext.getCmp("headerlogo").setHtml('<span class="vm-img-logo"><img src="resources/images/joyma-logo-face-50x40.png" /></span><span class="vm-logo-txt">'+g_l['lbl0049']+'</span>');
        if (Ext.os.is.iOS) {
            Ext.getCmp("backButton").setHidden(false);
            Ext.getCmp("headerlogo").setLeft('43%');
            Ext.getCmp("headerlogo").setTop('20%');
        }
    }
});
