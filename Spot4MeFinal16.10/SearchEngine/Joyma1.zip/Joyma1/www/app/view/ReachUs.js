Ext.define("com.inbooks.view.ReachUs",{
    extend:"Ext.form.Panel",
    xtype:"reachus",
    config:{
        scrollable:true,
        style: 'background-color: white;',
        items:[
            {
                xtype: 'spacer',
                height: '50PX'
            },
            {   xtype:'header',
                docked:'top'
            },
            {   xtype:'footer',
                docked:'bottom'
            },
            {
                items:[
                    {
                        xtype:'fieldset',
                        defaults:
                        {
                            labelWidth: '8%'
                        },
                        items:
                        [
                            { /*To field*/
                                xtype: 'emailfield',
                                name: 'txtReachUsToEmail',
                                id:'txtReachUsToEmail',
                                label: g_l['lbl0034'],
                                placeHolder: 'senthilnathank@vmokshagroup.com',
                                autoCapitalize: false,
                                disabled: true,
                                value:'senthilnathank@vmokshagroup.com',
                                //clearIcon: true,
                                style: 'background-color: #ffffff; font-size: 14px'
                            }
                        ]
                    },{

                        xtype:'fieldset',
                        items:
                        [
                            { /*To field*/
                                xtype: 'textareafield',
                                name: 'txtReachUsMessage',
                                id:'txtReachUsMessage',
                                //label: 'Message',
                                placeHolder: g_l['lbl0035'],
                                autoCapitalize: false,
                                height:'350px',
                                required: true,
                                clearIcon: true,
                                style: 'background-color: #ffffff; font-size: 14px'
                            }
                        ]
                    },
                    {
                        xtype: 'panel',
                        defaults: {
                            height: '50px'
                        },
                        layout: {
                            type: 'hbox',
                            pack: 'center'
                        },
                        style: 'padding-left:0.8%; padding-right:0.8%',
                        items: [
                            {//Spacer decoration
                                xtype: 'spacer',
                                width: '75%'
                            },
                            {//Invite button
                                xtype: 'button',
                                name: 'btnReachUsSend',
                                id:'btnReachUsSend',
                                action: 'btnReachUsSendClick',
                                text: g_l['lbl0033'],
                                width: '24%',
                                ui: 'action' //blue Theme
                            }
                        ]
                    }
                ]
            }
        ]

    },
    initialize: function () {
        console.log('ReachUs view initialized');
        this.callParent(arguments);
        this.on('painted', this.painted);
    },
    painted:function(){
        console.log('ReachUs view painted');
        com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[10];
        com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[10]);
        Ext.getCmp("txtReachUsToEmail").setLabel( g_l['lbl0034']);
        Ext.getCmp("txtReachUsMessage").setPlaceHolder( g_l['lbl0035']);
        Ext.getCmp("btnReachUsSend").setText( g_l['lbl0033']);

    }

});