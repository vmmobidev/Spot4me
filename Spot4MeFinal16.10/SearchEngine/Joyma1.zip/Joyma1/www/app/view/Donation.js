﻿Ext.define("com.inbooks.view.Donation", {
    extend: "Ext.form.Panel",
    xtype: 'donation',
    config: {
        //styleHtmlContent:true,
        scrollable : {
            direction     : 'vertical',
            directionLock : true
      },
        style: 'background-color: white;',
        items: [
           {/*Header*/
               xtype: 'header',
               docked: 'top'
           },
           {/*Footer*/
               xtype: 'footer',
               docked: 'bottom'
           },           
           {
               xtype: 'fieldset', //Fieldset has been given for grouping
               cls:"fieldsetbgcolor",
               items: [                                              
                    {/*Name*/
                    xtype: 'fieldset',
                    layout:
                    {
                        type: 'vbox',
                        pack: 'center'
                    },
                    items: [
                    {//Card Number
                        xtype: 'textfield',
                        //name: 'txtName',
                        id: 'txtDonateName',
                        //value: '',
                        //required: true,
                        placeHolder: 'Name',
                        //autoComplete: false,
                        style: 'background: #EEE;'
                    }
                ]
            },
            {/*Spacer Decoration*/
                xtype: 'spacer',
                height: '5px'
            },
            {/*Card type*/
                xtype: 'fieldset',
                layout:
                {
                    type: 'vbox',
                    pack: 'center'
                },
                items: [
                {//Card Type
                    xtype: 'selectfield',
                    name: 'drpCardtype',
                    id: 'drpCardtype',
                    usePicker:false,
                    value: '',
                    required: true,
                    //placeHolder: 'Card Type',
                    autoComplete: false,
                    style: 'background: #EEE;',
                    options: [
                                    { text: 'Card Type', value: 'Card Type' },
                                    { text: 'Visa', value: 'Visa' },
                                    { text: 'Master', value: 'Master' }
                            ]
                        }
                    ]
            },
            {/*spacer decoration*/
                xtype: 'spacer',
                height: '5px'
            },
            {/*Card Number*/
               xtype: 'fieldset',
               layout:
            {
                type: 'vbox',
                pack: 'center'
            },
               items: [
                {//Card Number
                    xtype: 'textfield',
                    component: {type: 'tel'},
                    name: 'numCardnumber',
                    id: 'numCardnumber',                                       
                    placeHolder: 'Card Number',                    
                    style: 'background: #EEE;'
                }
             ]
           },
           {/*spacer decoration*/
                xtype: 'spacer',
                height: '5px'
           },
           {/* hbox for month, year and cvv*/
               xtype:'fieldset',
             layout:
               {
                    type: 'hbox'
               },               
               items: [
                
                    {/*Exp.Month*/
                        xtype: 'selectfield',
                        name: 'drpMonth',
                        id: 'drpMonth',
                        usePicker:false,
                        value: '',
                        required: true,
                        autoComplete: false,
                        width: '40%',
                        style: 'background: #EEE;',
                        options: [
                            { text: 'Exp.Month', value: 'Month' },
                            { text: '1', value: '1' },
                            { text: '2', value: '2' },
                            { text: '3', value: '3' },
                            { text: '4', value: '4' },
                            { text: '5', value: '5' },
                            { text: '6', value: '6' },
                            { text: '7', value: '7' },
                            { text: '8', value: '8' },
                            { text: '9', value: '9' },
                            { text: '10', value: '10' },
                            { text: '11', value: '11' },
                            { text: '12', value: '12' }
                        ]
                    },
                            
                    {/*Exp.year*/
                    xtype: 'selectfield',
                    name: 'drpYear',
                    id: 'drpYear',
                    usePicker:false,
                    value: '',
                    required: true,
                    autoComplete: false,
                    width: '40%',
                    style: 'background: #EEE;',
                    options: [
                                { text: 'Exp.Year', value: 'Year' },
                                { text: '2013', value: '2013' },
                                { text: '2014', value: '2014' },
                                { text: '2015', value: '2015' },
                                { text: '2016', value: '2016' },
                                { text: '2017', value: '2017' },
                                { text: '2018', value: '2018' },
                                { text: '2019', value: '2019' },
                                { text: '2020', value: '2020' },
                                { text: '2021', value: '2021' },
                                { text: '2022', value: '2022' },
                                { text: '2023', value: '2023' },
                                { text: '2024', value: '2024' }
                            ]
                        },
                        
                    
                  
              
                        {
                            xtype: 'textfield',
                            component: {type: 'tel'},
                            name: 'txtcvv',
                            //value:'100',
                            placeHolder:'cvv',
                            width:"20%",
                            id: 'txtcvv',                                                       
                            style: 'background: #EEE;'
                        }
                  ]
                }            
              ]
            },
            {/*Amount push buttons*/
                xtype: 'fieldset',
                cls:"fieldsetbgcolor",
                items: [
                    {/*spacer decoration*/
                        xtype: 'spacer',
                        height: '15px'
                    },
                    {
                    layout:
                    {
                        type: 'hbox',                   
                        pack: 'center'
                    },
                    items: [
                       {//$5 button
                           xtype: "button",
                           cls: 'vm-btn',
                           itemId: 'btn$5',
                           action: 'btn$5',
                           text: '$5'
                       },
                       {//spacer decoration
                           xtype: 'spacer',
                           width: '1px'
                       },
                       
                        {//$10 button
                            xtype: "button",
                            cls: 'vm-btn',
                            itemId: 'btn$10',
                            action: 'btn$10',
                            text: '$10'
                        },
                        {//spacer decoration
                            xtype: 'spacer',
                            width: '1px'
                        },
                       

                       {//$20 button
                           xtype: "button",
                           cls: 'vm-btn',
                           itemId: 'btn$20',
                           action: 'btn$20',
                           text: '$20'
                       },
                       {//spacer decoration
                           xtype: 'spacer',
                           width: '1px'
                       },
                       
                       {//$30 button
                           xtype: "button",
                           cls: 'vm-btn',
                           itemId: 'btn$30',
                           action: 'btn$30',
                           text: '$30'
                       },
                       {//spacer decoration
                           xtype: 'spacer',
                           width: '1px'
                       },
                       
                       {//$50 button
                           xtype: "button",
                           cls: 'vm-btn',
                           itemId: 'btn$50',
                           action: 'btn$50',
                           text: '$50'
                       },
                       
                       /*{//spacer decoration
                           xtype: 'spacer',
                           width: '2px'
                       },
                       {//$30 button
                           xtype: "button",
                           cls: 'vm-btn',
                           width:'60px',
                           itemId: 'btn$100',
                           action: 'btn$100',
                           text: '$100'
                       }*/
                ]
            },
            {/*spacer decoration*/
                xtype: 'spacer',
                height: '5px'
            },
            {/*or label*/
                xtype: 'label',
                id: 'lblOR',
                html: '<div align="center">or</div>'
            },
            {/*Spacer decoration*/
                xtype: 'spacer',
                height: '5px'
            },

            {/*Amount in $*/
                xtype: 'fieldset',
                id:'lblotheramount',
                defaults:
                    {
                        labelWidth: '50%'
                    },
                    style:'padding-left:25%',
                    layout:
                    {
                        type: 'vbox',
                        pack: 'center'
                    },
                    width:'75%',
                    items: [
                            {//Card Number
                                xtype: 'numberfield',                            
                                label: 'Amount in $: ',
                                id: 'txtotheramount',
                                style: 'background-color: #ffffff'
                            }
                        ]
                    }            
                ]
            },
            {/*buttons*/
                xtype: 'panel',
                defaults: {
                    width: '100%',
                    height: '50px'
                },
                layout: {
                    type: 'vbox',
                    pack: 'center'
                },
                style: 'padding-left:0.8%;padding-right:0.8%',
                items: [
                    { /*Donate button*/
                        xtype: 'button',
                        name: 'btnDonate',
                        id: 'btnDonate',
                        action: 'btnDonateClick',
                        text: 'Donate',
                        ui: 'confirm'
                    },
                    {/*Spacer decoration*/
                        xtype: 'spacer',
                        height: '5px'
                    },
                    {/*Clear button*/
                        xtype: 'button',
                        name: 'btnClear',
                        hidden: true,
                        id: 'btnClear',
                        action: 'btn',
                        text: 'Clear',
                        ui: 'normal'
                    }
                ]
            }
        ]
    },
    initialize: function () {
        console.log('Donation view initialized');
        this.callParent(arguments);
        this.on('painted', this.painted);
    },
    painted: function () {
        console.log('Donation view painted');
        com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[13];
        com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[13]);
        Ext.getCmp('viewHeader').setHtml('<div style="position:absolute;top:28%;left:45%;">Donate</div>');
        Ext.getCmp('txtDonateName').setPlaceHolder(g_l['lbl0054']);
        Ext.getCmp('numCardnumber').setPlaceHolder(g_l['lbl0055']);
       //Ext.getCmp('lblExpirydate').setLabel(g_l['lbl0056']);
        Ext.getCmp('txtcvv').setPlaceHolder(g_l['lbl0057']);
        Ext.getCmp('txtotheramount').setLabel(g_l['lbl0059']);
        Ext.getCmp('lblOR').setHtml('<div align="center">' + g_l['lbl0058'] + '</div>');
        Ext.getCmp('btnDonate').setText(g_l['lbl0051']);
        if (Ext.os.deviceType == "Phone") {
            Ext.getCmp("txtcvv").setClearIcon(false);
            Ext.getCmp("lblotheramount").setLabelWidth("70%");
        }
        
        Ext.getCmp('drpMonth').setOptions([
                { text: g_l['lbl0056'], value: 'Month' },
                { text: '1', value: '1' },
                { text: '2', value: '2' },
                { text: '3', value: '3' },
                { text: '4', value: '4' },
                { text: '5', value: '5' },
                { text: '6', value: '6' },
                { text: '7', value: '7' },
                { text: '8', value: '8' },
                { text: '9', value: '9' },
                { text: '10', value: '10' },
                { text: '11', value: '11' },
                { text: '12', value: '12' }
                ]);
        Ext.getCmp('drpYear').setOptions([
                { text: g_l['lbl0061'], value: 'Year' },
                { text: '2013', value: '2013' },
                { text: '2014', value: '2014' },
                { text: '2015', value: '2015' },
                { text: '2016', value: '2016' },
                { text: '2017', value: '2017' },
                { text: '2018', value: '2018' },
                { text: '2019', value: '2019' },
                { text: '2020', value: '2020' },
                { text: '2021', value: '2021' },
                { text: '2022', value: '2022' },
                { text: '2023', value: '2023' },
                { text: '2024', value: '2024' }
                ]);
        Ext.getCmp("drpCardtype").setOptions([
                { text: g_l['lbl0060'], value: 'Card Type' },
                { text: 'Visa', value: 'Visa' },
                { text: 'Master', value: 'Master' }
        ])
     }
});
























































