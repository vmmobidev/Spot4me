Ext.define("com.inbooks.view.Music", {
    extend: "Ext.Panel",
    xtype: 'music',
    requires: [
        'com.inbooks.store.MusicStore',
        'Ext.dataview.List',
        'Ext.Audio'
    ],
    config: {
        id: 'id-vw-Music',
        layout: 'fit',
        items: [
            {
                xtype: 'header',
                docked: 'top'
            },
            {
                xtype: 'footer',
                docked: 'bottom'
            },
            {
                xtype: 'list',
                ui: 'round',
                disableSelection: true,
                cls: "booksList",
                //title: 'Music',
                itemId: 'list-Music',
                store: 'MusicStore',
                id: 'tplMusicLst',
                grouped: true,
                onItemDisclosure: true,
                itemTpl: new Ext.XTemplate(
                         [
                            '<div>'
                            , '<span><img class="catalog" id={Id} src=' + com.inbooks.app.g_BookThumbnailUrl + '{BOOKCODE}/{CoverPageThumbUrl}></img></span>'
                            , '<span style="width: 70%; position: absolute;">'
                            , '<p class="ellipsisDot line1" width="50%">&emsp;{Name}</p>'
                            , '</span>'
                            , '</div>'
                         ].join(''))
            }
            /*{
                docked: 'bottom',
                html: '<audio class="vm-audio" id="id-audio" controls autoplay preload="auto" type="audio/mpeg" codecs="mp3"></audio>'
            }*/
        ]
    },
    initialize: function (mybooks) {
        console.log("Music View initialize");
        this.callParent(arguments);
        try {
            var masterData = Ext.JSON.decode(localStorage.getItem("AllMasterData"));
            com.inbooks.app.g_catalogs = masterData.catalogs;
            com.inbooks.app.g_books = masterData.books;
            var store = Ext.getStore('BooksStore');
            store.setData(com.inbooks.app.g_books);
        }
        catch (e) { }
        this.on('painted', this.painted);
    },
    painted: function () {
        console.log('Music View painted - start');
        com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[14];
        com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[14]);
        //Ext.getCmp('viewHeader').setHtml('<div style="position:absolute;top:28%;left:45%;">Music</div>');
        //set the template after the page is painted in order to get the values of global variables for labels and messages
        Ext.getCmp('tplMusicLst').setItemTpl(new Ext.XTemplate(
            [
                '<div>'
                , '<span><img style="width: 60px; height: 60px;" id={Id} src="resources/images/music_file_alt.png"</img></span>'
                , '<span style="width: 70%; position: absolute;">'
                , '<p class="ellipsisDot line1" width="50%">&emsp;{Name}</p>'
                //, '<p class="ellipsisDot line1" width="50%">&emsp;<button class="btn btn-primary btn-mini play" id="music_{Id}">Play</button></p>'
                , '</span>'
                , '</div>'
            ].join('')));
        console.log('Music View painted - end');
    }
});