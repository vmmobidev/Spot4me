﻿Ext.define("com.inbooks.view.Bookmarks", {
    extend: "Ext.Panel",
    xtype: 'bookmarks',
    requires: [],
    config: {
        layout: 'fit',
        items: [
            {
                xtype: 'list',
                id: 'id-bookmark-items',
                scrollable: true,
                padding: '5px',
                title: 'Bookmarks',
                styleHtmlContent: true,
                store: 'BookmarksStore',
                itemTpl: new Ext.XTemplate(['<div><div class="ellipsisDot">{[this.formatDate(values.Date)]}</div>'
                    , '<div class="vm-pagenum"> Page: {PageId}</div></div>'].join(''),
                    {
                        formatDate: function (text) {
                            var d = new Date(text);
                            var curr_date = d.getDate();
                            var curr_month = d.getMonth() + 1; //Months are zero based
                            var curr_year = d.getFullYear();
                            var curTime = d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();
                            return curr_date + "/" + curr_month + "/" + curr_year + " " + curTime;
                        }
                    }),
                listeners: {
                    initialize: function (control, opts) {
                        console.log("Bookmarks List Initialize");
                    },
                    painted: function (control) {
                        console.log("Bookmarks List Painted");
                    }
                }
            }
        ]
    },
    initialize: function () {
        console.log("Bookmarks view initialize")
        this.callParent(arguments);
        this.on('painted', this.painted);
    },
    painted: function () {
        console.log('Bookmarks View painted');
    }
});