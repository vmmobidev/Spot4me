﻿Ext.define('com.inbooks.view.Preference', {
extend: 'Ext.Panel',
xtype: 'preference',
config: {
    scrollable: true,
    //id: 'id-vw-preferences',
    layout: {
        type: 'fit'
    },
    style: "background-color: white",
    items: [
            
        {//space decoration
            xtype: 'spacer',
            height: '50px'
        },
        {
            xtype: 'panel',
            cls: 'vm-panel',
            items: [
                {
                    xtype: "fieldset",
                    items: [

                        { //Language
                            xtype: 'selectfield',
                            id: 'cboLanguage',
                            label: 'Language',
                            //height: 60,
                            labelWidth: '45%',
                            options: [
                            /*{
                            text: 'বাংলা ', value: 'Bengali'
                            },*/
                                    {
                                    text: 'English', value: 'English'
                                },
                                    {
                                        text: 'हिन्दी', value: 'Hindi'
                                    }

                            ],
                            listeners: {
                                painted: function (language) {
                                    this.fireEvent("SelectLanguagePainted", this, language);
                                }
                            }
                        },
                        { //Keep me logged in
                            xtype: "togglefield",
                            name: "tglkeepmeloggedin",
                            id: 'idToggle',
                            cls: 'vm-toggle-field',
                            label: 'Keep me logged in',
                            labelWidth: '45%',
                            action: 'keepmeloggedintoggle'
                        },
                        { //Read Offline
                            xtype: "togglefield",
                            name: "tglOfflineReading",
                            id: 'tglOfflineReading',
                            cls: 'vm-toggle-field',
                            label: 'Read Offline',
                            labelWidth: '45%',
                            action: 'OfflineReadingtoggle'
                        },
                        { //Landscape Orientation
                            xtype: "togglefield",
                            name: "tglOrientation",
                            id: 'tglLandscapeOrientation',
                            cls: 'vm-toggle-field',
                            label: 'Landscape Orientation',
                            labelWidth: '45%',
                            action: 'LandscapeOrientationtoggle'
                        },
                        {
                            xtype: 'fieldset',
                            cls: 'vm-innerFieldset',
                            margin: 0,
                            items: [
                                { // Sync master data label
                                    xtype: 'field',
                                    id: 'lblSyncCatalog',
                                    label: 'Sync catalog',
                                    width: '45%',
                                    labelWidth: '100%'
                                },
                                { //sync master data button
                                    left: '46%',
                                    top: '15%',
                                    items: [
                                        {
                                            xtype: "button",
                                            cls: 'vm-btn',
                                            itemId: 'btnSyncData',
                                            action: 'btnSyncDataClick',
                                            text: '<i class="icon-refresh"></i>'
                                        }
                                    ]
                                }
                            ]
                        },
                        { //Language
                            xtype: 'fieldset',
                            margin: 0,
                            //style:'border-top:none;border-radius:0;',
                            cls: 'vm-innerFieldsetSelect',
                            items: [
                            {
                                xtype: 'selectfield',
                                id: 'cboThemeChanger',
                                label: 'Theme',
                                //height: 60,
                                labelWidth: '45%',
                                options: [
                                    {
                                        text: 'Green', value: 'Green'
                                    },
                                    {
                                        text: 'Blue', value: 'Blue'
                                    },
                                    {
                                        text: 'Pink', value: 'Pink'
                                    },
                                    {
                                        text: 'Red', value: 'Red'
                                    },
                                    {
                                        text: 'Orange', value: 'Orange'
                                    }

                                ]
                            }
                            ],
                            listeners: {
                                painted: function () {
                                    switch ((localStorage.getItem('curTheme')).split(',')[0]) {
                                        case "Blue":
                                            Ext.getCmp("cboThemeChanger").setValue('Blue');
                                            break;
                                        case "Pink":
                                            Ext.getCmp("cboThemeChanger").setValue('Pink');
                                            break;
                                        case "Red":
                                            Ext.getCmp("cboThemeChanger").setValue('Red');
                                            break;
                                        case "Orange":
                                            Ext.getCmp("cboThemeChanger").setValue('Orange');
                                            break;
                                        case "Green":
                                            Ext.getCmp("cboThemeChanger").setValue('Green');
                                            break;
                                        default: return;
                                    }
                                }
                            }
                        }
                    ]
                }
            ]
        },
        { //spacer decoration
            xtype: 'spacer',
            height: '25px'
        }
    ]
},
initialize: function () {
    console.log("Preference view initialize");
    this.callParent(arguments);
    this.on('painted', this.painted);
},
painted: function () {
    console.log("Preference view painted");
    //Ext.getCmp('id-footer').setActiveTab(4);
    Ext.getCmp("idToggle").setValue(localStorage.getItem('Inbooks-keepmeloggedin'));
    Ext.getCmp("tglOfflineReading").setValue(localStorage.getItem('ReadOffline'));
    Ext.getCmp('tglLandscapeOrientation').setValue(localStorage.getItem('LandscapeOrientation'));
    Ext.getCmp("cboLanguage").setLabel(g_l['lbl0009']);
    Ext.getCmp("idToggle").setLabel(g_l['lbl0010']);
    Ext.getCmp("lblSyncCatalog").setLabel(g_l['lbl0011']);
    Ext.getCmp("cboThemeChanger").setLabel(g_l['lbl0036']);
    Ext.getCmp("tglOfflineReading").setLabel(g_l['lbl0044']);
    Ext.getCmp("tglLandscapeOrientation").setLabel(g_l['lbl0050']);
}
});