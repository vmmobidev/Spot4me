﻿Ext.define('com.inbooks.controller.PreferenceController', {
    extend: 'Ext.app.Controller',
    requires: [
            'com.inbooks.view.Preference'
    ],
    config: {
        refs: {
            language: 'preference #cboLanguage',
            theme: 'preference #cboThemeChanger'
        },
        control: {
            'button[action=btnSyncDataClick]': { tap: 'SyncCatalog' },
            language:{change:'bindLanguageDropdown',SelectLanguagePainted:'onSelectLanguagePainted'},
            theme:{change:'bindHeaderThemeOnThemeChange'},
            'togglefield[action=keepmeloggedintoggle]': { change: 'keepmeloggedin_toggle' },
            'togglefield[action=OfflineReadingtoggle]': { change: 'offlineReading_toggle' },
            'togglefield[action=LandscapeOrientationtoggle]': { change: 'LandscapeOrientation_toggle' }
        }
    },
    bindLanguageDropdown:function(select, newValue, oldValue){debugger
        var prefLang;
        switch(newValue){
            case "Hindi":
                prefLang="HIN";
                break;
            case "English":
                prefLang="ENG";
                break;
            case "Bengali":
                prefLang="BEN";
                break;
            default:return;
        }
        localStorage.setItem('lang',prefLang);
        com.inbooks.classes.Helpers.setLanguage(prefLang);
        var userName = Ext.JSON.decode(localStorage.getItem("user")).Name;
        //Ext.getCmp("viewHeader").setTitle("<div><div style='white-space: nowrap; overflow: hidden; text-overflow: ellipsis;width: 100%;font-size:10pt;'><h6>"+ g_m['msg0038'] + "&nbsp; " + userName +"</h6></div></div>");
        Ext.getCmp("btnFooterHome").setTitle( g_l['lbl0005']);
        Ext.getCmp("btnFooterCatalog").setTitle( g_l['lbl0006']);
        Ext.getCmp("btnFooterBookshelf").setTitle(g_l['lbl0007']);
        Ext.getCmp("btnFooterSearch").setTitle(g_l['lbl0048']);
        Ext.getCmp("btnFooterSettings").setTitle( g_l['lbl0008']);
        Ext.getCmp("cboLanguage").setLabel( g_l['lbl0009']);
        Ext.getCmp("idToggle").setLabel( g_l['lbl0010']);
        Ext.getCmp("lblSyncCatalog").setLabel( g_l['lbl0011']);
        Ext.getCmp("cboThemeChanger").setLabel(g_l['lbl0036']);
        Ext.getCmp("tglOfflineReading").setLabel(g_l['lbl0044']);
        Ext.getCmp("idpreferences").tab.setTitle(g_l['lbl0047']);
        Ext.getCmp("tglLandscapeOrientation").setLabel(g_l['lbl0050']);
        Ext.getCmp("idprofile").tab.setTitle(g_l['lbl0046']);
        Ext.getCmp("headerlogo").setHtml('<span class="vm-img-logo"><img src="resources/images/logo-small.png" /></span><span class="vm-logo-txt">' + g_l['lbl0049'] + '</span>');
        
        
    },
    onSelectLanguagePainted:function(){
        switch(localStorage.getItem('lang')){
            case "HIN":
                Ext.getCmp("cboLanguage").setValue('Hindi');
                break;
            case "ENG":
            default:
                Ext.getCmp("cboLanguage").setValue('English');
                break;
            case "BEN":
                Ext.getCmp("cboLanguage").setValue('Bengali');
                break;
        }

    },
    SyncCatalog: function(btn){
        setTimeout(function(){
            Ext.Viewport.setMasked({
                xtype: 'loadmask',
                indicator: true,
                message: '' + g_m['msg0041'] + ''
            });
        },5);
        com.inbooks.app.fireEvent('LoadAllMasters', btn);
    },
    bindHeaderThemeOnThemeChange:function(select, newValue, oldValue){
        switch(newValue){
            /*css styles are expilcitly added here beacause adding classes will need the header to be rapinted again gor the sttings page*/
            case 'Blue':
                localStorage.setItem('curTheme',"Blue,vm-blue-theme");
                Ext.getCmp('viewHeader').setStyle('background-image: -ms-linear-gradient(bottom, #96DFF9 0%, #10A5DA 100%);background-image: -moz-linear-gradient(bottom, #96DFF9 0%, #10A5DA 100%);background-image: -o-linear-gradient(bottom, #96DFF9 0%, #10A5DA 100%);background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, #96DFF9), color-stop(1, #10A5DA));background-image: -webkit-linear-gradient(bottom, #96DFF9 0%, #10A5DA 100%);background-image: linear-gradient(to top, #96DFF9 0%, #10A5DA 100%);');
                break;
            case 'Pink':
                localStorage.setItem('curTheme',"Pink,vm-pink-theme");
                Ext.getCmp('viewHeader').setStyle('background-image: -ms-linear-gradient(bottom, #F4A7DE 0%, #EB008C 100%);background-image: -moz-linear-gradient(bottom, #F4A7DE 0%, #EB008C 100%);background-image: -o-linear-gradient(bottom, #F4A7DE 0%, #EB008C 100%);background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, #F4A7DE), color-stop(1, #EB008C));background-image: -webkit-linear-gradient(bottom, #F4A7DE 0%, #EB008C 100%);background-image: linear-gradient(to top, #F4A7DE 0%, #EB008C 100%);');
                break;
            case 'Red':
                localStorage.setItem('curTheme',"Red,vm-red-theme");
                Ext.getCmp('viewHeader').setStyle('background-image: -ms-linear-gradient(bottom, #F98989 0%, #F52626 100%);background-image: -moz-linear-gradient(bottom, #F98989 0%, #F52626 100%);background-image: -o-linear-gradient(bottom, #F98989 0%, #F52626 100%);background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, #F98989), color-stop(1, #F52626));background-image: -webkit-linear-gradient(bottom, #F98989 0%, #F52626 100%);background-image: linear-gradient(to top, #F98989 0%, #F52626 100%);');
                break;
            case 'Orange':
                localStorage.setItem('curTheme',"Orange,vm-orange-theme");
                Ext.getCmp('viewHeader').setStyle('background-image: -ms-linear-gradient(bottom, #F8CA87 0%, #FA9B13 100%);background-image: -moz-linear-gradient(bottom, #F8CA87 0%, #FA9B13 100%);background-image: -o-linear-gradient(bottom, #F8CA87 0%, #FA9B13 100%);background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, #F8CA87), color-stop(1, #FA9B13));background-image: -webkit-linear-gradient(bottom, #F8CA87 0%, #FA9B13 100%);background-image: linear-gradient(to top, #F8CA87 0%, #FA9B13 100%);');
                break;
            case 'Green':
                localStorage.setItem('curTheme',"Green,vm-green-theme");
                Ext.getCmp('viewHeader').setStyle('background-image: -ms-linear-gradient(bottom, #E5EFAF 0%, #BAD42C 100%);background-image: -moz-linear-gradient(bottom, #E5EFAF 0%, #BAD42C 100%);background-image: -o-linear-gradient(bottom, #E5EFAF 0%, #BAD42C 100%);background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, #E5EFAF), color-stop(1, #BAD42C));background-image: -webkit-linear-gradient(bottom, #E5EFAF 0%, #BAD42C 100%);background-image: linear-gradient(to top, #E5EFAF 0%, #BAD42C 100%);');
                break;
            default:return;
        }
    },
    keepmeloggedin_toggle: function () {
        console.log("Preference controller keepmeloggedin_toggle - starts");
        var val = Ext.getCmp("idToggle").getValues();
        //@#$ console.log("Keep me Logged in set to - " + val);
        localStorage.setItem("Inbooks-keepmeloggedin", val);
        console.log("Preference controller keepmeloggedin_toggle - ends");
    },
    offlineReading_toggle: function(){
        console.log("Preference controller offlineReading_toggle - starts");
            var readofflinechoice = Ext.getCmp("tglOfflineReading").getValues();
             localStorage.setItem("ReadOffline",readofflinechoice);
        console.log("Preference controller offlineReading_toggle - ends");
    },
    LandscapeOrientation_toggle: function () {
        console.log("Preference controller LandscapeOrientation_toggle - starts");
        var ChangeOrientation = Ext.getCmp("tglLandscapeOrientation").getValues();
        localStorage.setItem("LandscapeOrientation", ChangeOrientation);
        try{
            if(ChangeOrientation){
                //Change the orientation to default
                window.MyCls.changeToDefaultOrientation();
            }
            else{
                //Change the orientation to portrait
                window.MyCls.changeToPortrait();
            }
        }
        catch(e){}

        console.log("Preference controller LandscapeOrientation_toggle - ends");
    },
    launch: function () {
        console.log("Preference Controller - Launch");
    },
    init: function () {
        console.log("Preference Controller - Init");
    }
});
