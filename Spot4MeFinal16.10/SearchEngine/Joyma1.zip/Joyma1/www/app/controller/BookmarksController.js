Ext.define('com.inbooks.controller.BookmarksController', {
    extend: 'Ext.app.Controller',
    requires: [
        'com.inbooks.view.Bookmarks'
    ],
    config: {
        refs: {
            bookmark: 'bookmarks #id-bookmark-items'
        },
        control: {
            bookmark: { itemtap: 'bookmarkItemClick' }
        }
    },
    bookmarkItemClick: function(list, idx, target, record, evt){
        console.log("BookmarksController bookmarkClick - start");
        //show the loading mask
        setTimeout(function(){
            Ext.Viewport.setMasked({
                xtype: 'loadmask',
                indicator: true,
                message: g_m['msg0048']
            });
        }, 10);
        try{
            var carouselCmp = Ext.getCmp('carousel-reader');
            Ext.getCmp('btnBookmark').setPressedButtons(false);
            //Set active item of carousel to the item clicked in bookmarks
            carouselCmp.setActiveItem(record.data.PageId-1);

            var i = $('#imgPage_' + carouselCmp.activeIndex);
            //Load carousel page
            com.inbooks.classes.Helpers.loadCarouselImage(carouselCmp, i);
        }
        catch(e){
            console.log(e.message);
        }
        setTimeout(function(){
            Ext.Viewport.setMasked(false);
        }, 50);
        console.log("BookmarksController bookmarkClick - end");
    },
    launch: function () {
        console.log("BookmarksController - Launch");
    },
    init: function () {
        console.log("BookmarksController - Init");
    }
});
