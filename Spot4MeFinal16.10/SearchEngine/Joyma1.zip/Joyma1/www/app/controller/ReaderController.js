var me = {};
Ext.define('com.inbooks.controller.ReaderController', {
    extend: 'Ext.app.Controller',
    requires: [
        'com.inbooks.view.Reader'
    ],
    config: {
        refs: {
            carousel: '#carousel-reader',   //Reference to the carousel
            bookmark: 'reader #btnBookmark'
        },
        control: {
            "reader #carousel-reader": { activeitemchange: 'onCarouselActiveItemChange' },
            'button[action=btnPreviousPage]': { tap: 'previousPage' },
            'button[action=btnNextPage]': { tap: 'nextPage' },
            'bookmark': { toggle: 'btnBookmarkClick' }
        }
    },
    onCarouselActiveItemChange: function(newActiveItem, itm, oldActiveItem, eOpts){
        console.log("onCarouselActiveItemChange - Start");
        //Image Resizing to adjust in both the orientations
        try{
            //Disable the scroller initially
            var scroller = Ext.getCmp('carousel-reader').getActiveItem().getScrollable().getScroller().setDisabled(true);
            $('#imgPage_'+Ext.getCmp('carousel-reader').activeIndex).css('webkitTransform', 'scale(1)');
            $('#imgPage_'+Ext.getCmp('carousel-reader').activeIndex).css('width', window.innerWidth+'px');
            $('#imgPage_'+Ext.getCmp('carousel-reader').activeIndex).css('height', (window.innerHeight-175)+'px');//Header=50, Footer=50, TitleBar=50, PageNavigator=50, Total=175
        }
        catch(e){console.log(e.message)}
        var cmp = Ext.getCmp('carouselTitleBar');
        var carouselCmp = this.getCarousel();
        setTimeout(function(){
            Ext.getCmp('carousel-reader').items.items[carouselCmp.activeIndex].setMasked({
            //Ext.Viewport.setMasked({
                xtype: 'loadmask',
                indicator: true,
                message: g_m['msg0048']
            });
        }, 100);


        //Update slidervalue if its open
        try{
            setTimeout(function(){
                if(Ext.getCmp('goto-page-slider')!=undefined){
                    Ext.getCmp('goto-page-slider').setValue((carouselCmp.activeIndex)+1);
                    $('.x-thumb')[0].innerHTML = (carouselCmp.activeIndex)+1;
                }
            }, 100);
        }
        catch(e){console.log(e.message)}
        //Prefetch the next 5 pages in advance
        com.inbooks.classes.Helpers.prefetchSubsequentPages();
        var i = $('#imgPage_' + carouselCmp.activeIndex);

        cmp.setTitle((newActiveItem.activeIndex+1)+ " of " + this.getCarousel().getItems().length + " pages");
        if((carouselCmp.activeIndex) == (carouselCmp.items.length-1)){
            Ext.getCmp('btnNextPage').disable();
        }
        else{
            Ext.getCmp('btnNextPage').enable();
        }
        if((carouselCmp.activeIndex) == 0){
            Ext.getCmp('btnPreviousPage').disable();
        }
        else{
            Ext.getCmp('btnPreviousPage').enable();
        }
        //Load carousel page image
        com.inbooks.classes.Helpers.loadCarouselImage(carouselCmp, i);
        console.log("onCarouselActiveItemChange - End");
    },
    previousPage: function (page) {
        console.log("ReaderController previousPage - Start");
        try {
            var cmp = this.getCarousel();
            cmp.previous();
        } catch (e) { console.log("Error while clicking previousPage, page index = " + (cmp.activeIndex - 1))  }
        console.log("ReaderController previousPage - End");
    },
    nextPage: function (page) {
        console.log("ReaderController nextPage - Start");
        try {
            var cmp = this.getCarousel();
            cmp.next();
        } catch (e) {
            console.log("Error while clicking nextPage, page index = " + (cmp.activeIndex + 1))
        }
        console.log("ReaderController nextPage - End");
    },
    btnBookmarkClick: function(btn, button, isPressed, eOpts){
        console.log("ReaderController btnBookmarkClick - Start");
        if (com.inbooks.app.g_bookmarkPanel == null) {
            com.inbooks.app.g_bookmarkPanel = Ext.Viewport.add({
                xtype: 'bookmarks',
                id: 'pnlBookmarks',
                width: '50%',
                height: '60%'
                /*showAnimation:
                {
                    type: 'slideIn',
                    duration: 1000,
                    direction: 'left'
                },
                hideAnimation:
                {
                    type: 'slideOut',
                    duration: 1000,
                    direction: 'right'
                }*/
            });
        }

        if (isPressed) {
            //try { bookMarkView.hide() } catch (e) { }
            com.inbooks.app.g_bookmarkPanel.showBy(btn);
        } else { try { com.inbooks.app.g_bookmarkPanel.hide(); } catch (e) { } }
        console.log("ReaderController btnBookmarkClick - Start");
    },
    launch: function () {
        console.log("ReaderController - Launch");
    },
    init: function () {
        console.log("ReaderController - Init");
        com.inbooks.app.on('CarouselItemPinch', this.onCarouselItemPinch);
        com.inbooks.app.on('CarouselItemPinchStart', this.onCarouselItemPinchStart);
        com.inbooks.app.on('CarouselItemPinchEnd', this.onCarouselItemPinchEnd);
    },
    onCarouselItemPinch: function (item, cmp) {
        console.log("Carousel item Pinch handler-start");
        com.inbooks.app.g_pinchEndScale = item.scale;
        item.preventDefault();
        this.scale = item.scale * com.inbooks.app.g_pinchStartScale;

        //document.getElementById('imgPage_'+Ext.getCmp('carousel-reader').activeIndex).style.webkitTransform = 'scale('+this.scale+')';
        document.getElementById('imgPage_'+Ext.getCmp('carousel-reader').activeIndex).style.webkitTransform = 'matrix('+ this.scale +', 0, 0,'+ this.scale +', ' + 100 +', '+10+')';
        console.log("Carousel item Pinch handler-end");
    },
    onCarouselItemPinchStart: function (item, cmp) {
        console.log("Carousel item PinchStart handler-start");
        /*com.inbooks.app.g_minWidth = document.getElementById("imgPage_"+(Ext.getCmp('carousel-reader').activeIndex)).clientWidth;
        com.inbooks.app.g_minHeight = document.getElementById("imgPage_"+(Ext.getCmp('carousel-reader').activeIndex)).clientHeight;*/
        com.inbooks.app.g_pinchStartScale = item.scale;
        console.log("Carousel item PinchStart handler-end");
    },
    onCarouselItemPinchEnd: function (item, cmp) {
        console.log("Carousel item PinchEnd handler-start");
        com.inbooks.app.getController('ReaderController').adjustScroller();
        me = item;
        /*me = cmp;
        me.img1 = cmp.element.down('img');
        me.imgWidth = document.getElementById("imgPage_"+(Ext.getCmp('carousel-reader').activeIndex)).clientWidth;//me.img1.dom.width;
        me.imgHeight = document.getElementById("imgPage_"+(Ext.getCmp('carousel-reader').activeIndex)).clientHeight;//me.img1.dom.height;
        if((com.inbooks.app.g_minWidth == null) ||(com.inbooks.app.g_minHeight == null)){
            com.inbooks.app.g_minWidth = me.imgWidth;
            com.inbooks.app.g_minHeight = me.imgHeight;
        }
        if(com.inbooks.app.g_pinchStartScale<=com.inbooks.app.g_pinchEndScale){
            var modifiedImgWidth = me.imgWidth+((25*com.inbooks.app.g_minWidth)/100);
            var modifiedImgHeight = me.imgHeight+((25*com.inbooks.app.g_minHeight)/100);

            console.log("com.inbooks.app.g_minWidth: "+com.inbooks.app.g_minWidth);
            console.log("com.inbooks.app.g_minHeight: "+com.inbooks.app.g_minHeight);
            console.log("modifiedImgWidth: "+ modifiedImgWidth);
            console.log("modifiedImgHeight: "+ modifiedImgHeight);

            $("#imgPage_"+(Ext.getCmp('carousel-reader').activeIndex)).css("width", modifiedImgWidth);
            $("#imgPage_"+(Ext.getCmp('carousel-reader').activeIndex)).css("height", modifiedImgHeight);
            //document.getElementById('imgPage_'+(Ext.getCmp('carousel-reader').activeIndex)).style.webkitTransform = 'scale3d('+com.inbooks.app.g_pinchStartScale+','+com.inbooks.app.g_pinchEndScale+',0)';

            //Enable scrolling
            Ext.getCmp("carousel-reader").getActiveItem().setScrollable(true);
            *//*me.img1.setWidth(modifiedImgWidth);
            me.img1.setHeight(modifiedImgHeight);*//*
        }
        else{
            var modifiedImgWidth = me.imgWidth-((25*com.inbooks.app.g_minWidth)/100);
            var modifiedImgHeight = me.imgHeight-((25*com.inbooks.app.g_minHeight)/100);
            console.log("com.inbooks.app.g_minWidth: "+com.inbooks.app.g_minWidth);
            console.log("com.inbooks.app.g_minHeight: "+com.inbooks.app.g_minHeight);
            console.log("modifiedImgWidth: "+ modifiedImgWidth);
            console.log("modifiedImgHeight: "+ modifiedImgHeight);
            if((modifiedImgWidth>=com.inbooks.app.g_minWidth) || (modifiedImgHeight >= com.inbooks.app.g_minHeight)){
                $("#imgPage_"+(Ext.getCmp('carousel-reader').activeIndex)).css("width", modifiedImgWidth);
                $("#imgPage_"+(Ext.getCmp('carousel-reader').activeIndex)).css("height", modifiedImgHeight);
                //document.getElementById('imgPage_'+(Ext.getCmp('carousel-reader').activeIndex)).style.webkitTransform = 'scale3d('+com.inbooks.app.g_pinchStartScale+','+com.inbooks.app.g_pinchEndScale+',0)';

                if((modifiedImgWidth==com.inbooks.app.g_minWidth) || (modifiedImgHeight == com.inbooks.app.g_minHeight)){
                    //Disable scrolling
                    Ext.getCmp("carousel-reader").getActiveItem().setScrollable(false);
                }
                else{
                    //Enable scrolling
                    Ext.getCmp("carousel-reader").getActiveItem().setScrollable(true);
                }
                *//*me.img1.setWidth(modifiedImgWidth);
                me.img1.setHeight(modifiedImgHeight);*//*
            }
        }*/
        console.log("Carousel item PinchEnd handler-end");
    },
    adjustScroller: function() {
        console.log("adjustScroller start")
        me = Ext.getCmp('carousel-reader').items.items[Ext.getCmp('carousel-reader').activeIndex];
        var scroller = Ext.getCmp('carousel-reader').getActiveItem().getScrollable().getScroller(),
            scale = com.inbooks.app.g_pinchEndScale;

        // size container to final page size
        var boundWidth = com.inbooks.app.g_minWidth * scale ;
        var boundHeight = com.inbooks.app.g_minHeight * scale ;

        if((boundWidth>=com.inbooks.app.g_minWidth) && (boundHeight>=com.inbooks.app.g_minHeight)){
            console.log("if: condition");
            $('#imgPage_'+Ext.getCmp('carousel-reader').activeIndex).css('webkitTransform', 'scale(1)');
            $('#imgPage_'+Ext.getCmp('carousel-reader').activeIndex).css('width', boundWidth + 'px');
            $('#imgPage_'+Ext.getCmp('carousel-reader').activeIndex).css('height', boundHeight + 'px');
            //Enable the scroller if image size is larger than minimum size
            scroller.setDisabled(false);
            scroller.scrollTo(me.pageX*scale, me.pageY*scale);
            //Ext.getCmp('carousel-reader').items.items[Ext.getCmp('carousel-reader').activeIndex].element.down('img').setStyle({width : boundWidth + 'px', height: boundHeight + 'px'});
        }
        else{
            console.log("else: condition: com.inbooks.app.g_minWidth: "+com.inbooks.app.g_minWidth+"com.inbooks.app.g_minHeight: "+com.inbooks.app.g_minHeight);
            $('#imgPage_'+Ext.getCmp('carousel-reader').activeIndex).css('webkitTransform', 'scale(1)');
            $('#imgPage_'+Ext.getCmp('carousel-reader').activeIndex).css('width', com.inbooks.app.g_minWidth + 'px');
            $('#imgPage_'+Ext.getCmp('carousel-reader').activeIndex).css('height', com.inbooks.app.g_minHeight + 'px');
            //Disable the scroller if image size is minimum
            scroller.setDisabled(true);
            //Ext.getCmp('carousel-reader').items.items[Ext.getCmp('carousel-reader').activeIndex].element.down('img').setStyle({width : com.inbooks.app.g_minWidth + 'px', height: com.inbooks.app.g_minHeight + 'px'});
        }

        // update scroller to new content size
        //scroller.refresh();

        // apply scroll
        /*var x = 0;
        if (me.scrollX) {
            x = me.scrollX;
        }

        var y = 0;
        if (me.scrollY) {
            y = me.scrollY;
        }*/
        console.log("adjustScroller end")
    }
});
