﻿Ext.define('com.inbooks.controller.DashboardController', {
    extend: 'Ext.app.Controller',
    requires: [
        'com.inbooks.view.Dashboard'
    ],
    config: {
        refs: {},
        control: {}
    },
    
    launch: function () {
         console.log("Dashboard Controller - Launch");
    },
    init: function () {
         console.log("Dashboard Controller - Init");
    }

});
