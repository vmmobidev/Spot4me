﻿Ext.define('com.inbooks.controller.HeaderController', {
    extend: 'Ext.app.Controller',
    requires: [
        'com.inbooks.view.Header'
],
    config: {
        refs: {},
        control: {
            'button[action=btnLogoutClick]': { tap: 'btnLogout_Click' },
            'button[action=btnBackClick]': { tap: 'btnBack_Click' }
        }
    },
    launch: function () {
        console.log("Header Controller - Launch");
    },

    init: function () {
        console.log("Header Controller - Init");
    },

    btnLogout_Click: function () {
        console.log("Header Controller - btnLogout_Click");

        //show the loading mask
        Ext.Viewport.setMasked({
            xtype: 'loadmask',
            indicator: true,
            message: 'Logging Out....'
        });

        //Clearing global variables
        com.inbooks.app.g_viewportCaller = null;
        com.inbooks.app.g_arrNavHistory = [];
        com.inbooks.app.g_clrNavHistory = true;
        com.inbooks.app.g_bookshelf = null;

        //Destroying header buttons
        com.inbooks.app.destroyHeaderButtons();

        //Removing 'AllBookshelf' from localstorage
        localStorage.removeItem("AllBookshelf");

        //keep me logged in value set to zero
        localStorage.setItem("Inbooks-keepmeloggedin", 0);

        Ext.Viewport.setActiveItem(Ext.create('com.inbooks.view.Login'));

        // hide the loading mask
        Ext.Viewport.setMasked(false);

    },
    btnBack_Click: function () {
        onBackKeyDown();

    }

});
