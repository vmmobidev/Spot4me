Ext.define('com.inbooks.controller.MusicController', {
    extend: 'Ext.app.Controller',
    requires: [
        'com.inbooks.view.Music'
    ],
    config: {
        refs: {
            music: 'music #tplMusicLst'
        },
        control: {
            music: { disclose: 'showAudioPlayer' }
        }
    },
    showAudioPlayer: function(lst, data, args, index){
        console.log("MusicController showReader - start");
        try{
            Ext.getCmp('id-audio').destroy();
        }
        catch(e){
            console.log(e.message);
        }
        var audio = Ext.create('Ext.Panel', {
            id: 'id-audio',
            style: 'position: absolute; top: 25px; left: 75px; width: 50%;',
            html: '<audio id="id-audio-control" controls autoplay preload="auto" type="audio/mpeg" codecs="mp3"></audio>'
        });
        //var audio = new Audio(data.data.url);
        //var media = new Media(data.data.url, function(){}, function(err){console.log("playAudio():Audio Error: "+err);});
        /*var audio = Ext.create("Ext.Panel",{
            id: 'id-audio',
            //html: '<audio controls="controls"><source src="'+ data.data.url +'" type="audio/mpeg"></audio>'
            html: '<audio controls="controls"><source src="/resources/mp3/ChhodAayeHum.mp3" type="audio/mpeg"></audio>'
        });*/
        //media.play();
        args.element.dom.appendChild(audio.element.dom);
        $("#id-audio-control").attr('src', data.data.url);
        document.getElementById("id-audio-control").play();
        console.log("MusicController showReader - end");
    },
    launch: function () {
        console.log("MusicController - Launch");
    },
    init: function () {
        console.log("MusicController - Init");
    }
});

