
Ext.define('com.inbooks.controller.SignUpController', {
extend: 'Ext.app.Controller',
requires: [
    'com.inbooks.view.SignUp'
],
config: {
    refs: {
        signupForm: 'signup'
    },
    control: {
        'button[action=btnRegisterClick]': { tap: 'btnRegister_Click' },
        'button[action=btnCancelClick]': { tap: 'btnCancel_Click' }
    }
},

launch: function () {
    console.log("Signup Controller - Launch");
},

init: function () {
    console.log("Signup Controller - Init");
},

btnRegister_Click: function () {
    console.log("Signup Controller - btnRegister_click");
    hideKeyboard(); // Calling this function for resigning the keyboard 
    
    var objFields = this.getSignupForm().getFields();
    var hasPassedEmptyFieldsValidation = com.inbooks.classes.Helpers.validateFormFields(objFields);
    var hasPassedCustomValidation = this.customValidations(objFields);

    if (hasPassedEmptyFieldsValidation && hasPassedCustomValidation) {
        this.register();
        //Ext.Viewport.setActiveItem(Ext.create('com.inbooks.view.Dashboard'));
    }
},

customValidations: function (objFields) {
    var isValid = true;
    // Check for valid email id
    var objField = objFields["txtEmail"];
    var isEmailValid = com.inbooks.classes.Helpers.emailIsValid(objField);

    if (isEmailValid) {
        return true;
    }
    else {
        return false;
    }
},

register: function () {
    //show the loading mask
    Ext.Viewport.setMasked({
        xtype: 'loadmask',
        indicator: true,
        message: 'Loading...'
    });
    console.log("Registeration - start");

    var formvalues = this.getSignupForm().getValues();
    var username = formvalues.txtUsername;
    var password = formvalues.txtPassword;
    var name = formvalues.txtFullname;
    var gender = formvalues.drpGender;
    var email = formvalues.txtEmail;
    var mobile = formvalues.txtMobile;

    try {

        var params = '{ "request": { "MethodType": "POST", "UserName" : ' + '"' + username + '"' + ', "Password" : ' + '"' + password + '"' + ', "Name" : ' + '"' + name + '"' + ', "Gender" : ' + '"' + gender + '"' + ', "Email" : ' + '"' + email + '"' + ', "MobilePhone" : ' + '"' + mobile + '"' + ', "ReferredBy": 1, "Status": true, "CreatedBy": 1, "ModifiedBy": 1} }';

        var headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };

        com.inbooks.classes.Helpers.Ajax('/User/0', params, 'POST', 'JSON', this.onSignupCallback, '', headers);
    }
    catch (e) { }

    console.log("Registeration - end");
},

onSignupCallback: function (options, success, response) {
    console.log("SignupCallback callback");
    if (success) {
        var response = Ext.JSON.decode(response.responseText);
        var userData = Ext.JSON.encode(response.aaData.Profile);
        localStorage.setItem("user", userData);

        if (response.aaData.Success) {

            com.inbooks.app.destroyHeaderButtons();            
            com.inbooks.app.g_clrNavHistory = true;
            com.inbooks.app.g_viewportCaller = null;
            com.inbooks.app.g_arrNavHistory = [];
            
            localStorage.removeItem("AllBookshelf"); 
            
            setTimeout(function () {
                Ext.Viewport.setActiveItem(Ext.create('com.inbooks.view.Dashboard'));
                Ext.Viewport.setMasked(false);
            }, 1000);
        }
        else {
            //failure flow
            msg = g_m['msg0010'];
            com.inbooks.classes.Helpers.notifyError(msg, true);
            //Hide the progress mask
            Ext.Viewport.setMasked(false);
        }

    } else {

        //Possibly request timed out.
        var message = (response.timedout || response.statusText == "") ? g_m['msg0020'] : response.statusText;
        com.inbooks.classes.Helpers.notifyError(message, true); //message,showAsModal
        
        //Hide the progress mask
        Ext.Viewport.setMasked(false);
    }

},

btnCancel_Click: function () {

    console.log("Signup Controller - btnCancel_click");
    hideKeyboard(); // Calling this function for resigning the keyboard
    
    //Destroying header buttons
    com.inbooks.app.destroyHeaderButtons();
    com.inbooks.app.g_arrNavHistory.pop();
    
    Ext.Viewport.add(Ext.create('com.inbooks.view.Login'));
}

});

