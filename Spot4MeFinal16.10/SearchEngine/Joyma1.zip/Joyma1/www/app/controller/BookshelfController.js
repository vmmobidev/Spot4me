Ext.define('com.inbooks.controller.BookshelfController', {
    extend: 'Ext.app.Controller',
    requires: [
        'com.inbooks.view.Bookshelf'
    ],
    config: {
        refs: {
            bookShelf: 'bookshelf #bookshelf-list'
        },
        control: {
            bookShelf: { disclose: 'showMyBookReader' }
        }
    },
    showMyBookReader: function(lst, data, args){
        console.log("BookshelfController showReader - start");
        try{
            //Store book details in global variable
            com.inbooks.app.g_selectedBookDetails = data.data;
            //Update page details
            com.inbooks.app.g_pages = Ext.JSON.decode(data.data.Pages);
            com.inbooks.app.g_bookId = data.data.Id;
            com.inbooks.app.g_bookTitle = data.data.Name;
            com.inbooks.app.destroyHeaderButtons();
            Ext.Viewport.setActiveItem(Ext.create("com.inbooks.view.Reader"));
            Ext.getCmp('id-footer').setActiveTab(2);
        }
        catch(e){
            console.log(e.message);
        }
        console.log("BookshelfController showReader - end");
    },
    launch: function () {
        console.log("BookshelfController - Launch");
    },
    init: function () {
        console.log("BookshelfController - Init");
    }
});
