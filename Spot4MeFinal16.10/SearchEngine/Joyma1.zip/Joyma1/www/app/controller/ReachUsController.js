Ext.define('com.inbooks.controller.ReachUsController', {
    extend: 'Ext.app.Controller',
    requires: [
        'com.inbooks.view.ReachUs'
    ],
    config: {
        refs: {
             ReachUsForm:'reachus'
        },
        control: {
            'button[action=btnReachUsSendClick]': { tap: 'ReachUsSendClick' }
        }
    },
    launch: function () {
        console.log("ReachUS Controller - Launch");
    },
    init: function () {
        console.log("ReachUS Controller - Init");
    },
    ReachUsSendClick: function(){
        console.log("ReachUS Controller Sendclick- start");
     
        hideKeyboard();// Calling this function for resigning the keyboard
        var objFields=this.getReachUsForm().getFields();
        var hasPassedEmptyFieldsValidation = com.inbooks.classes.Helpers.validateFormFields(objFields);
        if (hasPassedEmptyFieldsValidation) {
            this.reachUs();
        }
        console.log("ReachUS Controller Sendclick- end");
    },
    reachUs:function(){
        
        //show the loading mask
        Ext.Viewport.setMasked({
            xtype: 'loadmask',
            indicator: true,
            message: g_m['msg0057']
        });
        console.log("ReachUsSend - start");
        
        var loggedOnUser= Ext.JSON.decode(localStorage.getItem('user'));
        var formvalues = this.getReachUsForm().getValues();
        var message = formvalues.txtReachUsMessage;
        try {
            var request={}
            request.MethodType = "POST";
            request.SenderName = loggedOnUser.Name;
            request.SenderEmail =  loggedOnUser.Email;
            request.Message = message;
            var params = JSON.stringify({ 'request': request });
            //var params = '{ "request": { "MethodType": "POST", "SenderName" : ' + '"' + loggedOnUser.Name + '"' + ',"SenderEmail" : ' + '"' + loggedOnUser.Email + '"' + ', "Message" : ' + '"' + escapedString + '"' + ' } }';

            var headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
            com.inbooks.classes.Helpers.Ajax('/Contact/reachus', params, 'POST', 'JSON', this.onReachUsSendCallback, '', headers);
        }
        catch (e) {
            com.inbooks.classes.Helpers.notifyError("Ajax failed", true);
            //Ext.Msg.alert("");
            Ext.Viewport.setMasked(false);
        }
    },
    onReachUsSendCallback:function(options, success, response){
        console.log("SignupCallback callback");
        if (success) {
            Ext.Viewport.setMasked(false);
            com.inbooks.classes.Helpers.notifySuccess(g_m['msg0056'], true);   // global message variable is used since we need localization and the returned msg is in english.
        }
        else{
            com.inbooks.classes.Helpers.notifyError(g_m['msg0062'], true);
            //Ext.Msg.alert();
            Ext.Viewport.setMasked(false);
        }
    }
});
