Ext.define('com.inbooks.controller.SettingsController', {
    extend: 'Ext.app.Controller',
    requires: [
            'com.inbooks.view.Settings'
    ],
    config: {
        refs: {

        },
        control: {
        }
    },

    launch: function () {
        console.log("Settings Controller - Launch");
    },
    init: function () {
        console.log("Settings Controller - Init");
    }

});
