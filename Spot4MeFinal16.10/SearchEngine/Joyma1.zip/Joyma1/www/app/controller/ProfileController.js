Ext.define('com.inbooks.controller.ProfileController', {
    extend: 'Ext.app.Controller',
    requires: [
            'com.inbooks.view.Profile'
    ],
    config: {
        refs: {
            changeProfileForm: "profile"
        },
        control: {
            'button[action=btnChangeProfile]': { tap: 'btnChangeProfile_Click' }
        }
    },
    launch: function () {
        console.log("Profile Controller - Launch");
    },
    init: function () {
        console.log("Profile Controller - Init");
    },
    btnChangeProfile_Click: function () {

        hideKeyboard(); // Calling this function for resigning the keyboard
        /*Validate the entered information*/
        var objFields = this.getChangeProfileForm().getFields();
        // Using helper class function validateFormFields
        var hasPassedEmptyFieldsValidation = com.inbooks.classes.Helpers.validateFormFields(objFields);
        var hasPassedCustomValidation = this.customChangeProfileValidations(objFields);

        if (hasPassedEmptyFieldsValidation && hasPassedCustomValidation) {
            //Call Rest API to update changes to profile
            this.updateChangeProfile();
        }

    },

    customChangeProfileValidations: function (objFields) {
        var isValid = false;
        // Check for valid email id
        var objField = objFields["txtemailid"];
        isValid = com.inbooks.classes.Helpers.emailIsValid(objField);

        if (isValid) {
            // Check for valid contact number
            var objField = objFields["txtcontactnumberid"];
            isValid = com.inbooks.classes.Helpers.contactNumberIsValid(objField);
        }
        return isValid;
    },

    // Method to call the REST API to reset the user's Profile
    updateChangeProfile: function () {
        
        //show the loading mask
        Ext.Viewport.setMasked({
            xtype: 'loadmask',
            indicator: true,
            message: 'Updating....'
        });

        var formValues = this.getChangeProfileForm().getValues();
        var email = formValues.txtemailid;
        var mobile = formValues.txtcontactnumberid;

        var methodtype = "PUT";
        var userInfo = Ext.JSON.decode(localStorage.getItem("user"));
        var username = userInfo.UserName;        
        var name = userInfo.Name;
        var gender = userInfo.Gender;
        var referedby = 1;
        var status = true;
        var createdby = 1;
        var modifiedby = 1;
        var Id = userInfo.Id;
        try {
            var params = '{"request":{"MethodType" : ' + '"' + methodtype + '"' + ',"UserName" : ' + '"' + username + '"' + ', "Name" : ' + '"' + name + '"' + ', "Gender" : ' + '"' + gender + '"' + ',"Email" : ' + '"' + email + '"' + ',"MobilePhone" : ' + '"' + mobile + '"' + ', "ReferredBy": 1, "Status": true, "CreatedBy": 1, "ModifiedBy": 1, "Id" : '+ Id +' }}';            
            var headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
            com.inbooks.classes.Helpers.Ajax('/User/0', params, 'PUT', 'JSON', this.onChangeProfileCallback, '', headers);            
        }
        catch (e) { }
        console.log(params);
        
    },

    onChangeProfileCallback: function (options, success, response) {
        
        if (success) {
            var response = Ext.JSON.decode(response.responseText);
            if (response.aaData.Success) {

                var userData = Ext.JSON.decode(localStorage.getItem('user'));
                userData.Email = Ext.getCmp('usrEmail').getValue();
                userData.MobilePhone = Ext.getCmp('usrContactNo').getValue();
                localStorage.setItem('user', Ext.JSON.encode(userData));

                try { com.inbooks.app.destroyHeaderButtons(); } catch (e) { }

                //com.inbooks.app.viewportCaller = com.inbooks.app.menus[0];
                Ext.Viewport.add(Ext.create('com.inbooks.view.Dashboard'));
                //msg = g_m['msg0009'];
                com.inbooks.classes.Helpers.notifySuccess(g_m['msg0059'], true);

            } else {
                //failure flow            
                com.inbooks.classes.Helpers.notifyError(g_m['msg0060'], true);
            }
            //Hide the progress mask
            Ext.Viewport.setMasked(false);
        }
        else {
            //Possibly request timed out.
            var message = (response.timedout || response.statusText == "") ? g_m['msg0020'] : response.statusText;
            com.inbooks.classes.Helpers.notifyError(message, true);
            //Ext.getCmp("idfieldset").setDisabled(false);

            //Hide the progress mask
            Ext.Viewport.setMasked(false);
        }
        //Hide the progress mask
        Ext.Viewport.setMasked(false);
    }

});
