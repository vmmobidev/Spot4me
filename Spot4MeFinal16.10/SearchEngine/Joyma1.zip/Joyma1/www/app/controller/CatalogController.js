Ext.define('com.inbooks.controller.CatalogController', {
    extend: 'Ext.app.Controller',
    requires: [
        'com.inbooks.view.Catalog'
    ],
    config: {
        refs: {
            category: 'catalog #list-catalog'
        },
        control: {
            category: { itemtap: "showBooks" } //disclose: "showBooks"
        }
    },
    launch: function () {
        console.log("Catalog Controller - Launch");
    },
    init: function () {
        console.log("Catalog Controller - Init");
    },
    showBooks: function(me, item, index, data, eOpts){
        console.log("showBooks - start");
        if( data.data.Id == 19 ){
           try{
                com.inbooks.app.destroyHeaderButtons();
           }
           catch(e){
                console.log(e.message);
           }
            Ext.Viewport.setActiveItem({xtype: 'music'});
            Ext.getCmp('id-footer').setActiveTab(1);
        }
        else if(data.data.Id == 84){
           try{
                com.inbooks.app.destroyHeaderButtons();
           }
           catch(e){
                console.log(e.message);
           }
            Ext.Viewport.setActiveItem({xtype: 'videos'});
            Ext.getCmp('id-footer').setActiveTab(1);
        }
        else{
            //show the loading mask
            Ext.Viewport.setMasked({
                xtype: 'loadmask',
                indicator: true,
                message: g_m['msg0048']
            });
            var store = Ext.getStore('BooksStore');
            store.filter("CATALOGCODE", data.data.CatalogCode);
            try{
                com.inbooks.app.destroyHeaderButtons();
                setTimeout(function(){
                    Ext.Viewport.setActiveItem(Ext.create("com.inbooks.view.Books"));
                    Ext.Viewport.setMasked(false);
                }, 1000);
            }
            catch(e){
                console.log(e.message);
            }
        }
        console.log("showBooks - end");
    }    
});
