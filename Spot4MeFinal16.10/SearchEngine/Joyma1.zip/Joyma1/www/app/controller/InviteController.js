﻿Ext.define('com.inbooks.controller.InviteController', {
    extend: 'Ext.app.Controller',
    requires: [
            'com.inbooks.view.Invite'
    ],
    config: {
        refs: {
            InviteForm: 'invite'
        },
        control: {
            'button[action=btnClearClick]': { tap: 'btnClear_Click' },
            'button[action=btnInviteClick]': { tap: 'InviteClick' }
        }
    },
    launch: function () {
         console.log("Invite Controller - Launch");
    },
    init: function () {
         console.log("Invite Controller - Init");
    },
    btnClear_Click: function (btn) {
        console.log("Invite Controller - btnClear_Click");
        hideKeyboard();// Calling this function for resigning the keyboard
        btn.up('formpanel').reset();
    },
    InviteClick: function(btn){
        console.log("Invite Controller InviteClick - start");
        
        hideKeyboard();// Calling this function for resigning the keyboard
        
        var objFields = this.getInviteForm().getFields(); //magic function from refs
        var hasPassedEmptyFieldsValidation = com.inbooks.classes.Helpers.validateFormFields(objFields);
        var hasPassedCustomValidation = this.customValidations(objFields);

        if (hasPassedEmptyFieldsValidation && hasPassedCustomValidation) {
            this.inviteFriend();
                
        }
        console.log("Invite Controller InviteClick - end");
    },

    customValidations: function (objFields) {
        var isValid = true;

        // Check for valid email id
        var objField = objFields["txtFriendsEmail"];
        var isEmailValid = com.inbooks.classes.Helpers.emailIsValid(objField);

        if (isEmailValid) {
            return true;
        }
        else {
            return false;
        }
    },

    inviteFriend: function(){
        console.log("Invite Controller inviteFriend - start");
        //show the loading mask
        Ext.Viewport.setMasked({
            xtype: 'loadmask',
            indicator: true,
            message: g_m['msg0064']
        });

        var userDetails = Ext.JSON.decode(localStorage.getItem("user"));

        var InviteFormValues = this.getInviteForm().getValues();

        var friendName = InviteFormValues.txtFriendName;
        var friendEmail = InviteFormValues.txtFriendsEmail;
        var specialNotes = InviteFormValues.txtNotes;

        //try {

            var params = '{"request":{"ReferrerUserName" : ' + '"' + userDetails.UserName + '"' + ',"ReferrerName" : ' + '"' + userDetails.Name + '"' + ',"RefereeName" : ' + '"' + friendName + '"' +',"ReferreeEmail" : ' + '"' + friendEmail + '"' +  ',"ApplicationName" : "Inbooks tablet app"' + '}}';
            var headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };

            com.inbooks.classes.Helpers.Ajax('/Referral/Invite', params, 'POST', 'JSON', this.InviteFriendCallback, '', headers);
        //catch (e) { }
        console.log("Invite Controller inviteFriend - end");
    },
    InviteFriendCallback: function(options, success, response){
        console.log("InviteFriendCallback callback - start");
        if (success) {
            //response.success = true case
            if (response.responseText != '' && (Ext.JSON.decode(response.responseText).aaData.Success==undefined)) {
                console.log("InviteFriendCallback Success");
                //var msg = "Invitation has been sent successfully";
                //Hide the progress mask
                Ext.Viewport.setMasked(false);
                com.inbooks.classes.Helpers.notifySuccess(g_m['msg0063'], true); //message,showAsModal
            }
            //response.success = false case
            else {
                var msg = "";
                try {
                    msg = Ext.JSON.decode(response.responseText).aaData.Message;
                } catch (e) { }

                //Hide the progress mask
                setTimeout(function () {
                    Ext.Viewport.setMasked(false);
                }, 10);
                com.inbooks.classes.Helpers.notifyError(msg, true); //message,showAsModal
            }

        } else {
            console.log("response.statusText = " + response.statusText)
            //Possibly request timed out.
            var message = (response.timedout || response.statusText == "") ? g_m['msg0020'] : response.statusText;
            com.inbooks.classes.Helpers.notifyError(message, true); //message,showAsModal
            //Hide the progress mask
            Ext.Viewport.setMasked(false);
        }
        console.log("InviteFriendCallback callback - end");
    }
});
