Ext.define('com.inbooks.controller.AppController', {
    extend: 'Ext.app.Controller',
    requires: [],
    config: {
        refs: {},
        control: {}
    },
    launch: function () {
        console.log("Application Controller - Launch");
    },
    init: function () {
        console.log("Application Controller - Init");
        this.getApplication().on('LoadAllMasters', this.onLoadAllMasters, this);
        this.getApplication().on('AddBookstoBookshelf', this.onAddBookstoBookshelf, this);
        
    },
    onLoadAllMasters: function () {
        console.log("onLoadAllMasters - Start");
        var scope = [];
        scope[0] = "AllMasters";
        var headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
        com.inbooks.classes.Helpers.Ajax(
            '/Master/All', '', 'GET', 'JSON',
            this.LoadMastersCallBack, scope, headers);
        console.log("onLoadAllMasters - End");
    },
    LoadMastersCallBack: function (options, success, response) {
        console.log("LoadMastersCallBack - Start");
        if (success) {
            try {
                var result = Ext.JSON.decode(response.responseText);
                var resultData = result.aaData;
                var catalogs = resultData.Catalog, books = resultData.Book;

                com.inbooks.app.g_catalogs = catalogs;
                com.inbooks.app.g_books = books;

                localStorage.setItem("AllMasterData", JSON.stringify({
                    "catalogs": com.inbooks.app.g_catalogs,
                    "books": com.inbooks.app.g_books
                }));
            }
            catch (e) {
                console.log("Exception in LoadMastersCallBack ");
            }
        }

        setTimeout(function () {
            Ext.Viewport.setMasked(false);
        }, 100);

        if (options.scope[0] == "AllMasters") {
            console.log("Mask false inside allmaster");
            try {
                if (success) {
                    var view = Ext.Viewport.getActiveItem().xtype;
                    if (view == 'settings') {
                        com.inbooks.classes.Helpers.notifySuccess(g_m['msg0031'], false); // message,showAsModal
                    }
                } else {
                    if (view == 'settings') {
                        com.inbooks.classes.Helpers.notifyError(g_m['msg0032'], false); // message,showAsModal
                    }
                }
            } catch (e) { }
        }
        console.log("LoadMastersCallBack - End");
    }
});
