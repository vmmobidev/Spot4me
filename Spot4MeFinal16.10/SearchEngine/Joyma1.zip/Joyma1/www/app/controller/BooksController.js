Ext.define('com.inbooks.controller.BooksController', {
    extend: 'Ext.app.Controller',
    requires: [
        'com.inbooks.view.Books'
    ],
    config: {
        refs: {
            book: 'books #list-books'
        },
        control: {
            book: { disclose: 'showReader' }
            //'button[action=showReaderOnPreviewClick]': { tap: 'getParentRowData'}
        }
    },
    showReader: function(lst, data, args){
        console.log("BooksController showReader - start");
        try{
            //show the loading mask
            setTimeout(function(){
                Ext.Viewport.setMasked({
                    xtype: 'loadmask',
                    indicator: true,
                    message: g_m['msg0049']
                });
            }, 100);
            //Store book details in global variable
            com.inbooks.app.g_selectedBookDetails = data.data;
            //Get all bookmarks for the book
            com.inbooks.classes.Helpers.getAllBookmarks();
            //Update page details
            com.inbooks.app.g_pages = Ext.JSON.decode(data.data.PAGES);
            com.inbooks.app.g_bookId = data.data.ID;
            com.inbooks.app.g_bookTitle = data.data.NAME;
            com.inbooks.app.destroyHeaderButtons();
            setTimeout(function(){
                Ext.Viewport.setMasked(false);
                Ext.Viewport.setActiveItem(Ext.create("com.inbooks.view.Reader"));
            }, 500);
            Ext.getCmp('id-footer').setActiveTab(1);
        }
        catch(e){
            console.log(e.message);
        }
        console.log("BooksController showReader - end");
    },
    launch: function () {
        console.log("BooksController - Launch");
    },
    init: function () {
        console.log("BooksController - Init");
    }
});

