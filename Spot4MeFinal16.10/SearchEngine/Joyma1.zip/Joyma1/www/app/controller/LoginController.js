Ext.define('com.inbooks.controller.LoginController', {
    extend: 'Ext.app.Controller',
    requires: [
        'com.inbooks.view.Login'
],
    config: {
        refs: {
            loginForm: 'login'
        },
        control: {
            'button[action=btnLoginClick]': { tap: 'btnLogin_Click' },
            'button[action=btnSignUpClick]': { tap: 'btnSignUp_Click' }
        }
    },

    launch: function () {
        console.log("Login Controller - Launch");
    },
    init: function () {
        console.log("Login Controller - Init");
    },

    // Clicking on Login button, traverse to the 'Dashboard' UI
    btnLogin_Click: function () {
        console.log("Login Controller - btnLogin_Click");

        //Ext.getCmp("idfieldset").setDisabled(true);
        hideKeyboard(); // Calling this function for resigning the keyboard

        var objFields = this.getLoginForm().getFields(); //magic function from refs        
        var hasPassedEmptyFieldsValidation = com.inbooks.classes.Helpers.validateFormFields(objFields);

        if (hasPassedEmptyFieldsValidation) {
            this.AuthenticateUser();
        }
    },

    AuthenticateUser: function () {
        //show the loading mask
        Ext.Viewport.setMasked({
            xtype: 'loadmask',
            indicator: true,
            message: '' + g_m['msg0039'] + ''
        });
        console.log("Authenticate - start");

        var loginCredentials = this.getLoginForm().getValues();
        var username = loginCredentials.txtUsername;
        var password = loginCredentials.txtPassword;

        try {
            var params = '{"request":{"Username" : ' + '"' + username + '"' + ',"Password" : ' + '"' + password + '"' + '}}';
            var headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
            com.inbooks.classes.Helpers.Ajax('/Account/Authenticate', params, 'POST', 'JSON', this.onAuthenticationCallback, '', headers);
        }
        catch (e) { }

        console.log("Authenticate - end");
    },

    onAuthenticationCallback: function (options, success, response) {
        console.log("authentication callback");
        if (success) {
            var response = Ext.JSON.decode(response.responseText);
            var userData = Ext.JSON.encode(response.aaData.Profile);
            localStorage.setItem("user", userData);
            com.inbooks.app.g_clrNavHistory = true;
            com.inbooks.app.g_viewportCaller = null;
            com.inbooks.app.g_arrNavHistory = [];
            if (response.aaData.Success) {
                //success flow                
                setTimeout(function () {
                    com.inbooks.app.destroyHeaderButtons();
                    Ext.Viewport.setActiveItem(Ext.create('com.inbooks.view.Dashboard'));
                    Ext.Viewport.setMasked(false);
                }, 1000);
            }
            else {
                //failure flow                
                if (response.aaData.Message == "InActive user") {
                    msg = g_m['msg0058'];
                    // msg = Ext.JSON.decode(response.responseText).Message
                    com.inbooks.classes.Helpers.notifyError(msg, true);
                    //Ext.Msg.alert("Invalid User");


                }
                else {
                    //msg = 'The username or password you entered is incorrect.';
                    msg = g_m['msg0004'];
                    com.inbooks.classes.Helpers.notifyError(msg, true);
                    //Ext.Msg.alert("The username or password you entered is incorrect");
                }

                //Ext.getCmp("idfieldset").setDisabled(false);

                //Hide the progress mask
                Ext.Viewport.setMasked(false);
            }
        }
        else {
            //Possibly request timed out.
            var message = (response.timedout || response.statusText == "") ? g_m['msg0020'] : response.statusText;
            com.inbooks.classes.Helpers.notifyError(message, true);
            //Ext.getCmp("idfieldset").setDisabled(false);

            //Hide the progress mask
            Ext.Viewport.setMasked(false);
        }
    },

    // Clicking on Signup button, traverse to the 'Signup' UI 
    btnSignUp_Click: function () {
        console.log("Login Controller - btnSignup_Click");
        com.inbooks.app.destroyHeaderButtons();
        Ext.Viewport.setActiveItem(Ext.create("com.inbooks.view.SignUp"));
    }

});
