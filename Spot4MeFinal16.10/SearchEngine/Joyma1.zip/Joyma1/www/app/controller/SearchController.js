Ext.define('com.inbooks.controller.SearchController', {
    extend: 'Ext.app.Controller',
    requires: [
        'com.inbooks.view.Search'
    ],
    config: {
        refs: {
            searchRef: 'search list'
        },
        control: {
            searchRef: {
                disclose: 'onSearchBookDiscloseClick'
            }
        }
    },
    onSearchBookDiscloseClick:function(lst, data, args){
        console.log("SearchController showReader - start");
        hideKeyboard(); // Calling this function for resigning the keyboard
        try{
            //show the loading mask
            setTimeout(function(){
                Ext.Viewport.setMasked({
                    xtype: 'loadmask',
                    indicator: true,
                    message: g_m['msg0049']
                });
            }, 100);
            //Store book details in global variable
            com.inbooks.app.g_selectedBookDetails = data.data;
            //Get all bookmarks for the book
            com.inbooks.classes.Helpers.getAllBookmarks();
            //Update page details
            com.inbooks.app.g_pages = Ext.JSON.decode(data.data.PAGES);
            com.inbooks.app.g_bookId = data.data.ID;
            com.inbooks.app.g_bookTitle = data.data.NAME;
            com.inbooks.app.destroyHeaderButtons();
            setTimeout(function(){
                Ext.Viewport.setActiveItem(Ext.create("com.inbooks.view.Reader"));
                Ext.Viewport.setMasked(false);
            }, 500);
            Ext.getCmp('id-footer').setActiveTab(1);
        }
        catch(e){
            console.log(e.message);
        }
        console.log("SearchController showReader - end");
    },
    launch: function () {
        console.log("SearchController  - Launch");
    },
    init: function () {
        console.log("SearchController r - Init");
    }

});