﻿Ext.define('com.inbooks.controller.FooterController', {
    extend: 'Ext.app.Controller',
    requires: [
            'com.inbooks.view.Footer'
    ],
    config: {
        refs: {

        },
        control: {
            'button[action=btnHomeClick]': { tap: 'btnHome_Click' },
            'button[action=btnCatalogueClick]': { tap: 'btnCatalog_Click' },
            'button[action=btnBookshelfClick]': { tap: 'btnBookshelf_Click' },
            'button[action=btnSettingsClick]': { tap: 'btnSettings_Click' },
            'button[action=btnSearchClick]': { tap: 'btnSearch_Click' }
        }
    },
    launch: function () {
        console.log("Footer Controller - Launch");
    },
    init: function () {
        console.log("Footer Controller - Init");
    },
    btnHome_Click: function () {
        console.log("Footer Controller - Home")
        com.inbooks.app.destroyHeaderButtons();
        com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[2];
        com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[2]);
        Ext.Viewport.setActiveItem(Ext.create("com.inbooks.view.Dashboard"));
    },
    btnCatalog_Click: function () {
        console.log("Footer Controller - Catalog");
        com.inbooks.app.destroyHeaderButtons();
        com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[3];
        com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[3]);
        Ext.Viewport.setActiveItem(Ext.create("com.inbooks.view.Catalog"));
    },
    btnBookshelf_Click: function () {
        console.log("Footer Controller - Bookshelf");
        com.inbooks.app.destroyHeaderButtons();
        com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[5];
        com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[5]);
        Ext.Viewport.setActiveItem(Ext.create("com.inbooks.view.Bookshelf"));
    },    
    btnSearch_Click: function () {
        console.log("Footer Controller - Search");
        com.inbooks.app.destroyHeaderButtons();
        com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[12];
        com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[12]);
        Ext.Viewport.setActiveItem(Ext.create("com.inbooks.view.Search"));
    },
    btnSettings_Click: function () {
        console.log("Footer Controller - Settings");
        com.inbooks.app.destroyHeaderButtons();
        com.inbooks.app.g_viewportCaller = com.inbooks.app.g_menus[8];
        com.inbooks.classes.Helpers.pushNavHistory(com.inbooks.app.g_menus[8]);
        Ext.Viewport.setActiveItem(Ext.create("com.inbooks.view.Settings"));
    },

});
