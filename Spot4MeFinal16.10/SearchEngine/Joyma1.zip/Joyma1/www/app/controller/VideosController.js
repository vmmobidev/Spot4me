Ext.define('com.inbooks.controller.VideosController', {
    extend: 'Ext.app.Controller',
    requires: [
        'com.inbooks.view.Videos'
    ],
    config: {
        refs: {
            videos: 'videos #list-videos'
        },
        control: {
            videos: { disclose: 'showVideoPanel' }
            //'button[action=showReaderOnPreviewClick]': { tap: 'getParentRowData'}
        }
    },
    showVideoPanel: function(lst, data, args){
        console.log("VideosController showReader - start");
        try{
            Ext.getCmp('id-video').destroy();
        }catch(e){
            console.log(e.message);
        }
        var customHeight = 50*(window.innerHeight)/100;
        try{
            var video = Ext.create("Ext.Panel",{
                id: 'id-video',
                modal: true,
                hideOnMaskTap: true,
                centered: true,
                width: '60%',
                height: customHeight,//'50%',
                html: '<iframe id="id-video-frame" width="100%" height='+ (customHeight-10) +' poster="'+ data.data.imgUrl + '" src="'+ data.data.Url +'" frameborder="0"></iframe>',
                showAnimation:
                {
                    type: 'slideIn',
                    duration: 1000,
                    direction: 'down'
                },
                hideAnimation:
                {
                    type: 'slideOut',
                    duration: 1000,
                    direction: 'down'
                },
                listeners: {
                    resize: function(ele){
                        console.log("VideosController Resize event - start");
                        var customHeight = 48.5*(window.innerHeight)/100;
                        $("id-video-frame").context.activeElement.height = customHeight;
                        console.log("VideosController Resize event - end");
                    }
                }
            });
            Ext.Viewport.add(video);
            video.show();
        }
        catch(e){
            console.log(e.message);
        }
        console.log("VideosController showReader - end");
    },
    launch: function () {
        console.log("VideosController - Launch");
    },
    init: function () {
        console.log("VideosController - Init");
    }
});

