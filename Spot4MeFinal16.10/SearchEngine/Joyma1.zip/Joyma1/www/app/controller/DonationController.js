﻿Ext.define('com.inbooks.controller.DonationController', {
    extend: 'Ext.app.Controller',
    requires: [
            'com.inbooks.view.Donation'
    ],
    config: {
        refs: {

        },
        control: {
            'button[action=btnDonateClick]': { tap: 'btnDonate_Click' },
        }
    },
    launch: function () {
        console.log("Donation Controller - Launch");
    },
    init: function () {
        console.log("Donation Controller - Init");
    },
   btnDonate_Click: function () {        
        com.inbooks.app.destroyHeaderButtons();        
        Ext.Viewport.setActiveItem(Ext.create("com.inbooks.view.Dashboard"));
    },

    

});
