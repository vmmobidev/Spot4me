﻿Ext.define('com.inbooks.model.BooksModel', {
    extend: 'Ext.data.Model',
    config: {
        fields: [
            { name: 'ID', type: 'integer' },
            { name: 'BOOKCODE', type: 'string' },
            { name: 'CATALOGCODE', type: 'string' },
            { name: 'NAME', type: 'string' },
            { name: 'AUTHOR', type: 'string' },
            { name: 'PUBLISHER', type: 'string'},
            { name: 'PUBLISHYEAR', type: 'string'},
            { name: 'LANGUAGECODE', type: 'string'},
            { name: 'CoverPageThumbUrl', type: 'string'},
            { name: 'PAGES', type: 'string'},
            { name: 'Summary', type: 'string'},
            { name: 'ProposedUser', type: 'string'}
        ]
    }
});