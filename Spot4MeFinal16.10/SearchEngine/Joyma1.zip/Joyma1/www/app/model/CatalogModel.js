﻿Ext.define('com.inbooks.model.CatalogModel', {
    extend: 'Ext.data.Model',
    config: {
        fields: [
            { name: 'Id', type: 'string' },
            { name: 'CatalogCode', type: 'string' },
            { name: 'Name', type: 'string' },
            { name: 'count', type: 'string' }
        ]
    }
});