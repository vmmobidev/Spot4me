﻿Ext.define('com.inbooks.model.BookmarksModel', {
    extend: 'Ext.data.Model',
    config: {
        fields: [
            { name: 'Id', type: 'integer' },
            { name: 'BookCode', type: 'string' },
            { name: 'UserName', type: 'string' },
            { name: 'Date', type: 'string' },
            { name: 'PageId', type: 'integer' }
        ]
    }
});