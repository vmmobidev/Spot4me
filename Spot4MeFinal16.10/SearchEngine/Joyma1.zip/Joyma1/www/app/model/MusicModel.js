﻿Ext.define('com.inbooks.model.MusicModel', {
    extend: 'Ext.data.Model',
    config: {
        fields: [
            { name: 'Id', type: 'string' },
            { name: 'MusicCode', type: 'string' },
            { name: 'Name', type: 'string' },
            { name: 'url', type: 'string' }
        ]
    }
});