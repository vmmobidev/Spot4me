﻿Ext.define('com.inbooks.model.VideoModel', {
    extend: 'Ext.data.Model',
    config: {
        fields: [
            { name: 'Id', type: 'integer' },
            { name: 'VideoCode', type: 'string' },
            { name: 'Name', type: 'string' },
            { name: 'Url', type: 'string'},
            { name: 'imgUrl', type: 'string'}
        ]
    }
});