﻿Ext.define('com.inbooks.model.BookshelfModel', {
    extend: 'Ext.data.Model',
    config: {
        fields: [
            { name: 'Id', type: 'integer' },
            { name: 'BookCode', type: 'string' },
            { name: 'CatalogCode', type: 'string' },
            { name: 'Name', type: 'string' },
            { name: 'Author', type: 'string' },
            { name: 'Publisher', type: 'string' },
            { name: 'PublishYear', type: 'string' },
            {name: 'CoverPageThumbUrl', type: 'string' },
            { name: 'Pages', type: 'string' },
            { name: 'Summary', type: 'string'},
            { name: 'ProposedBy', type: 'string'}
        ]
    }
});