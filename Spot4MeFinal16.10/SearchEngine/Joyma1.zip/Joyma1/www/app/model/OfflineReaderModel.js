﻿Ext.define('com.inbooks.model.OfflineReaderModel', {
    extend: 'Ext.data.Model',
    config: {
        fields: [
            { name: 'Source', type: 'string' },
            { name: 'PageNum', type: 'integer' },
            { name: 'BookCode', type: 'string' }
        ],
        proxy: {
            type: 'sqlitestorage',
            dbConfig: {
                tablename: 'OfflineReader',
                dbConn: com.inbooks.util.InitSQLite.getConnection()
            }
        }
    }
});