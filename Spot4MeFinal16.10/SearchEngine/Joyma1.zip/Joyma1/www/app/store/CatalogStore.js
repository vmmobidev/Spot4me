﻿Ext.define('com.inbooks.store.CatalogStore', {
    extend: 'Ext.data.Store',
    config: {
        model: 'com.inbooks.model.CatalogModel',
        autoLoad: true, //If set to true then the data will be retrieved during application launch
        clearOnPageLoad: true, //True to empty the store when loading another page via loadPage, nextPage or previousPage (defaults to true). Setting to false keeps existing records, allowing large data sets to be loaded one page at a time but rendered all together.
        pageSize: 10,
        storeId: 'catalogstore',
        sorters: 'Name'
//        proxy: {
//            type: 'ajax',
//            url : 'app/data/Catalog.json'
//        }
    }
});