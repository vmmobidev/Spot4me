﻿Ext.define('com.inbooks.store.VideoStore', {
    extend: 'Ext.data.Store',
    config: {
        model: 'com.inbooks.model.VideoModel',
        autoLoad: true, //If set to true then the data will be retrieved during application launch
        clearOnPageLoad: true, //True to empty the store when loading another page via loadPage, nextPage or previousPage (defaults to true). Setting to false keeps existing records, allowing large data sets to be loaded one page at a time but rendered all together.
        pageSize: 10,
        sorters: 'Name',
        grouper: {
            groupFn: function(record) {
                /*var CatName;
                Ext.each(com.inbooks.app.g_catalogs, function(item, index, countriesItSelf){
                    if(item.CatalogCode == record.get('CATALOGCODE')){
                        CatName = item.Name;
                    }
                });
                return CatName;*/
                return record.get('Name');
            },
            sortProperty: 'Name'
        },
        proxy: {
            type: 'ajax',
            url : 'app/data/Videos.json'
        }
    }
});