﻿Ext.define('com.inbooks.store.BookshelfStore', {
    extend: 'Ext.data.Store',
    config: {
        model: 'com.inbooks.model.BookshelfModel',
        autoLoad: true, //If set to true then the data will be retrieved during application launch
        clearOnPageLoad: true, //True to empty the store when loading another page via loadPage, nextPage or previousPage (defaults to true). Setting to false keeps existing records, allowing large data sets to be loaded one page at a time but rendered all together.
        pageSize: 10,
        sorters: 'NAME'
//        grouper: {
//            groupFn: function (record) {
//                var CatName;
//                Ext.each(com.inbooks.app.g_catalogs, function (item, index, countriesItSelf) {
//                    if (item.CatalogCode == record.get('CATALOGCODE')) {
//                        CatName = item.Name;
//                    }
//                });
//                return CatName;
//                //return record.get('CATALOGCODE').substr(0, 1);
//            },
//            sortProperty: 'NAME'
//        }
    }
});