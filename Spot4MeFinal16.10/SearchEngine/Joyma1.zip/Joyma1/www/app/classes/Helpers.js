Ext.define('com.inbooks.classes.Helpers', {
    singleton: true,
    requires: [ 'Ext.field.Slider' ],
    // Singleton Ajax method to call the REST APIs
    //-------------------------------------------------------------------------------------------------------------------

    Ajax: function (restUri, params, method, type, callBack, scope) {

        console.log("Query = [" + com.inbooks.app.g_api_host + com.inbooks.app.g_api_port + restUri + "]");
        if (this.networkIsReachable('google.co.in')) {
            Ext.Ajax.request({
                url: com.inbooks.app.g_api_host + com.inbooks.app.g_api_port + restUri
                       , method: method
                       , headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
                       , type: type
                       , params: params
                       , callback: callBack
                       , scope: scope
            });
        }
        else {
            console.log("Error in Ajax call");
            try { Ext.Viewport.setMasked(false); } catch (e) { console.log(e.message); }
        }
    },
    AjaxFailure: function () {
        try { this.notifyError("Error during Ajax call", true) } catch (e) { Ext.Viewport.setMasked(false); }
    },
    //-------------------------------------------------------------------------------------------------------------------

    format: function (str) {
        for (i = 1; i < arguments.length; i++) {
            str = str.replace('{' + (i - 1) + '}', arguments[i]);
        }
        return str;
    },

    //Check for network connectivity
    //------------------------------------------------------------------------------------------------------------------
    networkIsReachable: function (hostname) {
        console.log("networkIsReachable - Start");
        var networkState = null;
        try {
            console.log("networkState = " + navigator.connection.type);
            networkState = navigator.connection.type;
        } catch (e) { }

        if (networkState == null) { return true; }

        var states = {};
        states[Connection.UNKNOWN] = 'Unknown connection';
        states[Connection.ETHERNET] = 'Ethernet connection';
        states[Connection.WIFI] = 'WiFi connection';
        states[Connection.CELL_2G] = 'Cell 2G connection';
        states[Connection.CELL_3G] = 'Cell 3G connection';
        states[Connection.CELL_4G] = 'Cell 4G connection';
        states[Connection.NONE] = 'No network connection';
        if ((states[networkState] == 'Unknown connection') || (states[networkState] == 'No network connection')) {
            this.notifyError(g_m['msg0001'], true); //message: text,showAsModal: boolean
            console.log("networkIsReachable - End");
            return false;
        }
        console.log("networkIsReachable - End");
        return true;
    },
    //------------------------------------------------------------------------------------------------------------------


    //Check for valid email Id
    //-------------------------------------------------------------------------------------------------------------------
    emailIsValid: function (objField) {
        console.log("emailIsValid - Start");
        var val = objField.getValue();
        if (!this.emailCheckRegExp(val)) {
            objField.setValue("");
            objField.setPlaceHolder("" + g_m['msg0043'] + "");
            console.log("emailIsValid - End");
            return false;
        }
        console.log("emailIsValid - End");
        return true;
    },
    emailCheckRegExp: function (val) {
        console.log("emailCheckRegExp - Start");
        var regexp = /^(([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})*$/;
        var result = regexp.test(val);
        console.log("emailCheckRegExp - End");
        return result;
    },
    //-------------------------------------------------------------------------------------------------------------------

    //Check for valid Contact No
    //-------------------------------------------------------------------------------------------------------------------
    contactNumberIsValid: function (objField) {
        console.log("contactNumberIsValid - Start");
        var val = objField.getValue();
        if (!this.contactNumberCheckRegExp(val)) {
            objField.setValue("");
            objField.setPlaceHolder("" + g_m['msg0044'] + "");
            console.log("contactNumberIsValid - End");
            return false;
        }
        console.log("contactNumberIsValid - End");
        return true;
    },
    contactNumberCheckRegExp: function (val) {
        console.log("contactNumberCheckRegExp - Start");
        var regexp = /^((\+\d{1,3}(-| )?\(?\d\)?(-| )?\d{1,3})|(\(?\d{2,3}\)?))(-| )?(\d{3,4})(-| )?(\d{4})(( x| ext)\d{1,5}){0,1}$/;
        var result = regexp.test(val);
        console.log("contactNumberCheckRegExp - End");
        return result;
    },
    //-------------------------------------------------------------------------------------------------------------------

    //Check for valid Username
    //-------------------------------------------------------------------------------------------------------------------
    usernameIsValid: function (objField) {
        console.log("usernameIsValid - Start");
        var val = objField.getValue();
        if (!this.usernameCheckRegExp(val)) {
            objField.setValue("");
            objField.setPlaceHolder("" + g_m['msg0045'] + "");
            console.log("usernameIsValid - End");
            return false;
        }
        console.log("usernameIsValid - End");
        return true;
    },
    usernameCheckRegExp: function (val) {
        console.log("usernameCheckRegExp - Start");
        var regexp = /^[a-z0-9_-]{3,16}$/;
        var result = regexp.test(val);
        console.log("usernameCheckRegExp - End");
        return result;
    },
    //-------------------------------------------------------------------------------------------------------------------

    //Compare values of two objects
    //-------------------------------------------------------------------------------------------------------------------
    compareValues: function (obj1, obj2) {
        console.log("compareValues - Start");
        var val1 = obj1.getValue();
        var val2 = obj2.getValue();

        if (val1 != val2) {
            return false;
        }
        console.log("compareValues - End");
        return true;
    },
    //-------------------------------------------------------------------------------------------------------------------

    //Validate form (login, Signup, Change Profile, Change Password) field values
    //-------------------------------------------------------------------------------------------------------------------
    validateFormFields: function (objFields) {
        var objField, fieldName;
        var isValid = true;
        var password = "";

        console.log("validateFormFields - End");

        for (fieldName in objFields) {
            //trap the object by it's name            
            objField = objFields[fieldName];

            //check if the field is required
            if (objField._required) {
                //Yes, then check it's value
                var isEmpty = (!objField.getValue() || objField.getValue() == "");
                //Is empty ?
                if (isEmpty) {
                    //Yes, then set message to the placeholder    

                    objField.setPlaceHolder("" + g_m['msg0042'] + "");
                    isValid = false;
                }
            }
        }
        console.log("validateFormFields - End");
        return isValid;
    },

    // Determine the position of the noty on the screen
    //-------------------------------------------------------------------------------------------------------------------          
    notyLayout: function () {
        // Default show the noty at the Center of the screen, except for Dashboard screen. 
        // Reason: The Dashboard is an image and the noty overlaps this. So, on tap of the noty the image is also getting tapped.

        var layout = "center";
        if (com.inbooks.app.g_viewportCaller == com.inbooks.app.g_menus[0]) {
            layout = "topCenter";
        }

        return layout;
    },
    //-------------------------------------------------------------------------------------------------------------------          

    // Noty Type - Error
    //-------------------------------------------------------------------------------------------------------------------          
    notifyError: function (message, showAsModal) {
        console.log("notifyError start");
        $.noty.closeAll();
        if (Ext.os.is.iOS) {
            console.log("notifyError if ios");
            noty(
            {
                "text": '<div class="vm-notyDecorator">' + message + '</div>',
                "layout": 'top',
                "type": "error",
                "modal": false,
                timeout: 4000
            }
        )
                       
        }
        else 
        {
            console.log("notifyError if not ios");
            try{
                noty(
                    {
                        "text": '<div class="vm-notyDecorator">' + message + '</div>',
                        "layout": com.inbooks.classes.Helpers.notyLayout(),
                        "type": "error",
                        "modal": showAsModal,
                        "buttons": [
                            {
                                addClass: 'btn btn-danger', text: '' + g_l['lbl0024'] + '', onClick: function ($noty) { $noty.close() }
                            }
                        ]
                    }
                )
                console.log("notifyError if not ios inside try block");
            }
            catch(e){console.log(e.message)}

    }
    
    },
    //-------------------------------------------------------------------------------------------------------------------              

    // Noty Type - Success
        //-------------------------------------------------------------------------------------------------------------------          

        notifySuccess: function (message, showAsModal) {
            console.log("notifySuccess start");
            $.noty.closeAll();
            if (Ext.os.is.iOS) {
                noty(
            {
                "text": '<div class="vm-notyDecorator">' + message + '</div>',
                "layout": 'top',
                "type": "success",
                "modal": false,
                timeout: 4000
            }
        )

            }
            else {
                noty(
            {
                "text": '<div class="vm-notyDecorator">' + message + '</div>',
                "layout": com.inbooks.classes.Helpers.notyLayout(),
                "type": "success",
                "modal": showAsModal,
                "buttons": [
                    {
                        addClass: 'btn btn-success', text: '' + g_l['lbl0024'] + '', onClick: function ($noty) { $noty.close() }
                    }
                ]
            }
        )
    }

},


    
    //-------------------------------------------------------------------------------------------------------------------          

    // Noty Type - Warning
    //-------------------------------------------------------------------------------------------------------------------          

        notifyWarning: function (message, showAsModal) {
            console.log("notifyWarning start");
            $.noty.closeAll();
            if (Ext.os.is.iOS) {
                noty(
            {
                "text": '<div class="vm-notyDecorator">' + message + '</div>',
                "layout": 'top',
                "type": "warning",
                "modal": false,
                timeout: 4000
            }
        )

            }
            else {
                noty(
            {
                "text": '<div class="vm-notyDecorator">' + message + '</div>',
                "layout": com.inbooks.classes.Helpers.notyLayout(),
                "type": "warning",
                "modal": showAsModal,
                "buttons": [
                    {
                        addClass: 'btn btn-warning', text: '' + g_l['lbl0024'] + '', onClick: function ($noty) { $noty.close() }
                    }
                ]
            }
        )
    }

},    
    //-------------------------------------------------------------------------------------------------------------------              

    // Clear the navigation history array
    //-------------------------------------------------------------------------------------------------------------------                              
    popNavHistory: function () {
        console.log("popNavHistory - start");
        Ext.each(com.inbooks.app.g_arrNavHistory, function (item, index) {
            com.inbooks.app.g_arrNavHistory.pop();

        });
        console.log("popNavHistory - end");
    },


    //-------------------------------------------------------------------------------------------------------------------              

    // Add item to the navigation history array
    //-------------------------------------------------------------------------------------------------------------------                              
    pushNavHistory: function (val) {
        console.log("pushNavHistory - start");
        var l = com.inbooks.app.g_arrNavHistory.length;

        if (l > 0) {
            if (com.inbooks.app.g_arrNavHistory[l - 1] != val) {
                com.inbooks.app.g_arrNavHistory.push(val);
            }
        }
        else {
            com.inbooks.app.g_arrNavHistory.push(val);
        }

        console.log("pushNavHistory - end");
    },
    //-------------------------------------------------------------------------------------------------------------------              

    // sort the json array of objects by a property (prop)
    //-----------------------------------------------------------------------------------
    jsonSort: function (arrJson, prop) {
        var sortedJson = arrJson.sort(function (obj1, obj2) {
            var x = obj1[prop].toLowerCase(); var y = obj2[prop].toLowerCase();
            return ((x < y) ? -1 : ((x > y) ? 1 : 0));
        });

        return sortedJson;
    },
    //-------------------------------------------------------------------------------------------------------------------

    // Method to get the Image Url of the current page (used only for Browse free Books)
    //-------------------------------------------------------------------------------------------------------------------
    getPageImageUrl: function (idx) {
        console.log("getPageImageUrl start");
        var bookCode = (com.inbooks.app.g_selectedBookDetails.BookCode == undefined)?com.inbooks.app.g_selectedBookDetails.BOOKCODE:com.inbooks.app.g_selectedBookDetails.BookCode;
        var result = "";
        try {
            var isCurrentPage = null;
           /* Ext.each(Ext.getStore('OfflineReaderStore').data.all,function(item,indx){
                if(item.data.PageNum==idx && item.data.BookCode==bookCode){
                    isCurrentPage = item;
                    return false;
                }
            });*/
            //if(isCurrentPage == null){
            //var pages = Ext.JSON.decode(localStorage.getItem("ossPageViewModels"));
                result = com.inbooks.app.g_BookThumbnailUrl + bookCode + '/' + com.inbooks.app.g_pages[idx].image;
            //}
            /*else{
                var readOffline = localStorage.getItem('ReadOffline');
                result = (readOffline == 1)?(isCurrentPage.data.Source):(com.inbooks.app.g_BookThumbnailUrl + bookCode + '/' + com.inbooks.app.g_pages[idx].image);
            }*/
        } catch (e) { console.log("Error in getPageImageUrl," + e.message) }
        console.log("getPageImageUrl end");
        return result;
    },
    //-------------------------------------------------------------------------------------------------------------------
    // Method to get the the language id and set the variable accordingly
    //-------------------------------------------------------------------------------------------------------------------
    setLanguage: function (lId) {
        console.log("setLanguage start")
        try {
            switch (lId) {
                case "HIN":   /*the language is Hindi*/
                    g_m = m_hi;            /*set the global variable for messages as hindi language messages*/
                    g_l = l_hi;            /*set the global variable for labels as hindi language labels*/
                    break;
                case "ENG":   /*the language is English*/
                default:     /*default language is English*/
                    g_m = m_en;
                    g_l = l_en;
                    break;
            }
        } catch (e) { console.log("Error in setLanguage," + e.message) }
        console.log("setLanguage end")
        return;
    },
    addToBookshelf: function (bookcode) {
        var userdetails = Ext.JSON.decode(localStorage.getItem("user"));
        var Username = userdetails.UserName;
        try {
            var params = '{"request": { "UserName" : ' + '"' + Username + '"' + ', "BookCode":' + '"' + bookcode + '"' + ', "MethodType":"POST"} } ';
            var headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
            com.inbooks.classes.Helpers.Ajax('/BookShelf/0', params, 'POST', 'JSON', com.inbooks.classes.Helpers.AddToBookshelfCallback, '', headers);
        }
        catch (e) { }
    },
    AddToBookshelfCallback: function (options, success, response) {
        console.log("AddToBookshelfCallback callback");
        if (success) {
            var response = Ext.JSON.decode(response.responseText);
            if (response.aaData.Success) {
                //com.inbooks.app.fireEvent('LoadAllMasters', this);
                com.inbooks.classes.Helpers.loadMyBookshelf();
                $("#idaddtobookshelf_" + Ext.JSON.decode(options.params).request.BookCode).removeClass("btn-success");
                $("#idaddtobookshelf_" + Ext.JSON.decode(options.params).request.BookCode).prop("disabled", true);
                $("#idbuy_" + Ext.JSON.decode(options.params).request.BookCode).removeClass("btn-primary");
                $("#idbuy_" + Ext.JSON.decode(options.params).request.BookCode).prop("disabled", true);
                //Hide the progress mask
                Ext.Viewport.setMasked(false);
            }
            else {
                //failure flow
                msg = g_m['msg0047'];
                com.inbooks.classes.Helpers.notifyError(msg, true);
                //Hide the progress mask
                Ext.Viewport.setMasked(false);
            }

        } else {
            //Possibly request timed out.
            var message = (response.timedout || response.statusText == "") ? g_m['msg0020'] : response.statusText;
            com.inbooks.classes.Helpers.notifyError(message, true); //message,showAsModal
            //Hide the progress mask
            Ext.Viewport.setMasked(false);
        }
    },
    loadMyBookshelf: function () {
        //Load all books in my bookshelf
        var headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
        var userdetails = Ext.JSON.decode(localStorage.getItem("user"));
        var Username = userdetails.UserName;
        var scope = [];
        scope[0] = "AddtoBookshelf";

        com.inbooks.classes.Helpers.Ajax(
            '/BookShelf?User=' + Username + '', '', 'GET', 'JSON',
            this.LoadMyBookshelfCallback, scope, headers);
    },
    LoadMyBookshelfCallback: function (options, success, response) {
        console.log("AddtoBookshelfCallback - Start");
        if (success) {
            try {
                var result = Ext.JSON.decode(response.responseText);
                var bookshelf = result.aaData.Data;
                com.inbooks.app.g_bookshelf = bookshelf;
                localStorage.setItem("AllBookshelf", JSON.stringify({
                    "bookshelf": com.inbooks.app.g_bookshelf
                }));
                //Set the badge text for bookshelf in footer
                Ext.getCmp('btnFooterBookshelf').setBadgeText(bookshelf.length);
            }
            catch (e) {
                console.log("Exception in AddtoBookshelfCallback ");
            }
        }
        else {
            //Possibly request timed out.
            var message = (response.timedout || response.statusText == "") ? g_m['msg0020'] : response.statusText;
            com.inbooks.classes.Helpers.notifyError(message, true);
        }
        //Hide the progress mask
        //Ext.Viewport.setMasked(false);
    },
    delFrmBookshelf: function (bookcode) {
        //Hide the progress mask
        Ext.Viewport.setMasked(false);
        var username = Ext.JSON.decode(localStorage.getItem("user"));
        var Username = username.UserName;

        //try {
        //var params = '{"request": { "UserName" : ' + '"' + Username + '"' + ', "BookCode":' + '"' + bookcode + '"' + ', "MethodType":"POST"} } ';
        var headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
        com.inbooks.classes.Helpers.Ajax('/BookShelf/' + Username + '/' + bookcode + '', '', 'POST', 'JSON', com.inbooks.classes.Helpers.DelFrmBookshelfCallback, '', headers);
        //}
        //catch (e) { }
    },
    DelFrmBookshelfCallback: function (options, success, response) {

        console.log("DelFrmBookshelfCallback callback - Start");
        if (success) {

            var response = Ext.JSON.decode(response.responseText);
            if (response.aaData.Success) {
                com.inbooks.classes.Helpers.loadMyBookshelf();
                $(".booksList .x-item-selected").hide();
                //In the nexus tablet, some default value coming from store. To avoid that, 
                var checklength = Ext.JSON.decode(localStorage.getItem("AllBookshelf")).bookshelf.length;
                if (checklength == 1) {
                    Ext.getCmp("tplBookshelfLst").setHidden(true);
                    Ext.getCmp("id-vw-bookshelf").setHtml('<div style="position: absolute; top:48%; left: 40%;">'+g_m['msg0061']+'</div>');
                                  
                }

            }
            else {
                //failure flow
                msg = g_m['msg0055'];
                com.inbooks.classes.Helpers.notifyError(msg, true);
                //Hide the progress mask
                Ext.Viewport.setMasked(false);
            }

        } else {
            //Possibly request timed out.
            var message = (response.timedout || response.statusText == "") ? g_m['msg0020'] : response.statusText;
            com.inbooks.classes.Helpers.notifyError(message, true); //message,showAsModal
            //Hide the progress mask
            Ext.Viewport.setMasked(false);
        }
        console.log("DelFrmBookshelfCallback callback - End");
    },
    loadCarouselImage: function (carouselCmp, i) {
        console.log("loadCarouselImage - Start");
        console.log("\nI IS:   "+ i.attr('src'));
        //Set or reset the bookmark icon
        com.inbooks.classes.Helpers.setBookmarkIcon();
        var bookCode = (com.inbooks.app.g_selectedBookDetails.BookCode == undefined)?com.inbooks.app.g_selectedBookDetails.BOOKCODE:com.inbooks.app.g_selectedBookDetails.BookCode;
        if (com.inbooks.app.g_pages.length > 0) {
            console.log("inside com.inbooks.app.pages.length > 0")
            //Show Progress Bar
            setTimeout(function(){
                Ext.getCmp('carousel-reader').items.items[carouselCmp.activeIndex].setMasked({
                //Ext.Viewport.setMasked({
                    xtype: 'loadmask',
                    indicator: true,
                    message: g_m['msg0048']
                });
            }, 100);
            var imgCanvas = document.createElement("canvas"),
            imgContext = imgCanvas.getContext("2d");
            imgCanvas.width = i.width();
            imgCanvas.height = i.height();

            if (i.attr('src') != undefined) {
                console.log("I ATTRIBUTE IS NOT UNDEFINED")
                if (i.attr('src').indexOf('spacer.gif') == -1) {
                    console.log("INSIDE LOAD CAROUSELIMAGE, image source is not spacer, SRC:  " + i.attr('src'))
                        var flag=false;
                        Ext.each(com.inbooks.app.g_imginfo,function(item,index){
                            if(item.PageNum==carouselCmp.activeIndex && item.BookCode==bookCode){
                                flag=true;
                                return false;
                            }
                        });
                        if(!flag){
                            imgContext.drawImage(i[0], 0, 0, i.width(), i.height());
                            var imgData = {Source: imgCanvas.toDataURL("image/jpeg"),PageNum:carouselCmp.activeIndex, BookCode: bookCode };
                            com.inbooks.app.g_imginfo.push(imgData);
                        }

           
                    setTimeout(function () {
                        //console.log("Removing mask from Browse Controller inside showCarousalPageNum() with i.attr('src') != undefined  success")
                        Ext.getCmp('carousel-reader').items.items[carouselCmp.activeIndex].setMasked(false);
                        //Ext.Viewport.setMasked(false);
                    }, 150);
                } else {
                   // var url = com.inbooks.classes.Helpers.getPageImageUrl(carouselCmp.activeIndex);
                    console.log("INSIDE LOADCAROUSELIMAGE, img source is currently spacer.gif")  ;
                    console.log("\nSTACK : " + com.inbooks.app.g_Async_prefetch_CallStack);
                    com.inbooks.classes.Helpers.loadImageAsynchronously(carouselCmp.activeIndex);
                    /*var img = new Image();
                    img.id = "imgPage_" + carouselCmp.activeIndex;
                    console.log("IMAGE ID : " + img.id);
                    img.style.width = '100%';
                    img.style.height = '100%';
                    // Set up event handlers to know when the image has loaded
                    // or fails to load due to an error or abort.
                    img.onload = imgloaded;
                    img.onerror = imgerrored; // URL returns 404, etc
                    img.onabort = imgerrored; // IE may call this if user clicks "Stop"

                    // Setting the src property begins loading the image.
                    img.src = com.inbooks.classes.Helpers.getPageImageUrl(carouselCmp.activeIndex);
                    console.log("IMAGE SRC : " + img.src);
                    //i.attr('src', url)
                    function imgloaded() {
                            var i_idx;
                            if(localStorage.getItem('ReadOffline') == 1) {
                                var flag = false;
                                Ext.each(com.inbooks.app.g_imginfo,function(item,index){
                                    if(item.PageNum==carouselCmp.activeIndex && item.BookCode==bookCode){
                                        flag=true;
                                        return false;
                                    }
                                });
                                if(!flag) {
                                    imgContext.drawImage(i[0], 0, 0, i.width(), i.height());
                                    var imgData = {Source: imgCanvas.toDataURL("image/jpeg"),PageNum:carouselCmp.activeIndex, BookCode: bookCode };
                                    com.inbooks.app.g_imginfo.push(imgData);
                                }

                                var offlineStore= Ext.getStore('OfflineReaderStore');
                                offlineStore.clearData();
                                offlineStore.sync();

                                setTimeout(function(){
                                    offlineStore.setData(com.inbooks.app.g_imginfo);
                                    offlineStore.sync();
                                }, 500);
                            }
                            console.log("Adjusting Image Size based on first item in the image array (start)")
                            img.style.height = '100%';
                            img.style.width = '100%';
                            setTimeout(function () {
                                //console.log("Removing mask from Browse Controller inside showCarousalPageNum() with i.attr('src') == undefined  success")
                                Ext.getCmp('carousel-reader').items.items[carouselCmp.activeIndex].setMasked(false);
                                //Ext.Viewport.setMasked(false);
                            }, 50);
                            //console.log("Image Source" + i.attr('src'))
                            Ext.Array.remove(com.inbooks.app.g_Async_prefetch_CallStack,carouselCmp.activeIndex);
                        }
                        function imgerrored() {
                                console.log("Error loading " + img.src);
                                //Reset to old image is required? because the previous image failed so the old image should have been there already!
                                img.src = "resources/images/spacer.gif";
                                com.inbooks.classes.Helpers.notifyError(g_m['msg0006'], true);
                                Ext.Array.remove(com.inbooks.app.g_Async_prefetch_CallStack,carouselCmp.activeIndex);
                                console.log("Removing mask");
                                setTimeout(function () {
                                    //During error no need to check for condition instead simply remove the mask
                                    //console.log("Removing mask from Browse Controller inside showCarousalPageNum() with i.attr('src') == undefined, error");
                                    Ext.getCmp('carousel-reader').items.items[carouselCmp.activeIndex].setMasked(false);
                                    //Ext.Viewport.setMasked(false);
                                }, 50);

                        }*/
                }
            }
        }
        console.log("loadCarouselImage - End");
    },
    prefetchSubsequentPages: function () {
        try{
            var carousel = Ext.getCmp('carousel-reader');
            var carouselItems = carousel.getItems().items;
            //TODO: Senthil
            for(var indx=((carousel.activeIndex)+1); indx<=((carousel.activeIndex)+5); indx++){
                if(indx < carouselItems.length){
                    console.log("CALLING LOAD ASYNC :  " + indx);
                    //var item = $('#imgPage_'+ indx);
                    //var imgUrl = com.inbooks.classes.Helpers.getPageImageUrl(indx);
                    /*if (item.attr('src') != undefined){
                     if(item.attr('src').indexOf('spacer.gif') != -1){
                     item.attr('src', imgUrl);
                     }
                     }
                     else {
                     var html = '<div class="carousel-images" style="width: 100%; height: 100%"><img  style="width: 100%; height: 100%" onload="loadedImage(' + indx + ')" onerror="loadImageError('+ indx + ')" id="imgPage_' + indx + '" src="' + imgUrl + '" /></div>';
                     carouselItems[indx].setHtml(html);
                     }*/
                    com.inbooks.classes.Helpers.loadImageAsynchronously(indx);
                }
            }
        }
        catch(e){
            console.log(e.message) ;
        }
    },
    loadImageAsynchronously: function(index) {
        console.log("INSIDE LOAD ASYNC :  " + index);
        // Define a "worker" function that should eventually resolve or reject the deferred object.
        var exists = $.map(com.inbooks.app.g_prefetchedImgs, function (obj, i) { if (obj.pageNum == index) return obj; });
        if(!exists.length && !(Ext.Array.contains(com.inbooks.app.g_Async_prefetch_CallStack,index))){
            var loadImage = function(deferred) {
                var image = new Image();
                image.id = "imgPage_" + index;
                image.style.width = '100%';
                image.style.height = '100%';
                // Set up event handlers to know when the image has loaded
                // or fails to load due to an error or abort.
                image.onload = loaded;
                image.onerror = errored; // URL returns 404, etc
                image.onabort = errored; // IE may call this if user clicks "Stop"
                // Setting the src property begins loading the image.
                image.src = com.inbooks.classes.Helpers.getPageImageUrl(index);

                com.inbooks.app.g_Async_prefetch_CallStack.push(index);
                console.log("PUSHING INDEX TO CALL STACK: " + index + " ,STACK :  "+ com.inbooks.app.g_Async_prefetch_CallStack);
                console.log("image: "+image.src)

                function loaded() {
                    console.log("INSIDE LOADED :  " + index);
                    unbindEvents();
                    // Calling resolve means the image loaded sucessfully and is ready to use.
                    deferred.resolve(image);
                    Ext.Array.remove(com.inbooks.app.g_Async_prefetch_CallStack,index);
                    console.log("REMOVING INDEX FROM CALL STACK: " + index + " ,STACK :  "+ com.inbooks.app.g_Async_prefetch_CallStack);

                    //var exists = $.map(com.inbooks.app.g_prefetchedImgs, function (obj, i) { if (obj.pageNum == index) return obj; });
                    if(!exists.length){
                        var imgData = { pageNum: index, image: image };
                        com.inbooks.app.g_prefetchedImgs.push(imgData);
                    }
                    var carouselItemDiv = document.createElement('div');//<div class="carousel-images" style="width: 100%; height: 100%;"></div>');
                    carouselItemDiv.classList.add("carousel-images");
                    carouselItemDiv.style.width = '100%';
                    carouselItemDiv.style.height = '100%';
                    carouselItemDiv.appendChild(image);
                    console.log("ITEM SET :  " + image.src);

                    Ext.getCmp('carousel-reader').items.items[index].setHtml(carouselItemDiv);
                    Ext.getCmp('carousel-reader').items.items[index].setMasked(false);
                }
                function errored() {
                    console.log("INSIDE ERRORED :  " + index);
                    unbindEvents();
                    // Calling reject means we failed to load the image (e.g. 404, server offline, etc).
                    deferred.reject(image);
                    var html = '<div class="carousel-images" style="width: 100%; height: 100%"><img  style="width: 100%; height: 100%"  id="imgPage_' + index + '" src= "resources/images/spacer.gif" /></div>';
                    Ext.getCmp('carousel-reader').items.items[index].setHtml(html);
                    console.log(Ext.getCmp('carousel-reader').items.items[index].getHtml());
                    Ext.Array.remove(com.inbooks.app.g_Async_prefetch_CallStack,index);
                    console.log("REMOVING INDEX FROM CALL STACK: " + index + " ,STACK :  "+ com.inbooks.app.g_Async_prefetch_CallStack);

                    Ext.getCmp('carousel-reader').items.items[index].setMasked(false);
                }
                function unbindEvents() {
                    console.log("INSIDE UNBIND :  " + index);
                    // Ensures the event callbacks only get called once.
                    image.onload = null;
                    image.onerror = null;
                    image.onabort = null;
                }
            };
        }
        // Create the deferred object that will contain the loaded image.
        // We don't want callers to have access to the resolve() and reject() methods,
        // so convert to "read-only" by calling `promise()`.
        return $.Deferred(loadImage).promise();
    },
    setBookmarkIcon: function () {
        console.log("setBookmarkIcon - Start");
        var carouselCmp = Ext.getCmp("carousel-reader");
        var AllBookmarks = com.inbooks.app.g_bookmarks;
        var bookCode = (com.inbooks.app.g_selectedBookDetails.BookCode == undefined) ? com.inbooks.app.g_selectedBookDetails.BOOKCODE : com.inbooks.app.g_selectedBookDetails.BookCode;
        if (AllBookmarks != null && AllBookmarks != undefined) {
            if (AllBookmarks.length > 0) {
                var mybookmarks = jQuery.map(AllBookmarks, function (obj) {
                    if ((obj.PageId == carouselCmp.activeIndex + 1) && (obj.BookCode == bookCode))
                        return obj;
                });
                if (mybookmarks.length > 0) {
                    $('#id-bookmarks').removeClass("vm-bookmarks-before-select");
                    $('#id-bookmarks').addClass("vm-bookmarks-after-select");
                }
                else {
                    $('#id-bookmarks').removeClass("vm-bookmarks-after-select");
                    $('#id-bookmarks').addClass("vm-bookmarks-before-select");
                }
            }
        }

        //Update Bookmarks store data and disable/enable bookmark button
        com.inbooks.classes.Helpers.updateBookmarksStore();
        console.log("setBookmarkIcon - End");
    },
    processBookmarkIconTap: function (data) {
        console.log("processBookmarkIconTap - Start");
        var carouselCmp = Ext.getCmp("carousel-reader");
        var headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
        var userdetails = Ext.JSON.decode(localStorage.getItem("user"));
        var Username = userdetails.UserName;
        var bookCode = (com.inbooks.app.g_selectedBookDetails.BookCode == undefined) ? com.inbooks.app.g_selectedBookDetails.BOOKCODE : com.inbooks.app.g_selectedBookDetails.BookCode;
        var scope = [];
        try {
            if (data.className == "vm-bookmarks-after-select") {
                $('#id-bookmarks').removeClass("vm-bookmarks-after-select");
                $('#id-bookmarks').addClass("vm-bookmarks-before-select");
                var bookmarkId = jQuery.map(com.inbooks.app.g_bookmarks, function (obj) {
                    if ((obj.PageId == carouselCmp.activeIndex + 1) && (obj.BookCode == bookCode))
                        return obj;
                });
                var param = '{"request": { "Id" : ' + '"' + bookmarkId[0].Id + '"' + ', "MethodType":"DELETE"} } ';
                com.inbooks.classes.Helpers.Ajax(
                    '/Bookmark/2', param, 'DELETE', 'JSON',
                    com.inbooks.classes.Helpers.deleteFromBookmarksCallback, scope, headers);
            }
            else {
                $('#id-bookmarks').removeClass("vm-bookmarks-before-select");
                $('#id-bookmarks').addClass("vm-bookmarks-after-select");
                //Call Add to bookmarks api
                var pageNum = carouselCmp.activeIndex + 1;
                var params = '{"request": { "UserName" : ' + '"' + Username + '"' + ', "BookCode":' + '"' + bookCode + '"' + ', "PageId":' + pageNum + ', "MethodType":"POST"} } ';
                com.inbooks.classes.Helpers.Ajax(
                    '/Bookmark/0', params, 'POST', 'JSON',
                    com.inbooks.classes.Helpers.addToBookmarksCallback, scope, headers);
            }
        }
        catch (e) { console.log(e.message) }
        console.log("processBookmarkIconTap - End");
    },
    deleteFromBookmarksCallback: function (options, success, response) {
        console.log("deleteFromBookmarksCallback callback");
        if (success) {
            var responseMsg = Ext.JSON.decode(response.responseText);
            if (responseMsg.aaData.Success) {
                //Call All bookmarks api and Update Bookmarks store data and disable/enable bookmark button
                com.inbooks.classes.Helpers.getAllBookmarks();
               
            }
            else {
                $('#id-bookmarks').removeClass("vm-bookmarks-before-select");
                $('#id-bookmarks').addClass("vm-bookmarks-after-select");
                //failure flow
                msg = responseMsg.aaData.Message;
                com.inbooks.classes.Helpers.notifyError(msg, true);
                //Hide the progress mask
                Ext.Viewport.setMasked(false);
            }
        } else {
            $('#id-bookmarks').removeClass("vm-bookmarks-before-select");
            $('#id-bookmarks').addClass("vm-bookmarks-after-select");
            //Possibly request timed out.
            var message = (response.timedout || response.statusText == "") ? g_m['msg0020'] : response.statusText;
            com.inbooks.classes.Helpers.notifyError(message, true); //message,showAsModal
            //Hide the progress mask
            Ext.Viewport.setMasked(false);
        }
        console.log("deleteFromBookmarksCallback callback");
    },
    addToBookmarksCallback: function (options, success, response) {
        console.log("addToBookmarksCallback callback");
        if (success) {
            var responseMsg = Ext.JSON.decode(response.responseText);
            if (responseMsg.aaData.Success) {
                //Call All bookmarks api and Update Bookmarks store data and disable/enable bookmark button
                com.inbooks.classes.Helpers.getAllBookmarks();
            }
            else {
                $('#id-bookmarks').removeClass("vm-bookmarks-after-select");
                $('#id-bookmarks').addClass("vm-bookmarks-before-select");
                //failure flow
                msg = responseMsg.aaData.Message;
                com.inbooks.classes.Helpers.notifyError(msg, true);
                //Hide the progress mask
                Ext.Viewport.setMasked(false);
            }
        } else {
            $('#id-bookmarks').removeClass("vm-bookmarks-after-select");
            $('#id-bookmarks').addClass("vm-bookmarks-before-select");
            //Possibly request timed out.
            var message = (response.timedout || response.statusText == "") ? g_m['msg0020'] : response.statusText;
            com.inbooks.classes.Helpers.notifyError(message, true); //message,showAsModal
            //Hide the progress mask
            Ext.Viewport.setMasked(false);
        }
        console.log("addToBookmarksCallback callback");
    },
    updateBookmarksStore: function () {
        console.log("updateBookmarksStore - Start");
        try {
            var bookCode = (com.inbooks.app.g_selectedBookDetails.BookCode == undefined) ? com.inbooks.app.g_selectedBookDetails.BOOKCODE : com.inbooks.app.g_selectedBookDetails.BookCode;
            var store = Ext.getStore('BookmarksStore');
            store.clearData();
            store.setData(com.inbooks.app.g_bookmarks);
            store.filter("BookCode", bookCode);
            if (store.data.items.length == 0) {
                if (com.inbooks.app.g_bookmarkPanel != null) {
                    com.inbooks.app.g_bookmarkPanel.hide();
                }
                Ext.getCmp('btnBookmark').setPressedButtons(false);
                Ext.getCmp('id-Bookmarks').setText('<i style="color: gray;" class="icon-2x icon-tags"></i>').disable();
            }
            else {
                Ext.getCmp('id-Bookmarks').setText('<i style="color: red;" class="icon-2x icon-tags"></i>').enable();
            }
        }
        catch (e) { }
        console.log("updateBookmarksStore - End");
    },
    getAllBookmarks: function () {
        console.log("getAllBookmarks - Start");
        var headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
        var userdetails = Ext.JSON.decode(localStorage.getItem("user"));
        var Username = userdetails.UserName;
        var bookCode = (com.inbooks.app.g_selectedBookDetails.BookCode == undefined) ? com.inbooks.app.g_selectedBookDetails.BOOKCODE : com.inbooks.app.g_selectedBookDetails.BookCode;
        var scope = [];

        com.inbooks.classes.Helpers.Ajax(
            '/Bookmark?User=' + Username + '&BookCode=' + bookCode, '', 'GET', 'JSON',
            this.getAllBookmarksCallback, scope, headers);
        console.log("getAllBookmarks - end");
    },
    getAllBookmarksCallback: function (options, success, response) {
        console.log("getAllBookmarksCallback - Start");
        if (success) {
            try {
                var result = Ext.JSON.decode(response.responseText);
                if (result.aaData.Success) {
                    com.inbooks.app.g_bookmarks = result.aaData.Data;
                    //Update Bookmarks store data and disable/enable bookmark button
                    com.inbooks.classes.Helpers.updateBookmarksStore();
                }
                else {
                    //failure flow
                    msg = g_m['msg0055'];
                    com.inbooks.classes.Helpers.notifyError(msg, true);
                    //Hide the progress mask
                    //Ext.Viewport.setMasked(false);
                }
            }
            catch (e) {
                console.log("Exception in AddtoBookshelfCallback ");
            }
        }
        else {
            //Possibly request timed out.
            var message = (response.timedout || response.statusText == "") ? g_m['msg0020'] : response.statusText;
            com.inbooks.classes.Helpers.notifyError(message, true);
        }
        //Hide the progress mask
        //Ext.Viewport.setMasked(false);
        console.log("getAllBookmarksCallback - End");
    },
    GotoPage: function(){
        console.log("showGotoPage - Start");
        var cmp = Ext.getCmp('carousel-reader');
        try{
            com.inbooks.app.g_gotoPageSlider = null;
            Ext.getCmp('goto-page-slider').destroy();
        }
        catch(e){console.log(e.message)}

        try{
            if (com.inbooks.app.g_gotoPageSlider == null) {
                console.log("cmp.items.length: "+ cmp.items.length);
                com.inbooks.app.g_gotoPageSlider = Ext.getCmp('id-carousel-panel').add(
                    {
                        xtype: 'sliderfield',
                        value: 1,//(cmp.activeIndex)+1,
                        docked: 'bottom',
                        id: 'goto-page-slider',
                        minValue: 1,
                        increment: 1,
                        cls: 'vm-slider',
                        maxValue: cmp.items.length,
                        listeners: {
                            painted: function(){
                                console.log("showGotoPage painted event - Start");
                                Ext.getCmp('goto-page-slider').setValue((cmp.activeIndex)+1);
                                setTimeout(function(){
                                    try{
                                        $('.x-thumb')[0].innerHTML = (cmp.activeIndex)+1;
                                    }
                                    catch(e){ console.log(e.message) }

                                }, 10);
                                console.log("showGotoPage painted event - End");
                            },
                            change: function( me, sl, thumb, newValue, oldValue, eOpts){
                                console.log("showGotoPage change event - Start");
                                console.log("newValue"+newValue);
                                try{
                                    //Set active item of carousel to the slider value
                                    cmp.setActiveItem(newValue-1);
                                    var i = $('#imgPage_' + cmp.activeIndex);
                                    console.log("load Carousel Image: "+ i);

                                    //Load carousel page
                                    com.inbooks.classes.Helpers.loadCarouselImage(cmp, i);
                                }
                                catch(e){
                                    console.log(e.message);
                                }
                                console.log("showGotoPage change event - End");
                            },
                            drag: function(slider, sl, thumb, e, eOpts){
                                console.log("showGotoPage drag event - Start");
                                try{
                                    console.log("slider.getValue(): "+slider.getValue());
                                    if(slider.getValue()!=NaN){
                                        $('.x-thumb')[0].innerHTML = slider.getValue();
                                    }
                                }
                                catch(e){ console.log(e.message) }
                                console.log("showGotoPage drag event - End");
                            }
                        }
                    });
            }
            com.inbooks.app.g_gotoPageSlider.show();
        }
        catch(e){
            console.log(e.message);
        }
        console.log("showGotoPage - End");
    },
    onSearchKeyUp: function(field) {
        //get the store and the value of the field
        var value = field.getValue(),
            store = Ext.getStore('SearchStore');

        //first clear any current filters on the store. If there is a new value, then suppress the refresh event
        store.clearFilter(!!value);

        //check if a value is set first, as if it isnt we dont have to do anything
        if (value) {
            //the user could have entered spaces, so we must split them so we can loop through them all
            var searches = value.split(','),
                regexps = [],
                i, regex;

            //loop them all
            for (i = 0; i < searches.length; i++) {
                //if it is nothing, continue
                if (!searches[i]) continue;
                regex = searches[i].trim();
                regex = regex.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");

                //if found, create a new regular expression which is case insenstive
                regexps.push(new RegExp(regex.trim(), 'i'));
            }

            //now filter the store by passing a method
            //the passed method will be called for each record in the store
            store.filter(function(record) {
                var matched = [];

                //loop through each of the regular expressions
                for (i = 0; i < regexps.length; i++) {
                    var search = regexps[i],
                        didMatch = search.test(record.get('NAME'));

                    //if it matched the first or last name, push it into the matches array
                    matched.push(didMatch);
                }

                return (regexps.length && matched.indexOf(true) !== -1);
            });
        }
    },
    updateScreenOrientation: function(e, value, oldValue, eOpts){
        //Update the orientation
        try{
            var landscapeMode = localStorage.getItem('LandscapeOrientation');
            if(landscapeMode == "1"){
                var activeView = value.xtype;
                if(!(activeView == undefined)){
                    if(!(activeView == 'dashboard')){
                        //Change the orientation to default
                        window.MyCls.changeToDefaultOrientation();
                    }
                    else{
                        //Fix the orientation to portrait in Dashboard
                        window.MyCls.changeToPortrait();
                    }
                }
            }
        }
        catch(e){ }
    }
});